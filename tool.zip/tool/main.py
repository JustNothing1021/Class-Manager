from tkinter import *
from typing import *
import tkinter as tk
import tkinter.font as tkFont
from typing import *
from tkinter import ttk
import time
import sys
import traceback
import os
import tkinter.messagebox
import tkinter.scrolledtext
import pickle
import threading
import ctypes
from io import TextIOWrapper
import pygame
import base64

ctypes.windll.shcore.SetProcessDpiAwareness(1)
ScaleFactor = ctypes.windll.shcore.GetScaleFactorForDevice(0)
screen_width = ctypes.windll.user32.GetSystemMetrics(0)
screen_height = ctypes.windll.user32.GetSystemMetrics(1)
pygame.mixer.init()

inf = float("inf")
ninf = float("-inf")
nan = float("nan")

line = os.popen("whoami > user.txt").read()

user_list = line.split("\\")
user_name_computer = user_list[0]
user_name_default = user_list[-1]





def play_sound(filename):
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play()


def login():
    import tkinter as tk
    import tkinter.messagebox
    import pickle
    root = tk.Tk()
    root.title('登录')
    root.geometry("400x300+500+400")
    tk.Label(root, text='你好！').pack()
    tk.Label(root, text='用户名:').place(x=10, y=170)
    tk.Label(root, text='密码:').place(x=10, y=210)





current_user = "测试用户1"
VERSION = "1.0.0"
VERSION_CODE = 10000

debug = True

LOG_FILE = "log.log"
function = type(lambda:None)



SOUND_BRUH = os.getcwd() + "\\res\\sounds\\bruh.mp3"

def utc(precision:int=3):
    return int(time.time()*pow(10, precision))
    


class Logger(TextIOWrapper):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.line = ""

    def write(self, s):
        self.line += s
        if self.line.__contains__("\n"):
            super().write(s)
            log("W", s, "sys.stderr")

            self.line = ""

    def flush(self):
        "忽略"
        pass

class Logger2():
    def __init__(self):
        self.line = ""

    def write(self, s):
        self.line += s
        if self.line.__contains__("\n"):
            super().write(s)
            log("W", s, "sys.stderr")
            self.line = ""

try:
    err_orig = sys.stderr
    sys.stderr = Logger(err_orig)
except:
    sys.stderr = Logger2()
    
def gettime():
    lt = time.localtime()
    return F"{lt.tm_year}-{lt.tm_mon:02}-{lt.tm_mday:02} {lt.tm_hour:02}:{lt.tm_min:02}:{lt.tm_sec:02}.{int((time.time()%1)*1000):03}"

def log(type:Literal["I", "W", "E", "F", "D"],msg:str,send:str="MainThread"):
    with open(LOG_FILE, "a+", encoding="utf-8") as lf:
        for m in msg.splitlines():
            if not m.strip():
                continue
            m = f"{gettime()} {type} {send.ljust(35)} {m}\n"
            try:
                sys.stdout.write(m)
            except:
                pass
            lf.write(m)
            try:
                log_scr.config(state="normal")
                
                log_scr.insert(tk.END, m)
                log_scr.see(tk.END)
                log_scr.config(state="disabled")
    
            except:
                pass
    lf.close()




class ModifyingError(Exception):"修改出现错误。"
class ScoreModification: ...
class Achievement: ...


class Student:
    "一个学牲"
    def __init__(self, name:str, num:int, score:float, belongs_to:str, 
                 history:Dict[Any, ScoreModification]=None, last_reset:Optional[float]=None,
                 highest_score:float=0.0, lowest_score:float=0.0,
                 achievements:Dict[int, Achievement]=None, total_score:float=None,
                 highest_score_cause_time:float=0.0, lowest_score_cause_time:float=0.0):
        self._name = name
        self._num = num
        self._score = score
        self._belongs_to:str = belongs_to
        self._highest_score:float = highest_score
        self._lowest_score:float = lowest_score
        self._total_score:float = total_score if total_score is not None else score
        self.last_reset = last_reset
        self._highest_score_cause_time = highest_score_cause_time
        self._lowest_score_cause_time = lowest_score_cause_time
        self.achievements:Dict[int, Achievement] = achievements if achievements is not None else dict()
        


        if history is not None:
            self.history = history 
        else:
            log("I", f"学生{name.__repr__()}的history为None, 识别为历史记录中的Student对象（若需表达历史为空请改用{{}}）")
        
            # 我才发现如果不给初始值就会公共使用一个对象。。。
            # 就比如默认参数为{}那么所有的Student都会共用这个"{}"导致修改一个就会全部的学生都被更改。。。
        

    @property
    def highest_score(self):
        return self._highest_score
    
    @highest_score.setter
    def highest_score(self, value):
        log("I", f"{self.name} 更改最高分：{self._highest_score} -> {value}")
        self._highest_score = value
    
    @property
    def lowest_score(self):
        return self._lowest_score
    
    @lowest_score.setter
    def lowest_score(self, value):
        log("I", f"{self.name} 更改最低分：{self._lowest_score} -> {value}")
        self._lowest_score = value
    

    @property
    def highest_score_cause_time(self):
        return self._highest_score_cause_time
    
    @highest_score_cause_time.setter
    def highest_score_cause_time(self, value):
        log("I", f"{self.name} 更改最高分对应时间：{self._highest_score_cause_time} -> {value}")
        self._highest_score_cause_time = value

    @property
    def lowest_score_cause_time(self):
        return self._lowest_score_cause_time
    
    @lowest_score_cause_time.setter
    def lowest_score_cause_time(self, value):
        log("I", f"{self.name} 更改最低分对应时间：{self._lowest_score_cause_time} -> {value}")
        self._lowest_score_cause_time = value


    def __str__(self):
        return f"{self._name}({self._num}号，{self._score}分)"
    
    def __repr__(self):
        return (
F"Student(name={self._name.__repr__()}, " +
F"num={self._num.__repr__()}, score={self._score.__repr__()}, " +
F"belongs_to={self._belongs_to.__repr__()}, " +
(F"history={self.history.__repr__()}, " if hasattr(self, "history") else "") +
F"last_reset={repr(self.last_reset)}, " +
F"highest_score={repr(self.highest_score)}, " +
F"lowest_score={repr(self.highest_score)}, " +
F"total_score={repr(self.highest_score)}, " +
(F"achievements={repr(self.achievements)}, " if hasattr(self, "achievements") else "") +
F"highest_score_cause_time = {repr(self.highest_score_cause_time)}, " +
F"lowest_score_cause_time = {repr(self.lowest_score_cause_time)}" +
")")


    @property
    def name(self):
        "学生的名字。"
        return self._name
    
    @name.setter
    def name(self, val):
        log("W",f"正在尝试更改学号为{self._num}的学生的姓名：由\"{self._name}\"更改为\"{val}\"","Student.name.setter")
        if len(val) >= 50:
            log("E",f"更改名字失败：不是谁名字有{len(val)}个字啊？？？？","Student.name.setter")
            raise ModifyingError(f"请求更改的名字\"{val}\"过长，无法设置（但是为什么会有人有这么长的名字。。）")
        self._name = val
        log("I","更改完成！","Student.name.setter")

    @name.deleter
    def name(self):
        log("E","错误：用户尝试删除学生名","Student.num.deleter")
        raise ModifyingError("不允许删除学生的名字（没有名字了你们就不认得了）")
    

    @property
    def num(self):
        "学生的学号。"
        return self._num

    @num.setter
    def num(self, val:int):
        log("W",f"正在尝试更改学号为{self._name}的学生的学号：由{self._num}更改为{val}","Student.num.setter")
        if val >= 100:
            log("E","更改学号失败：学号过大了，不太合理","Student.name.setter")
            raise ModifyingError(f"请求更改的学号{val}过大了, 无法设置")
        self._num = val
        log("I","更改完成！","Student.name.setter")

    @num.deleter
    def num(self):
        log("E","错误：用户尝试删除学号（？？？？）","Student.name.deleter")
        raise ModifyingError("不允许删除学生的学号")
    
    @property
    def score(self):
        "学生的分数，操作时仅保留1位小数。"
        return self._score

    @score.setter
    def score(self, val:float):
        logstr = f"""正在尝试更改学号为{self._name}的学生的分数：由{self._score}更改为{val}（{f"上升{val-self._score:.1f}分" if val >= self._score else f"下降{(val-self._score)*-1:.1f}分"}）"""
        self.total_score += val - self._score
        if abs(val-self._score) >= 1145:
            logstr += "; 涉及到大分数操作，请注意此处"
        self._score = round(val,1)
        if self._score > self.highest_score:
            self.highest_score = self._score
            logstr += "; 刷新新高分！"
        if self._score < self.lowest_score:
            self.lowest_score = self._score
            logstr += "; 刷新新低分！（不应该是件好事？）"
        log("I",logstr,"Student.score.setter")

    @score.deleter
    def score(self):
        log("E","错误：用户尝试删除分数（？？？？）","Student.score.deleter")
        raise ModifyingError("不允许直接删除学生的分数")
    
    @property
    def belongs_to(self):
        "学生归属班级。"
        return self._belongs_to

    @belongs_to.setter
    def belongs_to(self,_):
        log("E","错误：用户尝试修改班级","Student.belongs_to.setter")
        raise ModifyingError("不允许直接修改学生的班级")

    @belongs_to.deleter
    def belongs_to(self):
        log("E","错误：用户尝试删除班级（？？？？？？？）","Student.belongs_to.deleter")
        raise ModifyingError("不允许直接删除学生的班级")
    
    def reset(self):
        "重置分数信息。"

    @property
    def total_score(self):
        return round(self._total_score,1)
    
    @total_score.setter
    def total_score(self, value):
        self._total_score = value


class StudentToSetInHistory(Student):
    @overload
    def __init__(self, stu:Student):...

    @overload
    def __init__(self, name:str, num:int, score:float, belongs_to:str, history:dict):...
    
    def __init__(self, stu_or_name, num=None, score=None, belongs_to=None, history=None, **kwargs):
        if isinstance(stu_or_name, Student):
            super().__init__(stu_or_name._name, stu_or_name._num, stu_or_name._score, stu_or_name._belongs_to, {}, **(kwargs))
        else:
            super().__init__(stu_or_name, num, score, belongs_to, {})
        del self.history
    

class ScoreModificationTemplate:
    "分数加减操作的模板。"
    def __init__(self, key:str, modification:float, title:str, description:str="该加减分模板没有详细信息。", cant_replace:bool=False):
        global classes
        logstr = "新的加减分模板创建模板创建："
        self.key = key
        logstr += f"key={key} "
        self.mod = modification
        logstr += f" 分数操作数量：{self.mod:.1f}"
        self.title = title
        logstr+=f" 原因：{self.title}"
        self.desc = description
        log("D",logstr+f" 详情：{self.desc}","ScoreModificationTemplate")
        self.cant_replace = cant_replace

    def __repr__(self):
        return f"""ScoreModificationTemplate(\
key={self.key.__repr__()} \
modification={self.mod.__repr__()}, \
title={self.title.__repr__()}, \
description={self.desc.__repr__()}, \
cant_replace={self.cant_replace.__repr__()})"""

    def __str__(self):
        return f"""\
分数变化：{self.mod:.1f}
原因：{self.title}
详情：{self.desc}""" + ("\n无法替换"  if self.cant_replace else "")






class ScoreModification:
    def __init__(self, template:ScoreModificationTemplate,
                       target:Student,
                       title:Optional[str]=None,
                       desc:Optional[str]=None,
                       mod:Optional[float]=None,
                       execute_time:Optional[str]=None,
                       create_time:Optional[str]=gettime(),
                       executed:bool=False,
                       ):
        global classes
        logstr = "新的待执行的加减分对象创建, "
        self.temp = template
        if title == self.temp.title:desc = None
        if mod == self.temp.mod:mod = None
        if desc == self.temp.desc:desc = None
        logstr += "模板信息："+("").join(str(self.temp.__str__()).splitlines(True)).strip().replace("\n",", ") + "; "
        if mod is not None:
            logstr += f"该加减分对象的加减分数经设置:{mod},可能来自Student.history; "
        self.mod = self.temp.mod if mod is None else mod
        if title is not None:
            logstr += "该加减分对象的原因有额外修改：" + title + "; "
        self.title = title if title is not None else self.temp.title
        if desc is not None:
            logstr += "该加减分对象的描述有额外修改：" + desc + "; "
        self.desc = desc if desc is not None else self.temp.desc
        self.target = StudentToSetInHistory(target)
        logstr += f"针对的学生：{target._name}({target._num}号，目前{target._score}分)"
        self.execute_time = execute_time
        self.create_time = create_time
        self.executed = executed
        log("I",logstr + ", 模板创建成功！","ScoreModification.__init__")
    

    def __repr__(self):
        return f"ScoreModification(template={self.temp.__repr__()}, target={self.target.__repr__()}, title={self.title.__repr__()}, desc={self.desc.__repr__()}, mod={self.mod.__repr__()}, execute_time={self.execute_time.__repr__()}, create_time={self.create_time.__repr__()}, executed={self.executed.__repr__()})"

    def __str__(self):
        global classes
        nl = "\n"
        target = self.target
        return f"""\
{self.mod:+.1f}分
原因：{self.title}
描述：{self.desc}
对象：{target._name}({target._num}号，{"暂未执行" if not self.executed else "操作已落实"}，目前{target._score}分)
创建时间：{self.create_time}{(nl+f"落实时间：{self.execute_time}") if self.execute_time is not None else ""}
"""
    def execute(self) -> bool:
        "执行当前的操作"
        if self.executed:
            log("W","执行已经完成，无需再次执行，如需重新执行请创建新的ScoreModification对象","ScoreModification.execute")
            return False
        logstr = ""
        logstr += "开始执行当前加减分, "
        logstr += "信息："+("").join(str(self).splitlines(True)).strip().replace("\n", ",") + ";"
        log("I", logstr, "ScoreModification.execute")
        try:
            self.execute_time = gettime()    
            self.execute_time_key = int(time.time()*1000)
            if classes[self.target.belongs_to].students[self.target.num].highest_score < classes[self.target.belongs_to].students[self.target.num].score + self.mod:
                log("I",f"预计刷新最高分：{classes[self.target.belongs_to].students[self.target.num].highest_score} -> {classes[self.target.belongs_to].students[self.target.num].score + self.mod}","ScoreModification.execute")
                classes[self.target.belongs_to].students[self.target.num].highest_score = classes[self.target.belongs_to].students[self.target.num].score + self.mod
                classes[self.target.belongs_to].students[self.target.num].highest_score_cause_time = self.execute_time_key
                log("I",f"修改完成，execute_time_key={self.execute_time_key}","ScoreModification.execute")

            if classes[self.target.belongs_to].students[self.target.num].lowest_score > classes[self.target.belongs_to].students[self.target.num].score + self.mod:
                log("I",f"预计刷新最低分：{classes[self.target.belongs_to].students[self.target.num].highest_score} -> {classes[self.target.belongs_to].students[self.target.num].score + self.mod}","ScoreModification.execute")
                classes[self.target.belongs_to].students[self.target.num].lowest_score = classes[self.target.belongs_to].students[self.target.num].score + self.mod
                classes[self.target.belongs_to].students[self.target.num].lowest_score_cause_time = self.execute_time_key 
                log("I",f"修改完成，execute_time_key={self.execute_time_key}","ScoreModification.execute")

            classes[self.target.belongs_to].students[self.target.num].score += self.mod
            log("I",f"执行完成，分数变化：{classes[self.target._belongs_to].students[self.target._num]._score - self.mod} -> {classes[self.target._belongs_to].students[self.target._num]._score}","ScoreModification.execute")
            self.executed = True
            
            classes[self.target.belongs_to].students[self.target.num].history[self.execute_time_key] = self
            return True

        except:
            if debug:raise
            log("E","执行时出现错误：\n\t\t"+("\t"*2).join(str(traceback.format_exc()).splitlines(True)).strip(),"ScoreModification.execute")
            return False

    def retract(self) -> bool:
        "撤销执行的操作"
        if self.executed:
            log("I","尝试撤回上次操作...","ScoreModification.execute")
            try:
                if self.mod < 0:
                    is_negative = True
                else:
                    is_negative = False
                if is_negative:
                    findscore = 0.0
                    lowestscore = 0.0
                    lowesttimekey = 0
                    for i in classes[self.target.belongs_to].students[self.target.num].history:
                        tmp:ScoreModification = classes[self.target.belongs_to].students[self.target.num].history[i]
                        if tmp.execute_time_key != self.execute_time_key:findscore += tmp.mod
                        if lowestscore > findscore and tmp.execute_time_key != self.execute_time_key: # 自己不参与排序
                            lowestscore = findscore
                    if self.execute_time_key == lowesttimekey:
                        lowestscore = 0
                    if classes[self.target.belongs_to].students[self.target.num].lowest_score_cause_time != lowesttimekey:
                        log("I",f"更新lowest_score_cause_time：{classes[self.target.belongs_to].students[self.target.num].lowest_score_cause_time} -> {lowesttimekey}","ScoreModification.execute")
                        classes[self.target.belongs_to].students[self.target.num].lowest_score_cause_time = lowesttimekey

                    if classes[self.target.belongs_to].students[self.target.num].lowest_score != lowestscore:
                        log("I",f"更新lowest_score：{classes[self.target.belongs_to].students[self.target.num].lowest_score} -> "
                                f"{lowestscore}","ScoreModification.execute")
                        classes[self.target.belongs_to].students[self.target.num].lowest_score = lowestscore
                    
                    
                else:
                    findscore = 0.0
                    highestscore = 0.0
                    highesttimekey = 0
                    for i in classes[self.target.belongs_to].students[self.target.num].history:
                        tmp:ScoreModification = classes[self.target.belongs_to].students[self.target.num].history[i]
                        if tmp.execute_time_key != self.execute_time_key:findscore += tmp.mod

                        if highestscore < findscore and tmp.execute_time_key != self.execute_time_key:
                            highesttimekey = tmp.execute_time_key
                            highestscore = findscore
                    if self.execute_time_key == highesttimekey:
                        highestscore = 0
                    if classes[self.target.belongs_to].students[self.target.num].highest_score_cause_time != highesttimekey:
                        log("I",f"更新highest_score_cause_time：{classes[self.target.belongs_to].students[self.target.num].highest_score_cause_time} -> {highesttimekey}","ScoreModification.execute")
                        classes[self.target.belongs_to].students[self.target.num].highest_score_cause_time = highesttimekey 

                    if classes[self.target.belongs_to].students[self.target.num].highest_score != highestscore:
                        log("I",f"更新highest_score：{classes[self.target.belongs_to].students[self.target.num].highest_score} -> "
                                f"{highestscore}","ScoreModification.execute")
                        classes[self.target.belongs_to].students[self.target.num].highest_score = highestscore


                score_orig = classes[self.target.belongs_to].students[self.target.num].score
                classes[self.target.belongs_to].students[self.target.num].score -= self.mod
                log("I",f"撤销完成，分数变化：{score_orig} -> {classes[self.target._belongs_to].students[self.target._num]._score}","ScoreModification.retract")
                self.executed = False
                self.execute_time = None
                del classes[self.target.belongs_to].students[self.target.num].history[self.execute_time_key]
                return True
            except:
                if debug:raise
                log("E","执行时出现错误：\n\t\t"+("\t"*2).join(str(traceback.format_exc()).splitlines(True)).strip(),"ScoreModification.retract")
                return False
        else:
            log("W","操作并未执行，无需撤回","ScoreModification.retract")
            return False


class Class:
    "一个班寄"
    def __init__(self, name:str, owner:str, students:Dict[int, Student], key):
        self.name = name
        self.owner = owner
        self.students = students
        self.key = key

    def __repr__(self):
        return f"Class(name={self.name.__repr__()}, owner={self.owner.__repr__()}, students={self.students.__repr__()}, key={self.key.__repr__()})"

    def __str__(self):
        return self.name
    
DEFAULT_CLASSES:Dict[str, Class] = {
    "CLASS_1145": Class(
        "1145班",
        "王晶晶老师",
        {
            1:  Student("1号",  1, 0.0, "CLASS_1145",  {}, achievements={}),
            2:  Student("2号",  2, 0.0, "CLASS_1145",  {}, achievements={}),
            3:  Student("3号",  3, 0.0, "CLASS_1145",  {}, achievements={}),
            4:  Student("4号",  4, 0.0, "CLASS_1145",  {}, achievements={}),
            5:  Student("5号",  5, 0.0, "CLASS_1145",  {}, achievements={}),
            6:  Student("6号",  6, 0.0, "CLASS_1145",  {}, achievements={}),
            7:  Student("7号",  7, 0.0, "CLASS_1145",  {}, achievements={}),
            8:  Student("8号",  8, 0.0, "CLASS_1145",  {}, achievements={}),
            9:  Student("9号",  9, 0.0, "CLASS_1145",  {}, achievements={}),
            10: Student("10号", 10, 0.0, "CLASS_1145", {}, achievements={}),
            11: Student("11号", 11, 0.0, "CLASS_1145", {}, achievements={}),
            12: Student("12号", 12, 0.0, "CLASS_1145", {}, achievements={}),
            13: Student("13号", 13, 0.0, "CLASS_1145", {}, achievements={}),
            14: Student("14号", 14, 0.0, "CLASS_1145", {}, achievements={}),
            15: Student("15号", 15, 0.0, "CLASS_1145", {}, achievements={}),
            16: Student("16号", 16, 0.0, "CLASS_1145", {}, achievements={}),
            17: Student("17号", 17, 0.0, "CLASS_1145", {}, achievements={}),
            21: Student("21号", 21, 0.0, "CLASS_1145", {}, achievements={}),
            22: Student("22号", 22, 0.0, "CLASS_1145", {}, achievements={}),
            23: Student("23号", 23, 0.0, "CLASS_1145", {}, achievements={}),
            24: Student("24号", 24, 0.0, "CLASS_1145", {}, achievements={}),
            25: Student("25号", 25, 0.0, "CLASS_1145", {}, achievements={}),
            26: Student("26号", 26, 0.0, "CLASS_1145", {}, achievements={}),
            28: Student("28号", 28, 0.0, "CLASS_1145", {}, achievements={}),
            29: Student("29号", 29, 0.0, "CLASS_1145", {}, achievements={}),
            30: Student("30号", 30, 0.0, "CLASS_1145", {}, achievements={}),
            31: Student("31号", 31, 0.0, "CLASS_1145", {}, achievements={}),
            32: Student("32号", 32, 0.0, "CLASS_1145", {}, achievements={}),
            33: Student("33号", 33, 0.0, "CLASS_1145", {}, achievements={}),
            34: Student("34号", 34, 0.0, "CLASS_1145", {}, achievements={}),
            35: Student("35号", 35, 0.0, "CLASS_1145", {}, achievements={}),
            36: Student("36号", 36, 0.0, "CLASS_1145", {}, achievements={}),
            37: Student("37号", 37, 0.0, "CLASS_1145", {}, achievements={}),
            38: Student("38号", 38, 0.0, "CLASS_1145", {}, achievements={}),
            40: Student("40号", 40, 0.0, "CLASS_1145", {}, achievements={}),
            41: Student("41号", 41, 0.0, "CLASS_1145", {}, achievements={}),
            42: Student("42号", 42, 0.0, "CLASS_1145", {}, achievements={}),
            43: Student("43号", 43, 0.0, "CLASS_1145", {}, achievements={}),
            44: Student("44号", 44, 0.0, "CLASS_1145", {}, achievements={}),
            45: Student("45号", 45, 0.0, "CLASS_1145", {}, achievements={}),
            46: Student("46号", 46, 0.0, "CLASS_1145", {}, achievements={}),
            47: Student("47号", 47, 0.0, "CLASS_1145", {}, achievements={}),
            49: Student("49号", 49, 0.0, "CLASS_1145", {}, achievements={}),
            50: Student("50号", 50, 0.0, "CLASS_1145", {}, achievements={}),
            51: Student("51号", 51, 0.0, "CLASS_1145", {}, achievements={}),
            52: Student("52号", 52, 0.0, "CLASS_1145", {}, achievements={}),
            53: Student("53号", 53, 0.0, "CLASS_1145", {}, achievements={}),
            54: Student("54号", 54, 0.0, "CLASS_1145", {}, achievements={}),
            55: Student("55号", 55, 0.0, "CLASS_1145", {}, achievements={})
        },
        "CLASS_1145"
    )
}

class StatusObserver:
    class ClassStatusObserver:
        def __init__(self, class_name):
            self.on_active:bool = False
            self.student_count:int = 0
            self.student_total_score:float = 0
            self.class_name:str = class_name
            self.stu_score_ord:dict = {}
        
        def _start(self):
            if not self.on_active:
                self.on_active = True
                while self.on_active:
                    time.sleep(0.05)
                    self.student_count = len(classes[self.class_name].students)
                    self.student_total_score = sum([s.score for s in classes[self.class_name].students.values()])
                    self.stu_score_ord = dict(zip(range(1, self.student_count+1), 
                                                sorted(list(classes[self.class_name].students.values()),key=lambda a:a.score)))
                    stu_list = classes[self.class_name].students.values()
                    stu_list = sorted(stu_list, key=lambda s:s.score, reverse=True)
                    stu_list2:List[Tuple[int, Student]] = [] 
                    last = inf
                    last_ord = 0
                    cur_ord = 0
                    for stu in stu_list:
                        cur_ord += 1
                        if stu.score == last:
                            _ord = last_ord
                        else:
                            _ord = cur_ord
                            last_ord = cur_ord
                        stu_list2.append((_ord, stu))
                        last = stu.score
                    self.rank_non_dumplicate = stu_list2
                    stu_list = classes[self.class_name].students.values()
                    stu_list = sorted(stu_list, key=lambda s:s.score, reverse=True)
                    stu_list2:List[Tuple[int, Student]] = [] 
                    last = inf
                    last_ord = 0
                    cur_ord = 0
                    for stu in stu_list:
                        if stu.score == last:
                            _ord = last_ord
                        else:
                            cur_ord += 1
                            _ord = cur_ord
                            last_ord = cur_ord
                        stu_list2.append((_ord, stu))
                        last = stu.score
                        
                    self.rank_dumplicate = stu_list2
                    
            else:
                log("I", "已经有存在的侦测线程了，无需再次启动")
                
        def start(self):
            a = threading.Thread(target=self._start)
            a.start()

        def stop(self):
            self.on_active = False

    class AchievementStatusObserver:
        def __init__(self, class_name):
            self.on_active:bool = False
            self.class_name = class_name
            
        
        def _start(self):
            if not self.on_active:
                self.on_active = True
                while self.on_active:
                    time.sleep(0.05)
                    for s in list(classes[self.class_name].students.values()):
                        for a in list(achievememt_templates.keys()):
                            if achievememt_templates[a].got(s) and (
                                achievememt_templates[a].key not in 
                                [a.temp.key for a in classes[self.class_name].students[s.num].achievements.values()]):
                                time.sleep(0.3) # 为了防止那边操作还未完成导致误判（真的有小概率情况会）
                                if achievememt_templates[a].got(s):
                                    log("I", F"[{s.name}] 达成了成就 [{achievememt_templates[a].name}]")
                                    Achievement(achievememt_templates[a], s).give()
                                    display_achievement(achievememt_templates[a], s)
                                    


            else:
                log("I", "已经有存在的侦测线程了，无需再次启动")
                
        def start(self):
            a = threading.Thread(target=self._start)
            a.start()

        def stop(self):
            self.on_active = False

achievement_obs: StatusObserver.AchievementStatusObserver
class_obs: StatusObserver.ClassStatusObserver

    

class AchievementTemplate:
    def __init__(self,     
                 key:str,
                 name:str,
                 desc:str,                           
                 # 满足以下所有条件才会给成就
                 name_equals:Optional[Union[str, Iterable[str]]]=None,   # 名称等于/在列表中
                 num_equals:Optional[Union[str, Iterable[str]]]=None,    # 学号等于/在列表中
                 score_range:Optional[Tuple[float, float]]=None,         # 分数范围
                 score_rank_range:Optional[Tuple[int, int]]=None,       # 名次范围（不计算并列的，名词按1-2-2-3-3之类计算）
                 highest_score_range:Optional[Tuple[float, float]]=None, # 最高分数范围
                 lowest_score_range:Optional[Tuple[float, float]]=None,  # 最低分数范围
                 highest_score_cause_range:Optional[Tuple[int, int]]=None, # 最高分产生时间的范围（utc，*1000）
                 lowest_score_cause_range:Optional[Tuple[int, int]]=None,  # 最低分产生时间的范围
                 modify_key_range:Optional[Union[Tuple[str, int, int], Iterable[Tuple[str, int, int]]]]=None,          # 指定点评次数的范围（必须全部符合o）
                 others:Optional[Union[str, Iterable[str]]]=None,
                 sound:Optional[str]=None):
        self.key = key
        self.name = name
        self.desc = desc
        if name_equals is not None:
            self.name_eq = name_equals if isinstance(name_equals, list) else [name_equals]

            
        if num_equals is not None:
            self.num_eq = num_equals if isinstance(name_equals, list) else [num_equals] 

        if score_range is not None:
            self.score_down_limit = score_range[0]
            self.score_up_limit = score_range[1]

        if score_rank_range is not None:
            self.score_rank_down_limit = score_rank_range[0]
            self.score_rank_up_limit = score_rank_range[1]

        if highest_score_range is not None:
            self.highest_score_down_limit = highest_score_range[0]
            self.highest_score_up_limit =   highest_score_range[1]

        if lowest_score_range is not None:
            self.lowest_score_down_limit = lowest_score_range[0]
            self.lowest_score_up_limit =   lowest_score_range[1]

        if  highest_score_cause_range is not None:
            self.highest_score_cause_range_down_limit = highest_score_cause_range[0]
            self.highest_score_cause_range_up_limit =   highest_score_cause_range[1]
        
        if  lowest_score_cause_range is not None:
            self.lowest_score_cause_range_down_limit = lowest_score_cause_range[0]
            self.lowest_score_cause_range_up_limit =   lowest_score_cause_range[1]

        if modify_key_range is not None:
            self.modify_ranges_orig = modify_key_range if isinstance(modify_key_range, list) else [modify_key_range]
            self.modify_ranges = [{"key":item[0], "lowest":item[1], "highest":item[2]} for item in self.modify_ranges_orig]
        if others is not None:
            self.other = others

        self.got_sound = sound

    def got(self, student:Student):
        # 反人类写法又出现了
        if hasattr(self, "name_eq") and student.name not in self.name_eq:return False
        if hasattr(self, "num_eq") and student.num not in self.num_eq:return False
        if hasattr(self, "score_down_limit") and not self.score_down_limit <= student.score <= self.score_up_limit:return False
        try:
            if hasattr(self,"score_rank_down_limit"):
                lowest_rank = max(*([i[0] for i in class_obs.rank_dumplicate]))
                l = lowest_rank + self.score_rank_down_limit + 1 if self.score_rank_down_limit < 0 else self.score_rank_down_limit
                r = lowest_rank + self.score_rank_up_limit + 1 if self.score_rank_up_limit < 0 else self.score_rank_up_limit
                if not (l <= [i[0] for i in class_obs.rank_dumplicate if i[1].num == student.num][0] <= r):return False
        except:
            return False
        if hasattr(self, "highest_score_down_limit") and not self.highest_score_down_limit <= student.highest_score <= self.highest_score_up_limit:return False
        if hasattr(self, "highest_score_cause_range_down_limit") and not self.highest_score_cause_range_down_limit <= student.highest_score_cause_time <= self.highest_score_cause_range_up_limit:return False
        if hasattr(self, "lowest_score_down_limit") and not self.lowest_score_down_limit <= student.lowest_score <= self.lowest_score_up_limit:return False
        if hasattr(self, "lowest_score_cause_range_down_limit") and not self.lowest_score_cause_range_down_limit <= student.lowest_score_cause_time <= self.lowest_score_cause_range_up_limit:return False
        try:
            if hasattr(self, "modify_ranges") and not all([item["lowest"] <= [history.temp.key for history in student.history.values()].count(item["key"]) <= item["highest"] for item in self.modify_ranges]):return False
        except:
            return False
        if hasattr(self, "other") and not self.other(student):return False
        return True
    
    def condition_desc(self):
        return_str = ""
        if hasattr(self, "name_eq"):return_str += "仅适用于" + "，".join(self.name_eq) + "\n"
        if hasattr(self, "num_eq"):return_str += "仅适用于学号为" + "，".join(self.name_eq) + "的学生\n"
        if hasattr(self, "score_down_limit"):return_str += f"分数介于{self.score_down_limit}和{self.score_up_limit}之间\n"
        if hasattr(self, "score_tank_down_limit"):return_str += f"排名介于{('倒数' if self.score_rank_down_limit < 0 else '') + str(abs(self.score_rank_down_limit))}和{('倒数' if self.score_rank_up_limit < 0 else '') + str(abs(self.score_rank_up_limit))}之间\n"
        if hasattr(self, "highest_score_down_limit"):return_str += f"历史最高分介于{self.highest_score_down_limit}和{self.highest_score_up_limit}之间\n"
        if hasattr(self, "lowest_score_down_limit"):return_str += f"历史最低分数介于{self.lowest_score_down_limit}和{self.lowest_score_up_limit}之间\n"
        if hasattr(self, "modify_ranges"):
            for item in self.modify_ranges:
                return_str += f"达成{item['lowest']}到{item['highest']}次\"{modify_templates[item['key']].title}\""
        if return_str == "":return_str = "(无条件)"
        return return_str




        


class Achievement:
    def __init__(self, template:AchievementTemplate, target:StudentToSetInHistory, reach_time:str=None,reach_time_key:int=None):
        if reach_time is None:
            reach_time = gettime()
        if reach_time_key is None:
            reach_time_key = utc()
        if isinstance(target, Student):
            target = StudentToSetInHistory(target)
        log("I", f"新成就模板创建：target={repr(target)}, time={repr(reach_time)}, key={reach_time_key}")
        self.time = reach_time
        self.time_key = reach_time_key
        self.temp = template
        self.target = target
        self.play_sound = self.temp.got_sound

    def give(self):
        log("I", f"发放成就：target={repr(self.target)}, time={repr(self.time)}, key={self.time_key}")
        classes[self.target.belongs_to].students[self.target.num].achievements[self.time_key] = self

    def delete(self):
        log("I", f"删除成就：target={repr(self.target)}, time={repr(self.time)}, key={self.time_key}")
        del classes[self.target.belongs_to].students[self.target.name].achievements[self.time_key]




classes = DEFAULT_CLASSES


modify_templates:Dict[str, ScoreModificationTemplate] = {
    "go_to_school_early": ScoreModificationTemplate("go_to_school_early", 2.0, "7:20前到校", "提早到校的学生可以额外+2分"),
    "Chinese_homework_bad": ScoreModificationTemplate("Chinese_homework_bad", -2.0, "语文作业缺交/未写", "作业状况有待改进"),
    "Chinese_homework_good": ScoreModificationTemplate("Chinese_homework_good", 2.0, "语文作业A+", "作业优秀"),
    "math_homework_bad":   ScoreModificationTemplate("math_homework_bad", -2.0, "数学作业缺交/未写", "作业状况有待改进"),
    "math_homework_good":    ScoreModificationTemplate("math_homework_good",    2.0, "数学作业100", "作业优秀"),
    "English_reading_last_for_week":ScoreModificationTemplate("English_reading_last_for_week", -20.0, "英语背诵未完成", "孩子，该去背你的2b了！"),
    "English_homework_good": ScoreModificationTemplate("English_homework_good", 2.0, "英语作业A+", "作业优秀"),
    "physics_homework_bad": ScoreModificationTemplate("physics_homework_bad", -2.0, "物理作业缺交/未写", "作业状况有待改进"),
    "physics_homework_good": ScoreModificationTemplate("physics_homework_good", 2.0, "物理作业A", "作业优秀"),
    "physics_homework_best": ScoreModificationTemplate("physics_homework_best", 4.0, "物理作业A+", "\"这不有手就行吗？\""),
    "history_homework_good": ScoreModificationTemplate("history_homework_good", 2.0, "历史作业A+", "\"黄玲老师怎么突然变这么好？\""),
    "chemistry_homework_good": ScoreModificationTemplate("chemistry_homework_good", 2.0, "化学作业100", "作业优秀"),
    "laws_homework_good":    ScoreModificationTemplate("laws_homework_good", 2.0, "道法作业A+", "作业优秀"), # 为什么是laws？？
    "attendance_bad": ScoreModificationTemplate("attendance_bad", -1.0, "考勤待改进", "please思考你的人生"),
    "wearing_bad": ScoreModificationTemplate("wearing_bad", -1.0, "着装待改进", "cjsy的校服我爱死你个呜呜伯"),
    "reading_bad": ScoreModificationTemplate("reading_bad", -1.0, "早读批评", "不会开口的话建议学一下手语"),
    "eye_exercise_bad": ScoreModificationTemplate("eye_exercise_bad", -1.0, "眼操", "近视：亻尔 女子"),
    "wang_de_shen_pan":ScoreModificationTemplate("wang_de_shen_pan",ninf, "王の审判", "触怒了王")
}



achievememt_templates:Dict[str, AchievementTemplate] = {
    "beyond_life_and_death":AchievementTemplate("beyond_life_and_death", "超越生死", "经历了人生的大波折，我已看淡生死了",
                                                lowest_score_range=(ninf, -20),
                                                score_range=(1, inf),
                                                sound=SOUND_BRUH),

    
    "early_bird":AchievementTemplate("early_bird", "早起的鸟儿", "不用我说了",
                                                modify_key_range=[("go_to_school_early", 3, inf)],
                                                sound="res\\sounds\\orb.ogg"),
    
    "top_of_life":AchievementTemplate("top_of_life", "人生巅峰", "我无敌辣！", 
                                      score_range=(50, inf), score_rank_range=(1, 1),highest_score_range=(50, inf),
                                      sound="res\\sounds\\levelup.ogg",)


    }


def glide(_object, x1:int, y1:int, x2:int, y2:int, _time:int, frame:int=33):
    
    if frame != 0:
        fc = _time//frame
        fdx = (x2-x1)/fc
        fdy = (y2-y1)/fc
    else:
        fdx = fdy = 0
        fc = 0

    for i in range(fc):
        time.sleep(frame/1000)
        _object.place(x=(x1 + fdx*i), y=(y1 + fdy*i))
    _object.place(x=x2, y=y2)



def display_achievement(achievement:AchievementTemplate, student:Student):...    



class EditingError(Exception):"编辑列表出现错误"

class TemplateExistsError(EditingError):"模板已存在且无法覆盖"
class TemplateNotExistError(EditingError):"模板不存在"
class ClassNotExistError(EditingError):"班级不存在"
class ClassExistsError(EditingError): "班级已存在"
class StudentExistsError(EditingError):"学生已存在"
class StudentNotExistError(EditingError):"学生不存在"


def find_student(identifier:Union[int, str]=1, from_class:str="CLASS_1145") -> Student:
    "寻找学生。"
    global classes
    "from_class中找到一个匹配identifier（可以是学号或者名字）的人"
    log("D",f"在{from_class}中寻找{identifier}...","MainThread.find_student")
    try:
        real_class = classes[from_class]
    except KeyError:
        log("E",f"班级{from_class}不存在...","MainThread.find_student")
        raise ClassNotExistError(f"班级{from_class}不存在")
    if isinstance(identifier, int):
        log("D",f"尝试在{real_class}中寻找学号为{identifier}的学生...","MainThread.find_student")
        for k in real_class.students.keys():
            if real_class.students[k]._num == identifier:
                s = real_class.students[k]
                log("D",f"寻找到了该学生，信息：来自{real_class.name}(班主任：{real_class.owner})\n{str(s)}".replace("\n",", "),"MainThread.find_student")
                return s
        log("E","没有找到该学生...","Mainthread.find_student")
        raise StudentNotExistError("没有找到指定的学生")
    elif isinstance(identifier, str):
        log("D",f"尝试在{real_class}中寻找名称为{identifier}的学生...","MainThread.find_student")
        for k in real_class.students.keys():
            if real_class.students[k]._name == identifier:
                s = real_class.students[k]
                log("D",f"寻找到了该学生，信息：来自{real_class.name}(班主任：{real_class.owner})\n{str(s)}".replace("\n",", "),"MainThread.find_student")
                return s
        log("E","没有找到该学生...","find_student")
        raise StudentNotExistError("没有找到指定的学生")
    raise StudentNotExistError("传参错误")
    

def student_exists(identifier:Union[int, str]=1, from_class:str="CLASS_1145"):
    global classes
    log("I",f"尝试寻找{from_class}班里的{identifier}{'号' if isinstance(identifier, int) else ''}...",
        "MainThread.student_exists")
    try:
        find_student(identifier, from_class)
        return True
    except:
        return False



def log_exc(info:str="未知错误：", sender="MainThread -> Unknown"):
    "向控制台和日志报错。"
    log("E",f"{info}\n\t\t"+("\t"*2).join(str(traceback.format_exc()).splitlines(True)).strip(),sender)




def add_template(key:str="fly_in_class",title:str="在课堂上飞起来",modify:float=-114.0,description:str="此模板未提供详细信息...?",reason:str="创建原因未知") -> Union[Literal[True], TemplateExistsError, Exception]:
    "新建模板。"
    global modify_templates
    log("I",f"正在新建模板{key}, 原因：{reason}","MainThread.add_template")
    
    if key in modify_templates.keys():
        log("W",f"尝试覆盖已经存在的模板,key={key.__repr__()} :","MainThread.add_template")
        if modify_templates[key].cant_replace:
            log("E","尝试覆盖一个无法修改的模板,raise TemplateExistsError","MainThread.add_template")
            raise TemplateExistsError(f"模板\"{modify_templates[key].title}\"({key})被设置为无法替换!")
    try:
        modify_templates[key] = ScoreModificationTemplate(key, modify, title, description)
        log("I","新建成功","MainThread.add_template")
        return True
    except:
        log_exc("新建模板失败:","MainThread.add_template")
        raise


def del_template(key:str="go_to_school_early",reason:str="删除原因未知") -> Union[Optional[ScoreModificationTemplate], TemplateNotExistError, Exception]:
    "删除模板。"
    global modify_templates
    log("I",f"正在删除模板{key}, 原因：{reason}","MainThread.del_template")
    if key not in modify_templates.keys():
        log("W",f"模板{key}本就不存在, raise TemplateNotExistError","MainThread.del_template")
        raise TemplateNotExistError("模版本不存在，无需操作")
    if modify_templates[key].cant_replace:
            log("E","尝试覆盖一个无法修改的模板, raise TemplateExistsError","MainThread.del_template")
            raise TemplateExistsError(f"模板\"{modify_templates[key].title}\"({key})被设置为无法替换!")
    try:
        orig = modify_templates[key]
        del modify_templates[key]
        log("I",f"模板{key}删除完毕!","MainThread.del_template")
        return orig
    except:
        log_exc("新建模板失败:","MainThread.del_template")
        raise

def add_class(key:str="CLASS_1145", name:str="1145班", owner:str="王晶晶老师",
              students:Dict[int, Student]={},
              reason:str="创建原因未知") -> Union[bool, Exception]:
    "新建班级。"
    global classes
    log("I",f"正在新建班级{name}(所属老师{owner},标识符{key}), 原因：{reason}","MainThread.add_class")
    if key in classes.keys():
        log("E","指定的班级已存在!","MainThread.add_class")
        raise ClassExistsError(f"指定班级{name}已存在!(标识:{key})")
    try:
        classes[key] = Class(name, owner, students)
        log("I",f"班级{name}新建完毕!","MainThread.add_class")
        return True
    except:
        log_exc("新建班级失败:","MainThread.class")
        raise

def del_class(key:str="CLASS_1145",
              reason:str="删除原因未知") -> Union[Class, Exception]:
    "删除班级。"
    global classes
    class_orig = classes[key]
    log("I",f"正在删除班级(标识符{key}), 原因：{reason}","MainThread.del_class")
    
    if key not in classes.keys():
        log("E","指定的班级不存在,无需操作!","MainThread.del_class")
    try:
        del classes[key]
        log("I",f"班级{key}删除完毕!","MainThread.del_class")
        return class_orig
    except:
        log_exc("新建班级失败:","MainThread.del_class")
        raise

def add_student(name:str="acj",from_class:str="CLASS_1145",num:int=1,init_score:float=0.0,reason:str="创建原因未知") -> Union[Optional[bool], Exception]:
    "新建学生。"
    global classes
    log("I",f"正在新建学生{name}, 原因：{reason}","MainThread.add_student")
    if from_class not in classes.keys():
        log("E","指定的班级不存在!","MainThread.add_student")
        raise ClassNotExistError(f"指定班级{from_class}不存在!")
    if num in classes[from_class].students:
        log("E",f"指定学生{name}已存在!(学号{num}已占用)","MainThread.add_student")
        raise StudentExistsError(f"指定学生{name}已存在!(学号{num}已占用)")
    try:
        classes[from_class].students[num] = Student(name, num, init_score, from_class, {})
        log("I",f"学生{name}新建完毕!","MainThread.add_student")
        return True
    except:
        log_exc("新建学生失败:","MainThread.add_student")
        raise

def del_student(identifier:Union[str,int]=1,from_class:str="CLASS_1145",reason:str="删除原因未知") -> Union[Optional[Student], Exception]:
    "删除学生。"
    global classes
    log("I",f"正在删除学生{identifier}, 原因：{reason}","MainThread.del_student")
    try:
        stuobj = find_student(identifier,from_class)
    except:
        log("W","指定的学生不存在,无需操作!信息："+repr(sys.exc_info()[1]),"MainThread.del_student")
        return
    try:
        orig = classes[from_class].students[stuobj.num]
        del classes[from_class].students[stuobj.num]
        log("I",f"学生{stuobj.name}删除完毕!","MainThread.del_student")
        return orig
    except:
        log_exc("删除学生失败:","MainThread.del_student")
        raise



def save_data(path:str=f"chunks\\{current_user}\\classes.datas"):
    "保存当前存档。"
    log("I","保存数据到"+path+"...","MainThread.save_data")
    
    try:
        if not os.path.isdir(os.path.dirname(path)):
            p = os.path.dirname(path)
            os.makedirs(p)
        pickle.dump({
            "user": current_user,
            "time": time.time(),
            "version": VERSION,
            "version_code":VERSION_CODE,
            "classes":classes,
            "templates":modify_templates,
            "achievements":achievememt_templates
        },file=open(path, "wb"))
        b = open(path, "rb")
        b2 = base64.b85encode(b.read()) 
        b.close()
        b = open(path, "wb")    
        b.write(b2)
        b.close()
    except:
        log_exc("保存存档"+path+"失败：", "Mainthread.save_data")
        raise
    



def load_data(path:str=f"chunks\\{current_user}\\classes.datas") -> dict:
    "从文件加载存档。（只是返回数据！！）"
    log("I","从"+path+"加载数据...","MainThread.save_data")
    
    try:
        b = base64.b85decode(open(path, "r").read())
        f = open(path+".tmp", "wb")
        f.write(b)
        f.close()
        data = pickle.load(open(path+".tmp","rb"))
        os.remove(path+".tmp")
        return data
    
    except:
        log_exc("读取存档"+path+"失败：", "Mainthread.load_data")
        raise

def preload():
    try:
        try:
            s1 = open("data/preload/additions/achievements.py",encoding="utf-8").read()
            s2 = open("data/preload/additions/templates.py",encoding="utf-8").read()
        except:
            s1 = open("data/preload/additions/achievements.py",encoding="gbk").read()
            s2 = open("data/preload/additions/templates.py",encoding="gbk").read()
        g = globals()
        l = locals()
        exec(s1, g, l)
        exec(s2, g, l)
        for a in l:
            g[a] = l[a]
        for a in g["template_addition"]:
            modify_templates[a] = g["template_addition"][a]
        for a in g["achievement_addition"]:
            achievememt_templates[a] = g["achievement_addition"][a]
    except:
        tkinter.messagebox.showwarning(message=f"警告：加载additions出错:\n{traceback.format_exc()}\n部分模板可能丢失")



def read_ini(filepath:str="options.ini",encoding="utf-8",nospace:bool=True) -> Union[int,Dict[str,Union[bool,str]]]:
    "读取一个写满了<变量名>=<值>的文本文件然后返回一个字典"
    reading_file = open(filepath,encoding=encoding,mode="r",errors="ignore")
    content = reading_file.readlines()
    reading_file.close()
    if len(content) == 0:return {}
    output = {}
    for i in range(len(content)):
        try:
            line_setting = str(content[i]).split("=",2)
            prop = str(line_setting[0])   
            value = line_setting[1].split("\n",1)[0]
            if nospace:value = value.replace(" ","")
            if value.upper() == "FALSE":value = False
            if value.upper() == "TRUE":value = True
            output[prop]=value
        except:
            continue

    
    return output  


data = load_data()



classes = data["classes"]
modify_templates = data["templates"]
achievememt_templates = data["achievements"]


default_padx_1 = 20
default_padx_2 = 0
default_pady_1 = 20
default_pady_2 = 0

debug = True

font_options = read_ini("font_options.ini")
style = font_options["Text_style"]
size = int(font_options["Text_size"])
weight = font_options["Text_weight"]
slant = font_options["Text_slant"]
underline = int(font_options["Text_underline"])
overstrike = int(font_options["Text_overstrike"])

background_options = read_ini("background_options.ini")
color = background_options["color"]
attributes = background_options["attributes"]


gui_row = 0
gui_column = 0
buttons:Dict[int, Checkbutton] = {}
results:Dict[int, IntVar] = {}

def textview(text:str, title:str="文本窗口", master:Optional[Union[Tk, Toplevel]]=None, disable_master:bool=True,geometry:str="600x420"):
    if master is not None and disable_master:master.attributes("-disabled", 1)
    font = tkFont.Font(family=style, size=10, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
    root = Toplevel(master) if master is not None else Tk()
    root["bg"] = color
    root.title(title)
    root.geometry(geometry)
    view = tk.Text(root,width=999,height=50,wrap="none",font=font,)
    view.pack(side=tk.LEFT, fill=tk.BOTH)
    sb = tk.Scrollbar(root, command=view.yview)
    sb.pack(side=tk.RIGHT, fill=tk.Y)
    view.insert(tk.END, text)
    view.see(tk.END)
    view.config(state="disabled")

    flag = 1
    try:
        master.lift()
    except:
        pass
    while flag:
        try:
            root.update()
            if not root.winfo_exists():
                flag = 0 
        except:
            break
    if master is not None and disable_master:master.attributes("-disabled", 0);master.lift()


def canbe(value, _class:type):
    "检查一个数据是否能作为另一个类型，比如can_be(\"11.4514\",float) == True"
    try:
        _class(value)
        return True
    except:
        return False

def error_msgbox(errormsg:str):
    tkinter.messagebox.showerror(message=errormsg)



def display_achievement(achievement:AchievementTemplate, student:Student):
    skip = 0
    try:
        label = Button(stu_window, text=f"{student.name} 达成了成就 [{achievement.name}]  (点击跳过)", width=50, height=3)
    except:pass
    try:
        label2 = Button(main_class_window, text=f"{student.name} 达成了成就 [{achievement.name}]  (点击跳过)", width=50, height=3)
    except:pass
    stu_screen_x = int(screen_width/1920*840/2-250) 
    stu_screen_y = int(screen_height/1080*560)
    cls_screen_x = int(screen_width/1920*1360/2-300)
    cls_screen_y = int(screen_height/1080*740)
    try:
        label.grid(row=114, column=514)
    except:pass
    try:
        label2.grid(row=1919, column=810)
    except:pass

    def setskip():
        nonlocal skip
        skip = 1
        try:
            label.destroy()
        except:pass
        try:
            label2.destroy()
        except:pass
        

    try:
        label.config(command=setskip)
    except:pass
    try:
        label2.config(command=setskip)
    except:pass
    try:glide(label, stu_screen_x, stu_screen_y+50, stu_screen_x, stu_screen_y-35, 126, 5)
    except:pass
    if achievement.got_sound is not None:play_sound(achievement.got_sound)
    try:glide(label2, cls_screen_x, cls_screen_y+50, cls_screen_x, cls_screen_y-75, 125, 5)
    except:pass
    i = 0
    try:
        while i <= 30 and not skip:
            i += 1
            if skip:break
            time.sleep(0.1)
    except:pass
    try:
        if label.winfo_exists() and label2.winfo_exists():glide(label, stu_screen_x, stu_screen_y-35, stu_screen_x, stu_screen_y+100, 750, 25)
    except:pass
    try:
        if label2.winfo_exists() and label2.winfo_exists():glide(label2, cls_screen_x, cls_screen_y-75, cls_screen_x, cls_screen_y+100, 750, 25)
    except:pass
    try:label.destroy()
    except:pass
    try:label2.destroy()
    except:pass



nl = "\n"
def _stuselector_update_checkbox(student:Student,var:int):
    log("D",f"更新选中状态：{StudentToSetInHistory(student).__repr__()} = {results[var].get().__repr__()}", "MainThread.update_checkbox")


_stuselect_result = []
_stusel_finished = False

def stu_selector(target_class:Class, master:Optional[Union[Tk, Toplevel]]=None) -> None:
    "byd你tkinter你tm阻塞mainloop就算了为什么不让我用threading"
    if master is not None:
        master.attributes('-disabled', 1)
    target_class = classes[target_class.key]
    global buttons, results
    global _stusel_finished
    _stusel_finished = False
    log("I","启动学生选择器","class_window.stu_selector")
    sw = tk.Toplevel(main_class_window)
    sw.title(target_class.name)
    sw.geometry(f"{int(screen_width/1920*1360)}x{int(screen_height/1080*480)}+{int(screen_height/1080*320)}+{int(screen_height/1080*180)}")
    sw["bg"] = color
    sw.attributes("-alpha", attributes)
    i = 0
    for num in list(target_class.students.keys()):
        results[num] = tk.IntVar(sw)
        buttons[num] = tk.Checkbutton(sw, 
                                text=f"{target_class.students[num]._num}:{target_class.students[num]._name}\n{target_class.students[num]._score}分",
                                width=10, height=2,
                              variable=results[num],
                                command=(lambda s=target_class.students[num], v=num:_stuselector_update_checkbox(s,v)))

    max_column = 10
    padx = (10, 0)
    pady = (20, 0)
    for num in buttons:
        buttons[num].grid(row=int(i/max_column), column=i%max_column, padx=padx, pady=pady)
        i += 1
    def _select_all():
        log("I","全选项目","class_window.stu_selector.select_all")
        for num in buttons:
            if not results[num].get():
                buttons[num].toggle()

    def _select_none():
        log("I","清空选择项目","class_window.stu_selector.select_none")
        for num in buttons:
            if results[num].get():
                buttons[num].toggle()

    def _select_opposite():
        log("I","反选项目","class_window.stu_selector.select_opposite")
        for num in buttons:
            buttons[num].toggle()      

    Button() 
    def _selector_ok():
        global _stusel_finished
        global _stuselect_result
        _stuselect_result = []
            
        for i in buttons:
            if results[i].get():
                _stuselect_result.append(target_class.students[i])
        log("I",f"选择完成，列表：\n -> {nl+' -> '.join([repr(StudentToSetInHistory(s)) for s in _stuselect_result])}","class_window.stu_selector.selector_ok")
        if len(_stuselect_result) == 0:
            log("I","列表长度为0，重新选择","class_window.stu_selector.selector_ok")
            error_msgbox("请至少选择一项")
            return
        _stusel_finished = True
        sw.destroy()
        if master is not None:
            master.attributes('-disabled', 0)
    
        
    
    def _selector_cancel():
        global _stusel_finished
        global _stuselect_result
        _stuselect_result = []
        log("I","取消选择","class_window.stu_selector.selector_cancel")
        _stusel_finished = True
        sw.destroy()
        if master is not None:
            master.attributes('-disabled', 0)
            
    
    tk.Button(sw, text="确认", 
                       width=10, height=2, command=_selector_ok).grid(
                           row=i//max_column+2,column=1,padx=(10,10),pady=(10,10))
    tk.Button(sw, text="全选",
                        width=10, height=2, command=_select_all).grid(
                            row=i//max_column+2,column=2,padx=(10,10),pady=(10,10))
    tk.Button(sw, text="反选",
                        width=10, height=2, command=_select_opposite).grid(
                            row=i//max_column+2,column=3,padx=(10,10),pady=(10,10))
    tk.Button(sw, text="清空",
                        width=10, height=2, command=_select_none).grid(
                            row=i//max_column+2,column=4,padx=(10,10),pady=(10,10))
    tk.Button(sw, text="取消",
                        width=10, height=2, command=_selector_cancel).grid(
                            row=i//max_column+2,column=5,padx=(10,10),pady=(10,10))
    
    flag = 1
    while flag:
        try:
            sw.update()
            if not sw.winfo_exists():
                flag = 0 
            sw.lift()
        except:
            break
    if master is not None:master.attributes('-disabled', 0);master.lift()
    return _stuselect_result
    


class SendModifyError(ModifyingError):"发送点评出现错误"
def send_modify(key:str="fly_in_class",
                send_to:Union[List[Student], Student]=[],
                extra_title:Optional[str]=None,
                extra_desc:Optional[str]=None,
                extra_mod:Optional[Union[float]]=None,):
    if not isinstance(send_to, list):
        send_to = [send_to]
    if send_to == []:send_to = [None]
    if send_to == [None]:
        log("W","传参为[None]，疑似初始化，return","MainThread.send_modify")
        return
    if key is None:
        log("W","key为None，疑似模板选择时取消，return","MainThread.send_modify")
        return
    log("I",f"开始发送点评\n模板： {modify_templates[key].__repr__()}\n发送至：\n---------------------","MainThread.send_modify")
    succeed = []
    for stu in send_to:
        a = ScoreModification(modify_templates[key], stu, extra_title, extra_desc, extra_mod)
        success = a.execute()
        if not success:
            for m in succeed:
                m.retract()
            raise SendModifyError("向学生"+repr(StudentToSetInHistory(stu))+"发送点评出现错误，本组点评已撤回")
        log("I", f"对象 -> {repr(StudentToSetInHistory(stu))}")
        succeed.append(a)

    log("I", f"---------------------\n发送完成，总数:{len(send_to)}","MainThread.send_modify")


_stuselect_result:List[Student]
results = {}
buttons = {}

his_window:Tk
his_window_in_use:bool = False




sb:Scrollbar
lb:Listbox
tmp_root:Toplevel
main_class_window:Tk



def history_list_window(student:Student, master:Optional[Union[Tk, Toplevel]]=None):
    global sb, lb
    global his_window_in_use, tmp_root
    if master is not None:master.attributes('-disabled', 1)
    student = classes[student.belongs_to].students[student.num]
    tmp_root = Toplevel(stu_window)
    tmp_root.title(f"点评记录列表 - {student.name}")
    tmp_root.geometry(f"{int(screen_width/1920*550)}x{int(screen_height/1080*800)}+{int(screen_height/1080*200)}+{int(screen_height/1080*160)}")
    sb = Scrollbar(tmp_root, orient="vertical")
    sb.pack(side="right", fill="y")
    datas = {}
    log("I", f"加载{repr(StudentToSetInHistory(student))}的历史数据记录","history_list_window")
    def history_select(button:Event):
        nonlocal datas
        s = lb.curselection()[0]
        history = datas[s][1]
        log("I", f"选择的对象：{history}")
        history_window(history, s, tmp_root)

    lb = Listbox(tmp_root, yscrollcommand=sb.set, width=45)
    lb.pack(side="left", fill="both")
    index = 0
    
    for history in reversed(list(classes[student.belongs_to].students[student.num].history)):
        event = "<Double-Button>"
        lb.bind(event, history_select)
        lb.insert("end", f"{student.history[history].title} {student.history[history].execute_time.rsplit('.', 1)[0]} {student.history[history].mod:+.1f} ")
        datas[index] = (index, classes[student.belongs_to].students[student.num].history[history])
        index += 1
  


    Button(tmp_root, text="返回顶部", command=lambda:lb.see(0)).pack(fill="x")
    Button(tmp_root, text="滚动至底部", command=lambda:lb.see("end")).pack(fill="x")

    
    sb.config(command=lb.yview)
    flag = 1
    while flag:

        try:
            tmp_root.update()
            sb.update()
            lb.update()
            if not tmp_root.winfo_exists():
                flag = 0 
        except:
            
            break
    log("I", "窗口关闭","history_list_window")
    if master is not None:master.attributes('-disabled', 0);master.lift()



sb2:Scrollbar
lb2:Listbox
tmp_root:Toplevel

def tmplate_list_window(tmps:Union[Dict[str, ScoreModificationTemplate], 
                                   List[ScoreModificationTemplate]], 
                        master:Optional[Union[Tk, Toplevel]]=None):
    global sb2, lb2
    global his_window_in_use, tmp_root
    if master is not None:master.attributes('-disabled', 1)
    log("I", "加载模板列表","template_list_window")
    if isinstance(tmps, list):
        tmps = dict(zip(range(len(tmps)), tmps))
    tmp_root = Toplevel(master)
    tmp_root.title("模板列表")
    tmp_root.geometry(f"{int(screen_width/1920*550)}x{int(screen_height/1080*800)}"
                      f"+{int(screen_height/1080*200)}+{int(screen_height/1080*160)}")
    sb2 = Scrollbar(tmp_root, orient="vertical")
    sb2.pack(side="right", fill="y")
    datas = {}
    def tmp_select(button:Event):
        nonlocal datas
        try:
            s = lb2.curselection()[0]
            tmp = datas[s][1]
            index_2 = datas[s][0]
            log("I", f"选择的对象：{repr(tmp)}({index_2}, {tmp.title})")
            template_editor(tmp.key, index_2, tmp_root)
        except:pass
    lb2 = Listbox(tmp_root, yscrollcommand=sb2.set, width=45)
    lb2.pack(side="left", fill="both")
    index = 0
    for i in reversed(list(tmps)):
        event = "<Double-Button>"
        lb2.bind(event, tmp_select)
        lb2.insert("end", f"{tmps[i].title}")
        datas[index] = (index, tmps[i])
        index += 1


    Button(tmp_root, text="返回顶部", command=lambda:lb2.see(0)).pack(fill="x")
    Button(tmp_root, text="滚动至底部", command=lambda:lb2.see("end")).pack(fill="x")

    
    sb2.config(command=lb2.yview)
    flag = 1
    while flag:

        try:
            tmp_root.update()
            sb2.update()
            lb2.update()
            if not tmp_root.winfo_exists():
                flag = 0 
        except:
            break
    log("I", "窗口关闭","template_list_window")
    if master is not None:master.attributes('-disabled', 0);master.lift()


sb3:Scrollbar
lb3:Listbox


def student_list_window(stus:Union[Dict[str, Student], 
                                   List[Student]], 
                        master:Optional[Union[Tk, Toplevel]]=None):
    global sb3, lb3
    global stu_rank_root
    if master is not None:master.attributes('-disabled', 1)
    if isinstance(stus, list):
        stus = dict(zip(range(len(stus)), stus))
    stu_rank_root = Toplevel(master)
    stu_rank_root.title("学生排名")
    stu_rank_root.geometry(f"{int(screen_width/1920*550)}x{int(screen_height/1080*800)}"
                      f"+{int(screen_height/1080*200)}+{int(screen_height/1080*160)}")
    stu_list = stus.values()
    stu_list = sorted(stu_list, key=lambda s:s.score, reverse=True)
    stu_list2:List[Tuple[int, Student]] = [] 
    last = inf
    last_ord = 0
    cur_ord = 0
    for stu in stu_list:
        cur_ord += 1
        if stu.score == last:
            _ord = last_ord
        else:
            _ord = cur_ord
            last_ord = cur_ord
        stu_list2.append((_ord, stu))
        last = stu.score
    
        
    sb3 = Scrollbar(stu_rank_root, orient="vertical")
    sb3.pack(side="right", fill="y")
    stu_rank_root.lift()
    datas = {}
    def stu_select(button:Event):
        nonlocal datas
        s = lb3.curselection()[0]
        stu = datas[s][1]
        index_2 = datas[s][0]
        log("I", f"选择的对象：{repr(StudentToSetInHistory(stu))}({index_2})")
        student_window(stu, stu_rank_root)

    lb3 = Listbox(stu_rank_root, yscrollcommand=sb3.set, width=45, height=15)
    lb3.pack(side="left", fill="both")
    index = 0
    for i in stu_list2:
        event = "<Double-Button>"
        lb3.bind(event, stu_select)
        lb3.insert("end", f"第{i[0]}名 {i[1].name} {i[1].score}分")
        datas[index] = (index, i[1])
        index += 1


    Button(stu_rank_root, text="返回顶部", command=lambda:lb3.see(0)).pack(fill="x")
    Button(stu_rank_root, text="滚动至底部", command=lambda:lb3.see("end")).pack(fill="x")

    
    sb3.config(command=lb3.yview)
    flag = 1
    while flag:

        try:
            stu_rank_root.update()
            sb3.update()
            lb3.update()
            if not stu_rank_root.winfo_exists():
                flag = 0 
        except:
            break
    if master is not None:master.attributes('-disabled', 0);master.lift()


sb4:Scrollbar
lb4:Listbox
ach_root:Toplevel



def achievement_list_window(student:Student, master:Optional[Union[Tk, Toplevel]]=None):
    global sb4, lb4
    if master is not None:master.attributes('-disabled', 1)
    student = classes[student.belongs_to].students[student.num]
    ach_root = Toplevel(stu_window)
    ach_root.title(f"达成成就列表 - {student.name}")
    ach_root.geometry(f"{int(screen_width/1920*550)}x{int(screen_height/1080*800)}+{int(screen_height/1080*200)}+{int(screen_height/1080*160)}")
    sb4 = Scrollbar(ach_root, orient="vertical")
    sb4.pack(side="right", fill="y")
    datas = {}
    log("I", f"加载{repr(StudentToSetInHistory(student))}的成就数据记录","achievement_list_window")
    def achievement_select(button:Event):
        nonlocal datas
        s = lb4.curselection()[0]
        achievement = datas[s][1]
        log("I", f"选择的对象：{achievement}","achievement_list_window.achievement_select")
        achievement_window(achievement, s, ach_root)

    lb4 = Listbox(ach_root, yscrollcommand=sb4.set, width=45)
    lb4.pack(side="left", fill="both")
    index = 0
    
    for achievement in reversed(list(classes[student.belongs_to].students[student.num].achievements)):
        event = "<Double-Button>"
        lb4.bind(event, achievement_select)
        lb4.insert("end", classes[student.belongs_to].students[student.num].achievements[achievement].temp.name)
        datas[index] = (index, classes[student.belongs_to].students[student.num].achievements[achievement])
        index += 1


    Button(ach_root, text="返回顶部", command=lambda:lb4.see(0)).pack(fill="x")
    Button(ach_root, text="滚动至底部", command=lambda:lb4.see("end")).pack(fill="x")

    
    sb4.config(command=lb4.yview)
    flag = 1
    while flag:

        try:
            ach_root.update()
            sb4.update()
            lb4.update()
            if not ach_root.winfo_exists():
                flag = 0 
        except:
            
            break
    log("I", "窗口关闭","achievement_list_window")
    if master is not None:master.attributes('-disabled', 0);master.lift()


def achievement_window(achievement:Union[AchievementTemplate, Achievement], listbox_index:int, master:Optional[Union[Toplevel, Tk]]=None):
    if master is not None:master.attributes('-disabled', 1)
    global sb4, lb4
    exec_time = 0
    if isinstance(achievement, Achievement):
        exec_time = achievement.time
        target = achievement.target
        achievement = achievement.temp
    log("I", "选中成就（模板）："+repr(achievement),"MainThread.achievement_window")
    if his_window_in_use and ach_window.winfo_exists():
        log("I", "当前已存在窗口，强制置为最前窗口，his_window.lift()","MainThread.achievement_window")
        ach_window.lift()
    else:
        log("I", "当前不存在窗口，his_window = Toplevel(master)","MainThread.achievement_window")
        ach_window = Toplevel(master)
    ach_window.title(f"成就记录 - {achievement}, {achievement.name} ({listbox_index})")
    ach_window.geometry(f"{int(screen_width/1920*480)}x{int(screen_height/1080*260)}+{int(screen_height/1080*320)}+{int(screen_height/1080*150)}")
    ach_window["bg"] = color
    ach_window.attributes("-alpha", attributes)
    l1=tk.Label(ach_window, text="名称", width=16)
    l2=tk.Label(ach_window, text="描述", width=16)
    l4=tk.Label(ach_window, text="对象", width=16)
    l11=tk.Label(ach_window, text="达成时间", width=16)
    l1.grid(row=0, column=0, padx=(5,0), pady=(5,0))
    l2.grid(row=1, column=0, padx=(5,0), pady=(5,0))
    l4.grid(row=2, column=0, padx=(5,0), pady=(5,0))
    l11.grid(row=3, column=0, padx=(5,0), pady=(5,0))
    l6=tk.Label(ach_window, text=achievement.name, width=16)
    l6.grid(row=0, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l7=tk.Label(ach_window, text=achievement.desc, width=16)
    l7.grid(row=1, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    real_stu = classes[target.belongs_to].students[target.num]
    l8=tk.Label(ach_window, text=str(real_stu), width=16)
    l8.grid(row=2, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l9=tk.Label(ach_window, text=(exec_time if exec_time != 0 else "无数据"), width=16)
    l9.grid(row=3, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    def detail(key:AchievementTemplate):
        textview(key.condition_desc(), "达成条件", ach_window)

    Button(ach_window, text="查看详细", width=8, height=2, command=lambda k=achievement:detail(k)).grid(row=6,column=0,pady=(20,0),padx=(20,0))

    flag = 1
    while flag:
        try:
            ach_window.update()
            if not ach_window.winfo_exists():
                flag = 0 
        except:
            break
    if master is not None:master.attributes('-disabled', 0);master.lift()



def set_entry(e:Entry, s):
        e.delete(0,"end");e.insert(0, str(s))

def template_editor(template:Union[ScoreModificationTemplate, str],
                    listbox_index:int,
                    master:Optional[Union[Toplevel]]=None):
    if master is not None:master.attributes('-disabled', 1)
    if isinstance(template, ScoreModificationTemplate):
        key = template.key
    else:
        key = template
    tmp = modify_templates[key]
    
    tmp_edit_window = Toplevel(master) if master is not None else Tk()
    tmp_edit_window.title("模板修改")
    tmp_edit_window.geometry(f"{int(screen_width/1920*600)}x{int(screen_height/1080*340)}+{int(screen_height/1080*200)}+{int(screen_height/1080*160)}")


    Label(tmp_edit_window, text="名称", width=12).grid(row=0, column=0, padx=(5,0), pady=(5,0))
    l6=Entry(tmp_edit_window, text=tmp.title)
    l6.grid(row=0, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    

    Label(tmp_edit_window, text="描述", width=12).grid(row=1, column=0, padx=(5,0), pady=(5,0))
    l7=Entry(tmp_edit_window, text=str(tmp.desc))
    l7.grid(row=1, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))


    Label(tmp_edit_window, text="分数", width=12).grid(row=2, column=0, padx=(5,0), pady=(5,0))
    l8=Entry(tmp_edit_window, text=str(tmp.mod))
    l8.grid(row=2, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))

    Label(tmp_edit_window, text="标识符", width=12).grid(row=3, column=0, padx=(5,0), pady=(5,0))
    l9=Label(tmp_edit_window, text=tmp.key, width=16)
    l9.grid(row=3, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))

    def _template_save_ok():
        global modify_templates
        title = l6.get()
        desc = l7.get()
        mod = l8.get()
        if not title.strip():log("I", "未输入标题，请求重新输入","template_editor");error_msgbox("请输入标题");tmp_edit_window.lift()
        if not mod.strip():log("I", "未输入分数，请求重新输入","template_editor");error_msgbox("请输入分数");tmp_edit_window.lift()
        res = ScoreModificationTemplate(key, float(mod), title, desc)
        log("I", f"保存中：{repr(res)}")
        modify_templates[key] = res
        tmp_edit_window.destroy()

    def _template_save_cancel():
        tmp_edit_window.destroy()

    def _reset_entry(e:Entry, s):e.delete(0,"end");e.insert(0, str(s))

    def _template_delete():
        tmp_edit_window.attributes('-disabled', 1)
        log("I", "询问是否删除...","template._template_delete")
        if tkinter.messagebox.askokcancel("警告", "接下来将会删除该模板。\n是否继续？"):
            try:
                del_template(template, "用户删除")
            except:pass
            lb2.delete(listbox_index, listbox_index)
            lb2.insert(listbox_index, "（已删除）")
            print(listbox_index)
            tmp_edit_window.destroy()
        else:
            tmp_edit_window.lift()
        try:tmp_edit_window.attributes('-disabled', 0)
        except:pass
        

    _reset_entry(l6, tmp.title)
    _reset_entry(l7, tmp.desc)
    _reset_entry(l8, tmp.mod)
    Button(tmp_edit_window, text="保存", command=_template_save_ok).grid(row=4, column=1, columnspan=2, padx=(10,0), pady=(5,0))
    Button(tmp_edit_window, text="删除", command=_template_delete).grid(row=4, column=2, columnspan=2, padx=(10,0), pady=(5,0))
    Button(tmp_edit_window, text="取消", command=_template_save_cancel).grid(row=4, column=3, columnspan=2, padx=(10,0), pady=(5,0))
    Button(tmp_edit_window, text="重置", command=lambda:_reset_entry(l6, tmp.title), width=4).grid(row=0, column=3, columnspan=2, padx=(10,0), pady=(5,0))
    Button(tmp_edit_window, text="重置", command=lambda:_reset_entry(l7, tmp.desc), width=4).grid(row=1, column=3, columnspan=2, padx=(10,0), pady=(5,0))
    Button(tmp_edit_window, text="重置", command=lambda:_reset_entry(l8, tmp.mod), width=4).grid(row=2, column=3, columnspan=2,  padx=(10,0), pady=(5,0))

    66
    last = ""
    flag = 1
    while flag:
        try:
            tmp_edit_window.update()
            c = l8.get()
            if (not canbe(c, float)) and c not in ("", "-") or abs(float((0 if c in  ("", "-") else c))) > 1145141919810: 
                l8.delete(0, "end")
                l8.insert(0, last)
            last = l8.get()
            if not tmp_edit_window.winfo_exists():
                flag = 0 
        except:
            break
    log("I", "窗口关闭","template_editor")
    if master is not None:master.attributes('-disabled', 0);master.lift()

    


    
    




tmpsel_result:str
def send_template_selector(tmplist:Union[dict,list]=modify_templates, master:Optional[Union[Tk, Toplevel]]=None
                      ) -> Tuple[Optional[str], str, str, str]:
    global tmpsel_result
    if master is not None:master.attributes('-disabled', 1)
    if isinstance(tmplist, list):
        tmplist = dict(zip(range(len(tmplist)), tmplist))
    root = Toplevel(master)
    tmpsel_result = ""
    root.geometry(f"{int(screen_width/1920*800)}x{int(screen_height/1080*230)}+{int(screen_height/1080*300)}+{int(screen_height/1080*180)}")
    root.title("请选择模板")
    varlist = []
    count = 0
    for temp in tmplist:
        count += 1
        varlist.append(f"[{count}] {tmplist[temp].title}")
    box = ttk.Combobox(root, values=tuple(varlist))
    box.grid(row=0, column=0, padx=(5,0), pady=(5,0))
    box.set(varlist[0])
    def tmpsel_update(string):
        log("D", F"更新选项：{string}")
        temp = modify_templates[list(tmplist)[int(box.get().split('[')[1].split(']')[0])-1]]
        set_entry(e1, temp.title)
        set_entry(e2, temp.desc)
        set_entry(e3, str(temp.mod))
    box.bind("<<ComboboxSelected>>", lambda e:tmpsel_update(box.get()))
    def tmpsel_ok():
        global tmpsel_result
        log("I", f"选择的对象：{box.get()}, 对应key:{list(tmplist)[int(box.get().split('[')[1].split(']')[0])-1]}")
        tmpsel_result = list(tmplist)[int(box.get().split("[")[1].split("]")[0])-1]
        root.destroy()
        if master is not None:master.attributes('-disabled', 0);master.lift()
    temp = modify_templates[list(tmplist)[int(box.get().split('[')[1].split(']')[0])-1]]

    tk.Label(root, text="修改原因", width=7).grid(row=2, column=0, padx=(5,0), pady=(5,0))
    tk.Label(root, text="修改描述", width=7).grid(row=3, column=0, padx=(5,0), pady=(5,0))
    tk.Label(root, text="修改分数", width=7).grid(row=4, column=0, padx=(5,0), pady=(5,0))
    e1 = Entry(root)
    e2 = Entry(root)
    e3 = Entry(root)
    set_entry(e1, temp.title)
    set_entry(e2, temp.desc)
    set_entry(e3, str(temp.mod))
    e1.grid(row=2, column=1, padx=(5,0), pady=(5,0), ipadx=150)
    e2.grid(row=3, column=1, padx=(5,0), pady=(5,0), ipadx=150)
    e3.grid(row=4, column=1, padx=(5,0), pady=(5,0), ipadx=150)
    

    
    Button(root, text="完成", command=tmpsel_ok).grid(row=5,column=0)
    flag = 1
    last_choice = varlist[0]
    while flag:
        try:
            v1 = e1.get()
            v2 = e2.get()
            v3 = e3.get()
            
            if ((not canbe(v3, float)) and v3 not in ("", "-")) or abs(float((0 if v3 in  ("", "-") else v3))) > 1145141919810: 
                e3.delete(0, "end")
                e3.insert(0, last)
            last = e3.get()
            root.update() 
            if box.get() not in varlist:
                box.set(last_choice)
            last_choice = box.get()
            if not root.winfo_exists():
                flag = 0 
        except:
            break
    if master is not None:master.attributes('-disabled', 0);master.lift()
    return tmpsel_result if tmpsel_result else None, (v1 if v1.strip() else None), (v2 if v2.strip() else None), (float(v3) if (v3.strip() and canbe(v3, float)) else None)
    


def history_window(modify:ScoreModification, listbox_index:int, master:Optional[Union[Toplevel, Tk]]=None):
    if master is not None:master.attributes('-disabled', 1)
    global sb2, lb2
    global his_window
    global his_window_in_use
    log("I", "选中模板："+modify.__repr__(),"MainThread.history_window")
    if his_window_in_use and his_window.winfo_exists():
        log("I", "当前已存在记录窗口，强制置为最前窗口，his_window.lift()","MainThread.history_window")
        his_window.lift()
    else:
        log("I", "当前不存在记录窗口，his_window = Toplevel(master)","MainThread.history_window")
        his_window = Toplevel(master)
    his_window.title(f"点评记录 - {modify.target.name}, {modify.title} ({listbox_index})")
    his_window.geometry(f"{int(screen_width/1920*480)}x{int(screen_height/1080*260)}+{int(screen_height/1080*320)}+{int(screen_height/1080*150)}")
    his_window["bg"] = color
    his_window.attributes("-alpha", attributes)
    l1=tk.Label(his_window, text="原因", width=16)
    l2=tk.Label(his_window, text="描述", width=16)
    l3=tk.Label(his_window, text="分数", width=16)
    l4=tk.Label(his_window, text="对象", width=16)
    l11=tk.Label(his_window, text="创建时间", width=16)
    l12=tk.Label(his_window, text="执行状态", width=16)
    l1.grid(row=0, column=0, padx=(5,0), pady=(5,0))
    l2.grid(row=1, column=0, padx=(5,0), pady=(5,0))
    l3.grid(row=2, column=0, padx=(5,0), pady=(5,0))
    l4.grid(row=3, column=0, padx=(5,0), pady=(5,0))
    l11.grid(row=4, column=0, padx=(5,0), pady=(5,0))
    l12.grid(row=5, column=0, padx=(5,0), pady=(5,0))
    l6=tk.Label(his_window, text=modify.title, width=16)
    l6.grid(row=0, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l7=tk.Label(his_window, text=str(modify.desc), width=16)
    l7.grid(row=1, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l8=tk.Label(his_window, text=str(modify.mod), width=16)
    l8.grid(row=2, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    real_stu = classes[modify.target.belongs_to].students[modify.target.num]
    l9=tk.Label(his_window, text=f"{str(real_stu)}", width=16)
    l9.grid(row=3, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l01=tk.Label(his_window, text=str(modify.execute_time), width=16)
    l01.grid(row=4, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l02=tk.Label(his_window, text=(f"执行于{modify.execute_time}" if modify.executed else "未执行"), width=16)
    l02.grid(row=5, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    def retract(key:str):
        global his_window_in_use
        log("I", "撤回当前点评...")
        exec_time = modify.execute_time
        title = modify.title
        classes[modify.target.belongs_to].students[modify.target.num].history[key].retract()
        his_window_in_use = False
        lb.delete(listbox_index, listbox_index)
        lb.insert(listbox_index, f"{title} {exec_time.rsplit('.', 1)[0]} {modify.mod:+.1f} （已撤回）")
        his_window.destroy()
        if master is not None:master.attributes('-disabled', 0);master.lift()

    b1 = tk.Button(his_window, text="撤回点评", width=8, height=2, command=lambda k=modify.execute_time_key:retract(k))
    if not modify.executed:
        b1.config(state=DISABLED)
    b1.grid(row=6,column=0,pady=(20,0))
    his_window_in_use = True
    flag = 1
    while flag:
        try:
            his_window.update()
            if not his_window.winfo_exists():
                flag = 0 
        except:
            break
    his_window_in_use = False
    if master is not None:master.attributes('-disabled', 0);master.lift()



def add_new_template(master:Optional[Union[Tk, Toplevel]]=None):
        if master is not None:master.attributes('-disabled', 1)
        template_window = Toplevel(master) if master != None else Tk()
        main_window_font = tkFont.Font(family=style, size=size, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
        template_window["bg"] = color
        template_window.title("创建新模板")
        template_window.geometry(f"{int(screen_width/1920*500)}x{int(screen_height/1080*160)}+{int(screen_height/1080*320)}+{int(screen_height/1080*150)}")
        template_window.attributes("-alpha", attributes)
        label_title = tk.Label(template_window, text="模板名称", width=12, font=main_window_font)
        label_modify = tk.Label(template_window, text="分数", width=12, font=main_window_font)
        label_desc = tk.Label(template_window, text="模板描述", width=12, font=main_window_font)
        entry_title = tk.Entry(template_window)
        entry_modify = tk.Entry(template_window)
        entry_desc = tk.Entry(template_window)
        label_title.grid(row=0, column=0, padx=(5,0), pady=(5,0))
        label_modify.grid(row=2, column=0, padx=(5,0), pady=(5,0))
        label_desc.grid(row=3, column=0, padx=(5,0), pady=(5,0))
        entry_title.grid(row=0, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
        entry_modify.grid(row=2, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
        entry_desc.grid(row=3, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
        
        def createtmp_ok():
            global var_desc,var_modify,var_title
            var_title = entry_title.get()
            var_modify = entry_modify.get()
            var_desc = entry_desc.get()
            if var_title.strip() == "":
                error_msgbox("标题不能为空")
                template_window.lift()
                return
            if not var_desc.strip():
                var_desc = None
            if not canbe(var_modify, float):
                error_msgbox("请输入分数")
                template_window.lift()
                return
            elif abs(float(var_modify)) > 1145141919810:
                error_msgbox("分数过大可能造成精度丢失，请重新输入")
                template_window.lift()
                return
            var_modify = float(var_modify)
            add_template(f"userset_{utc()}", var_title, var_modify, var_desc, "用户创建")
            template_window.destroy()

        def createtmp_cancel():
            template_window.destroy()
        
            

        b1 = tk.Button(template_window, text="确认", width=8, height=2, command=createtmp_ok)
        b2 = tk.Button(template_window, text="取消", width=8, height=2, command=createtmp_cancel)
        b1.grid(row=5,column=0,pady=(20,0))
        b2.grid(row=5,column=2,pady=(20,0))
        flag = 1
        last = ""
        while flag:
            try:
                template_window.update()
                c = entry_modify.get()
                if ((not canbe(c, float)) and c not in  ("", "-")) or abs(float((0 if c in  ("", "-") else c))) > 1145141919810: 
                    entry_modify.delete(0, "end")
                    entry_modify.insert(0, last)
                last = entry_modify.get()
                if not template_window.winfo_exists():
                    flag = 0 
            except:
                break
        if master is not None:master.attributes('-disabled', 0);master.lift()







def log_window(master:Optional[Union[Tk, Toplevel]]=None):
    
    global log_scr
    try:
        master.lift()
    except:
        pass
    font = tkFont.Font(family=style, size=10, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
    log_root = Toplevel(master) if master is not None else Tk()
    log_root["bg"] = color
    log_root.title("日志")
    log_root.geometry(f"{int(screen_width/1920*1400)}x{int(screen_height/1080*700)}")
    log_scr = tk.Text(log_root,width=999,height=50,wrap="none",font=font,)
    log_scr.pack(side=tk.LEFT, fill=tk.BOTH)
    log_scr.config(state="disabled")
    sb = tk.Scrollbar(log_root, command=log_scr.yview)
    sb.pack(side=tk.RIGHT, fill=tk.Y)
    flag = 1
    try:
        master.lift()
    except:
        pass
    while flag:
        try:
            log_root.update()
            if not log_root.winfo_exists():
                flag = 0 
        except:
            break




stu_window:Tk
stu_window_in_use = False
def student_window(student:Student, master:Optional[Union[Tk, Toplevel]]=None):
    global stu_window
    global stu_window_in_use
    if master is not None:master.attributes('-disabled', 1)
    log("I", "选中学生："+str(StudentToSetInHistory(student).__repr__()),"MainThread.student_window")
    if stu_window_in_use and stu_window.winfo_exists():
        log("I", "当前已存在学生窗口，强制置为最前窗口，stu_window.lift()","MainThread.student_window")
        stu_window.lift()
    else:
        log("I", "当前不存在学生窗口，stu_window = Toplevel(master)","MainThread.student_window")
        stu_window = Toplevel(master)
    stu_window.title(f"学生信息 - {student.name}")
    stu_window.geometry(f"{int(screen_width/1920*840)}x{int(screen_height/1080*600)}+{int(screen_height/1080*320)}+{int(screen_height/1080*150)}")
    stu_window["bg"] = color
    stu_window.attributes("-alpha", attributes)
    l1=tk.Label(stu_window, text="学生名", width=16)
    l2=tk.Label(stu_window, text="学号", width=16)
    l3=tk.Label(stu_window, text="当前分数", width=16)
    l4=tk.Label(stu_window, text="所属班级", width=16)
    l5=tk.Label(stu_window, text="最高/低分", width=16)
    l1.grid(row=0, column=0, padx=(5,0), pady=(5,0))
    l2.grid(row=1, column=0, padx=(5,0), pady=(5,0))
    l3.grid(row=2, column=0, padx=(5,0), pady=(5,0))
    l4.grid(row=3, column=0, padx=(5,0), pady=(5,0))
    l5.grid(row=4, column=0, padx=(5,0), pady=(5,0))
    tk.Label(stu_window, text="历史总分", width=16).grid(row=5, column=0, padx=(5,0), pady=(5,0))

    l6=tk.Label(stu_window, text=student.name, width=12)
    l6.grid(row=0, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l7=tk.Label(stu_window, text=str(student.num), width=12)
    l7.grid(row=1, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l8=tk.Label(stu_window, text=str(student.score), width=12)
    l8.grid(row=2, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l9=tk.Label(stu_window, text=str(classes[student.belongs_to].name), width=12)
    l9.grid(row=3, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l10=tk.Label(stu_window, text=f"{student.highest_score:.1f}/{student.lowest_score:.1f}", width=12)
    l10.grid(row=4, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    l11=tk.Label(stu_window, text=str(student.total_score), width=16)
    l11.grid(row=5, column=1, columnspan=2, ipadx=80, padx=(10,0), pady=(5,0))
    

    def stu_window_viewach():
        stu_window.attributes('-disabled', 1)
        achievement_list_window(student, master=stu_window)
        stu_window.attributes('-disabled', 0)
        stu_window.lift()
        

    def stu_window_sendmodify():
        key = send_template_selector(master=stu_window)
        if key is not None:
            log("I", f"向当前学生（{student.name}）发送点评...")
            send_modify(key[0], student, key[1], key[2], key[3])
    
        

    def stu_window_history():
        log("I", f"加载当前学生（{student.name}）的历史记录...")
        history_list_window(student, stu_window)


    b1 = tk.Button(stu_window, text="历史记录", width=8, height=2, command=stu_window_history)
    b2 = tk.Button(stu_window, text="发送点评", width=8, height=2, command=stu_window_sendmodify)
    b3 = tk.Button(stu_window, text="成就记录", width=8, height=2, command=stu_window_viewach)
    b1.grid(row=7,column=0,pady=(20,0),padx=(20,20))
    b2.grid(row=7,column=2,pady=(20,0),padx=(20,20))
    b3.grid(row=7,column=1,pady=(20,0),padx=(20,20))

    stu_window_in_use = True
    flag = 1
    while flag:
        try:
            # classes[student.belongs_to].students[student.num]取的是地址而不是新的object，这样就能实时监测更新了
            stu = classes[student.belongs_to].students[student.num]
            l6.config(text=classes[student.belongs_to].students[student.num].name, width=16)
            l7.config(text=str(classes[student.belongs_to].students[student.num].num), width=16)
            l8.config(text=str(classes[student.belongs_to].students[student.num].score), width=16)
            l9.config(text=str(classes[classes[student.belongs_to].students[student.num].belongs_to].name), width=16)
            l10.config(text=f"{student.highest_score:.1f}/{student.lowest_score:.1f}", width=16)
            l11.config(text=str(stu.total_score))
            stu_window.update()
            if not stu_window.winfo_exists():
                flag = 0 
        except:
            break
    stu_window_in_use = False
    if master is not None:master.attributes('-disabled', 0);master.lift()

    


def class_window(target_class:Class=classes["CLASS_1145"]):
    global results, buttons
    global color, attributes, _stuselect_result
    global style, size, weight, slant, underline, overstrike
    global main_class_window
    global class_obs, achievement_obs
    class_obs = StatusObserver.ClassStatusObserver(target_class.key)
    class_obs.start()   # 一定要先开class_obs，因为achievememt_obs要用到
    achievement_obs = StatusObserver.AchievementStatusObserver(target_class.key)
    achievement_obs.start()
    

    main_class_window = Tk()
    main_window_font = tkFont.Font(family=style, size=size, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
    main_class_window.title("班级管理")
    main_class_window.geometry(F"{int(screen_width/1920*1360)}x{int(screen_height/1080*760)}+{int(screen_height/1080*220)}+{int(screen_height/1080*180)}")
    main_class_window["bg"] = color
    main_class_window.attributes("-alpha", attributes)
    
    student_fr = LabelFrame(main_class_window, text="本班学生", border=4)
    student_fr.grid(sticky="e", row=1, column=1, padx=(10,10), pady=(10,10))
    classstat_fr = LabelFrame(main_class_window, text="班级信息")
    classstat_fr.grid(row=1, column=2, padx=(10,10), pady=(10,10), sticky="nw")
    lb_classname = Label(classstat_fr, text="班级名称", width=20, height=2, font=tkFont.Font(family=style, size=12))
    lb_classname.pack(fill="x")
    lb_classown = Label(classstat_fr, text="班主任", width=20, height=2, font=tkFont.Font(family=style, size=12))
    lb_classown.pack(fill="x")
    lb_totalscore = Label(classstat_fr, text="总分", width=20, height=2, font=tkFont.Font(family=style, size=12))
    lb_totalscore.pack(fill="x")

    window_menu_bar = tk.Menu(main_class_window, font=main_window_font)
    
    view_menu = tk.Menu(window_menu_bar, tearoff=0)
    
    def add_points():
        student = stu_selector(target_class, main_class_window)
        if len(student):
            key = send_template_selector(master=main_class_window)
            if key is not None:
                send_modify(key[0], student, key[1], key[2], key[3])
    
    operate_menu = tk.Menu(window_menu_bar, tearoff=0)
    window_menu_bar.add_cascade(label="操作", menu=operate_menu, font=main_window_font)
    operate_menu.add_command(label="新建加分模板", command=lambda:add_new_template(main_class_window))
    operate_menu.add_command(label="模板管理", command=lambda:tmplate_list_window(modify_templates,main_class_window))
    operate_menu.add_command(label="发送点评", command=add_points)

    window_menu_bar.add_cascade(label="视图", menu=view_menu, font=main_window_font)
    view_menu.add_command(label="小组视图", command=lambda:None)
    view_menu.add_command(label="班级排名", command=lambda:student_list_window(classes[target_class.key].students, main_class_window))
    view_menu.add_command(label="日志菜单", command=lambda:log_window(main_class_window))



    labels:Dict[int, Button] = {}
    i = 0
    for num in target_class.students:
        labels[num]  = Button(student_fr, 
                                 text=f"{target_class.students[num]._num}:{target_class.students[num]._name}\n{target_class.students[num]._score}分", 
                                width=10, height=3, command=lambda a=num:student_window(target_class.students[a], main_class_window))
    max_row = 10
    padx = (10,0)
    pady = (20,0)
    for num in labels:
        labels[num].grid(row=i//max_row, column=i%max_row, padx=padx, pady=pady)
        i+=1
    main_class_window.config(menu=window_menu_bar)
    def update_class_window():
        try:
            for num in classes[target_class.key].students:
                lb_classname.config(text=f"班级名称：{classes[target_class.key].name}")
                lb_classown.config(text=f"班主任：{classes[target_class.key].owner}")
                lb_totalscore.config(text=f"总分：{sum([s.score for s in classes[target_class.key].students.values()])}")
                labels[num].config(text=f"{classes[target_class.key].students[num].num}:{classes[target_class.key].students[num].name}\n{classes[target_class.key].students[num].score}分")
                labels[num].update()
            main_class_window.after(100,update_class_window)
        except:
            return
    main_class_window.after(100,update_class_window)
    main_class_window.mainloop()

    



def main_gui():
    main_window = tk.Tk()
    main_window_font = tkFont.Font(family=style, size=size, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
    main_window.title("常规分工具")
    main_window.geometry(f"{int(screen_width/1920*480)}x{int(screen_height/1080*240)}+{int(screen_height/1080*120)}+{int(screen_height/1080*130)}")
    main_window["bg"] = color
    main_window.attributes("-alpha", attributes)

    menu_bar = tk.Menu(main_window, font=main_window_font)

    file_menu = tk.Menu(menu_bar, tearoff=0)
    edit_menu = tk.Menu(menu_bar, tearoff=0)
    settings_menu = tk.Menu(menu_bar, tearoff=0)

    menu_bar.add_cascade(label="文件", menu=file_menu, font=main_window_font)
    menu_bar.add_cascade(label="编辑", menu=edit_menu, font=main_window_font)
    menu_bar.add_cascade(label="设置", menu=settings_menu, font=main_window_font)


    # second_file_menu = tk.Menu(file_menu)
    # second_edit_menu = tk.Menu(edit_menu)
    # second_settings_menu = tk.Menu(settings_menu)
    file_menu.add_command(label="创建新班级")
    main_window.config(menu=menu_bar)
    def __jump():
        preload()
        main_window.destroy()
        class_window()
   
    class_1145 = tk.Button(main_window, text="1145班", width=12, height=3, font=main_window_font, command=__jump)
    class_1145.grid(row=0, column=0, padx=(20,0), pady=(20,0))
    main_window.mainloop()



main_gui()

save_data()
try:
    achievement_obs.stop()
    class_obs.stop()
except:pass








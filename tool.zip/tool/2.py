import tkinter as tk
import random
from tkinter import messagebox
import time
import threading
window = tk.Tk()
window.title('my window')
##窗口尺寸
window.geometry('400x350')
#新建画布
b = tk.Button(window, text="点我", command=quit)
b.pack()

def glide(_object, x1:int, y1:int, x2:int, y2:int, _time:int, frame:int=33):
    
    if frame != 0:
        fc = _time//frame
        fdx = (x2-x1)/fc
        fdy = (y2-y1)/fc
    else:
        fdx = fdy = 0
        fc = 0


    for i in range(fc):
        time.sleep(frame/1000)
        _object.place(x=(x1 + fdx*i), y=(y1 + fdy*i))
    _object.place(x=x2, y=y2)

def main():
    time.sleep(0.4)
    glide(b, 0, 0, 300, 300, 500, 1)
a = threading.Thread(target=main)
a.start()
tk.mainloop()



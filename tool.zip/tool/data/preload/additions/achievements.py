# 附加成就
# 提示：
# def __init__(self,     
#                  key:str,
#                  name:str,
#                  desc:str,                           
#                  # 满足以下所有条件才会给成就
#                  name_equals:Optional[Union[str, Iterable[str]]]=None,   # 名称等于/在列表中
#                  num_equals:Optional[Union[str, Iterable[str]]]=None,    # 学号等于/在列表中
#                  score_range:Optional[Tuple[float, float]]=None,         # 分数范围
#                  score_rank_range:Optional[Tuple[int, int]]=None,       # 名次范围（不计算并列的，名词按1-2-2-3-3之类计算）
#                  highest_score_range:Optional[Tuple[float, float]]=None, # 最高分数范围
#                  lowest_score_range:Optional[Tuple[float, float]]=None,  # 最低分数范围
#                  highest_score_cause_range:Optional[Tuple[int, int]]=None, # 最高分产生时间的范围（utc，*1000）
#                  lowest_score_cause_range:Optional[Tuple[int, int]]=None,  # 最低分产生时间的范围
#                  modify_key_range:Optional[Union[Tuple[str, int, int], Iterable[Tuple[str, int, int]]]]=None,          # 指定点评次数的范围（必须全部符合o）
#                  others:Optional[Union[str, Iterable[str]]]=None,
#                  sound:Optional[str]=None)
# 
achievement_addition = {
}
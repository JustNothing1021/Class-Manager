# 附加模板
# 提示：
# def __init__(self, key:str, modification:float, title:str, description:str="该加减分模板没有详细信息。", cant_replace:bool=False)

template_addition = {
    "test": ScoreModificationTemplate("test", ninf, "测试", "测试"),
}
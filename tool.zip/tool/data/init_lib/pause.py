import os
def pause():
    os.system("pause > nul")
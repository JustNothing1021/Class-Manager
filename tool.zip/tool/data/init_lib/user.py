import os
os.system("whoami > user.txt")
file = open('user.txt','r',encoding='utf-8')
line = file.readline()
file.close()
user_list = line.split("\\")
os.system("del user.txt")
user_name_computer = user_list[0]
user_name_default = user_list[-1]
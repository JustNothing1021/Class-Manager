import time
from lunardate import LunarDate
from datetime import datetime
import csv


today = time.strftime("%Y/%m/%d",time.localtime())
today_without_year = time.strftime("%m%d",time.localtime())
today_time = time.strftime("%H:%M:%S",time.localtime()) # 公历日期

def convert_solar_to_lunar(year,month,day): # 定义一个公历日期转农历日期的函数
    solar_date = datetime(year,month,day)
    lunar_date = LunarDate.fromSolarDate(solar_date.year,solar_date.month,solar_date.day)
    return lunar_date


solar_year = int(time.strftime("%Y",time.localtime())) # 公历日期:年
solar_month = int(time.strftime("%m",time.localtime())) # 公历日期:月
solar_day = int(time.strftime("%d",time.localtime())) # 公历日期:日


lunar_date = convert_solar_to_lunar(solar_year,solar_month,solar_day)


list_of_lunar_date = str(lunar_date).split('(')[-1].split(')')[0].split(',')[0:-1]


lunar_year = list_of_lunar_date[0]


lunar_month = list_of_lunar_date[1]
lunar_month = str(lunar_month.split(' ')[-1]).zfill(2)


lunar_day = list_of_lunar_date[-1]
lunar_day = str(lunar_day.split(' ')[-1]).zfill(2)

solar_month = str(solar_month)
solar_day = str(solar_day)

solar_year = str(solar_year)
solar_month = str(solar_month.split(' ')[-1]).zfill(2)
solar_day = str(solar_day.split(' ')[-1]).zfill(2)

solar_date = solar_year + '/' + solar_month + '/' + solar_day
lunar_date = lunar_year + '/' + lunar_month + '/' + lunar_day
from os import system
def system_custom(x):
    x = '"' + x + '"'
    system(x)
import os
def cls():
    os.system("cls")
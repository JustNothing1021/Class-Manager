
the_class_1145 = "CLASS_1145"
the_owner_to_the_class_1145 = "王晶晶老师"


default_padx_1 = 20
default_padx_2 = 0

default_pady_1 = 20
default_pady_2 = 0


options = open("options.ini", "r", encoding="utf-8")
options_lines = options.readlines()
options.close()
options_list = [line.strip() for line in options_lines]

debug = options_lines[0]



font_options = open("font_options.ini" ,"r" ,encoding="utf-8" )
font_lines = font_options.readlines()
font_options.close()
font_options_list = [line.strip() for line in font_lines]

font_list = [l.split("=")[-1] for l in font_options_list[0:48]]
style = font_list[0]
size = font_list[1]
weight = font_list[2]
slant = font_list[3]
underline = font_list[4]
overstrike = font_list[5]


background_options = open("background_options.ini" ,"r" ,encoding="utf-8" )
background_lines = background_options.readlines()
background_options.close()
background_options_list = [line.strip() for line in background_lines]

color = background_options_list[0].split("=")[-1]
attributes = background_options_list[1].split("=")[-1]


class_1145_gui_location = open("data\\class\\class_1145\\location.cfg", "r", encoding="utf-8")
class_1145_gui_location_lines = class_1145_gui_location.readlines()
class_1145_gui_location.close()
class_1145_gui_location_list = [line.strip() for line in class_1145_gui_location_lines]

class_1145_gui_location_about_the_row = int(class_1145_gui_location_list[0].split("=")[-1])
class_1145_gui_location_about_the_column = int(class_1145_gui_location_list[1].split("=")[-1])
class_1145_gui_location_about_the_padx = class_1145_gui_location_list[2].split("=")[-1]
class_1145_gui_location_about_the_pady = class_1145_gui_location_list[3].split("=")[-1]


the_student_name = open("data\\class\\class_1145\\names_of_students", "r", encoding="utf-8")
the_student_name_lines = the_student_name.readlines()
the_student_name.close()
the_student_name_list = [line.strip() for line in the_student_name_lines]


the_sudents_of_the_class_1145_about_names = [l.split("=")[-1] for l in the_student_name_list[0:48]]

the_student_number = open("data\\class\\class_1145\\numbers_of_students", "r", encoding="utf-8")
the_student_number_lines = the_student_number.readlines()
the_student_number.close()
the_student_number_list = [line.strip() for line in the_student_number_lines]


the_sudents_of_the_class_1145_about_numbers = [l.split("=")[-1] for l in the_student_number_list[0:48]]


the_class_1145_student_number_and_name = []
for i in range(len(the_sudents_of_the_class_1145_about_names)):
    the_class_1145_student_number_and_name.append(the_sudents_of_the_class_1145_about_numbers[i] + ':' + the_sudents_of_the_class_1145_about_names[i])




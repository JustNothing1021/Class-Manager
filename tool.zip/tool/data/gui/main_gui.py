from data.init_lib.call_library import *
from data.init_lib.variable import *
from data.init_lib.init_lib import *

def main_gui():
    main_window = tk.Tk()
    main_window_font = tkFont.Font(family=style, size=size, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
    main_window.title("常规分工具")
    main_window.geometry("1440x810+240+130")
    main_window["bg"] = color
    main_window.attributes("-alpha", attributes)

    menu_bar = tk.Menu(main_window, font=main_window_font)

    file_menu = tk.Menu(menu_bar, tearoff=0)
    edit_menu = tk.Menu(menu_bar, tearoff=0)
    settings_menu = tk.Menu(menu_bar, tearoff=0)

    menu_bar.add_cascade(label="文件", menu=file_menu, font=main_window_font)
    menu_bar.add_cascade(label="编辑", menu=edit_menu, font=main_window_font)
    menu_bar.add_cascade(label="设置", menu=settings_menu, font=main_window_font)


    second_file_menu = tk.Menu(file_menu)
    second_edit_menu = tk.Menu(edit_menu)
    second_settings_menu = tk.Menu(settings_menu)

    file_menu.add_command(label="创建新班级")


    main_window.config(menu=menu_bar)


    class_1145 = tk.Button(main_window, text="1145班", width=8, height=4, font=main_window_font, command=class1145)
    class_1145.grid(row=0, column=0, padx=(20,0), pady=(20,0))






    main_window.mainloop()
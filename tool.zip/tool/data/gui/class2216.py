from data.init_lib.call_library import tk,tkFont
from data.init_lib.variable import style,size,slant,underline,weight,overstrike,color,attributes


def class1145():
    class1145_window = tk.Tk()
    main_window_font = tkFont.Font(family=style, size=size, weight=weight, slant=slant, underline=underline, overstrike=overstrike)
    class1145_window.title("1145班")
    class1145_window.geometry("1280x720+320+180")
    class1145_window["bg"] = color
    class1145_window.attributes("-alpha", attributes)
    
    
    class1145_window_menu_bar = tk.Menu(class1145_window, font=main_window_font)
    
    
    operate_menu = tk.Menu(class1145_window_menu_bar, tearoff=0)
    
    
    class1145_window_menu_bar.add_cascade(label="操作", menu=operate_menu, font=main_window_font)
    
    operate_menu.add_command(label="新建加分模板")


    class1145_window.config(menu=class1145_window_menu_bar)
    
    
    class1145_window.mainloop()


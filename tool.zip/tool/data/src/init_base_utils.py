from src.init_data import *
from src.log import log_path_format as log_path_formatter


"最基本的函数，基于Python"


SCRIPT_FILE_NAME = f"script:{__name__}"

def exist(filepath:str) -> bool: # 提前写了
    "判定文件存不存在，存在就输出True，不然就是False"
    if filepath.startswith("\"") and filepath.endswith("\""):
        filepath = filepath[1:][0:-1]
    return os.path.exists(filepath)

def list_tree(path:str=cwd,build_base_dir=False) -> Tuple[str]: # os.walk: ?不是哥们
    "列举出一个文件夹下的所有文件。"
    dirs = []
    if not path.endswith("\\"):
        path += "\\"
    if build_base_dir:
        base_dir_out = path
    else:
        base_dir_out = ""
    base_dir = path
    items = []
    all_list = os.listdir(path)
    while True:
        if dirs == []:
            for item in all_list:
                if os.path.isdir(base_dir+item+"\\"):
                    dirs.append(item+"\\")
                if os.path.isfile(base_dir+item):
                    items.append(base_dir_out+item)
        tmp_dirs = []
        for iterating_dir in dirs:
            if not len(os.listdir(base_dir+iterating_dir)): # 目录是空的：直接加入
                items.append(base_dir_out+iterating_dir)
                continue
            for item in os.listdir(base_dir+iterating_dir):
                if os.path.isdir(base_dir+iterating_dir+item+"\\"):
                    tmp_dirs.append(iterating_dir+item+"\\")
                if os.path.isfile(base_dir+iterating_dir+item):
                    items.append(base_dir_out+iterating_dir+item)
        dirs = tmp_dirs        
        if dirs == []:
            return tuple(items)


def get_variable(varname:str,name:str="__main__"):
    "获得全局变量"
    return sys.modules[name].__dict__[varname]

def get_variable_to_dict(name:str="__main__"):
    "根据字典获得全局变量"
    return sys.modules[name].__dict__
    
def set_variable(varname:str,val,name:str="__main__"):
    "设置全局变量"
    sys.modules[name].__dict__[varname] = val


def set_variables_from_dict(dict:dict,name:str="__main__"):
    "根据字典设置全局变量"
    for key in dict.keys():
        set_variable(key,dict[key],name)



def setvar_toutils(varname:str,val):
    "直接对一个变量进行几乎对所有utils模块生效的设置"
    set_variable(varname,val)
    set_variable(varname,val,"src.init_data")
    set_variable(varname,val,"src.init_base_utils")
    set_variable(varname,val,"src.init_cmd_utils")
    set_variable(varname,val,"src.init_utils")
    set_variable(varname,val,"src.boot")

def setvar_toall(varname:str,val):
    "暴力全局"
    options = get_variable("options")
    if varname in options.keys():
        update_options({},"add",varname,val)
    setvar_toutils(varname,val)

def split_line(*text:Optional[str],color_style:str=info_color,width=console.width):
    "显示一条分割线"
    output_text = ""
    for index in text:
        output_text += index
    if output_text == "":
        console.print(Rule("",style=color_style[1:][0:-1],align="right",characters=rule_character),width=width)
    else:   
        console.print(Rule(f"{color_style}{output_text}",style=color_style[1:][0:-1],characters=rule_character),width=width)

def get_time() -> str:
    "获取时间"
    local_time = time.localtime()
    time_float = str(int((time.time()%1)*1000))

    return f"{local_time.tm_year}/{str(local_time.tm_mon).zfill(2)}/{str(local_time.tm_mday).zfill(2)}_{str(local_time.tm_hour).zfill(2)}:{str(local_time.tm_min).zfill(2)}:{str(local_time.tm_sec).zfill(2)}.{str(time_float).zfill(3)}"

starttime = time.time()
starttime_str = get_time()

def pause(showtext:Union[bool,str]=True):
    "暂停，可以选择有没有文本提示或者自定义文本提示（因为真的不想打一大串指令了）"
    if showtext == True:
        console.print(f"{pause_color}（按任意键继续）")
    elif showtext != False:
        console.print(f"{pause_color}{showtext}")
    os.system("pause > nul")


def get_saving_name():
    "也是获取时间，但是是作为所记录的日志名的"
    local_time = time.localtime()
    return f"{local_time.tm_year}_{str(local_time.tm_mon).zfill(2)}_{str(local_time.tm_mday).zfill(2)}_{str(local_time.tm_hour).zfill(2)}_{str(local_time.tm_min).zfill(2)}_{str(local_time.tm_sec).zfill(2)}"                  







def read_variable_file(filepath:str=OPTIONS_FILE_NAME, 
                       _progress:Tuple[str,Optional[Progress]]=("global",progress),
                       stagename:str=None, 
                       stagepercent:tuple=100, 
                       removespace:bool=True,
                       writeinlog:bool=True,
                       globalprogressrange:tuple=(-1,-1),
                       starttotaltask=None,
                       encoding="gbk") -> Union[int,Dict[str,Union[bool,int,str]]]:
    "读取一个写满了<变量名>=<值>的文本文件然后返回一个字典"
    if showstartcompletedpercent:
        if _progress[0] == "local":
            with progress:
                total_task = progress.add_task(stagename,total=100)
                read_file_task = progress.add_task(f"{desc_color}寻找文件",total=100)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:开始读取...")
                if exist(filepath):
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:打开文件：%s..."%filepath)
                    reading_file = open(filepath,encoding=encoding,mode="r",errors=UnicodeDecodeError_Handle)
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:读取文件...")
                    content = reading_file.readlines()
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:关闭文件...")
                    reading_file.close()
                    progress.update(read_file_task,advance=100)
                    if len(content) == 0:
                        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:此文件可能是空文件，将会返回-1")
                        return -1
                    percentperline = (stagepercent)/len(content)
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:设置每行的占比：%s"%(percentperline))
                    output = {}
                    progress.remove_task(read_file_task)
                    progress.advance(total_task,40)
                    parse_task = progress.add_task(f"{desc_color}分析数据")
                    for i in range(len(content)):
                        progress.advance(total_task,percentperline*0.6)
                        progress.advance(parse_task,percentperline)
                        line_setting = content[i]
                        line_setting = str(line_setting)
                        line_setting = line_setting.split("=",2)
                        if len(line_setting) >= 2:
                            prop = str(line_setting[0])                       
                            value = line_setting[1]
                            value = value.split("\n",1)                       
                            value = value[0]                                
                        else:
                            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:该行[第%s行]格式不正确，跳过"%(i+1))
                            continue
                        if removespace == True:
                            value = value.split(" ",1)[0]

                        if value in ("false","False"):value = False
                        if value in ("True","true"):value = True
                        output [prop] = value
                        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:设置字典中的项目：%s:%s"%(prop,value))
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:顺利完成！")
                    progress.remove_task(total_task)
                    progress.remove_task(parse_task)
                    return(output)
                else:
                    progress.remove_task(total_task)
                    progress.remove_task(read_file_task)
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"readvariablefile:指定的文件[%s]不存在..."%(filepath))
                    return -1
                
        elif _progress[0] == "global":
                if stagename is None:stagename = f"{info_color}读取{filepath}"
                total_task = _progress[1].add_task(stagename,total=100)
                read_file_task = _progress[1].add_task(f"{desc_color}寻找文件",total=100)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:开始读取...")
                if exist(filepath):
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:打开文件：%s..."%filepath)
                    reading_file = open(filepath,encoding=encoding,mode="r")
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:读取文件...")
                    content = reading_file.readlines()
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:关闭文件...")
                    reading_file.close()
                    _progress[1].update(read_file_task,advance=100)
                    if len(content) == 0:
                        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:此文件可能是空文件，将会返回-1")
                        return -1
                    percentperline = (stagepercent)/len(content)
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:设置每行的占比：%s"%(percentperline))
                    output = {}
                    _progress[1].remove_task(read_file_task)
                    _progress[1].advance(total_task,40)
                    parse_task = _progress[1].add_task(f"{desc_color}分析数据")
                    if starttotaltask is None:
                        global start_total_task
                    else:
                        start_total_task = starttotaltask

                    for i in range(len(content)):
                        if globalprogressrange != (-1,-1):
                            _progress[1].update(start_total_task,completed=(globalprogressrange[0]+((i+1)/len(content))*(globalprogressrange[1]-globalprogressrange[0])))
                        _progress[1].advance(parse_task,percentperline)
                        _progress[1].advance(total_task,percentperline*0.6)
                        line_setting = content[i]
                        line_setting = str(line_setting)
                        line_setting = line_setting.split("=",2)
                        if len(line_setting) >= 2:
                            prop = str(line_setting[0])                       
                            value = line_setting[1]
                            value = value.split("\n",1)                       
                            value = value[0]                                
                        else:
                            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:该行[第%s行]格式不正确，跳过"%(i+1))
                            continue
                        if removespace == True:
                            value = value.split(" ",1)[0]

                        if value in ("false","False"):value = False
                        if value in ("True","true"):value = True
                        output [prop] = value
                        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:设置字典中的项目：%s:%s"%(prop,value))
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:顺利完成！")
                    _progress[1].remove_task(total_task)
                    _progress[1].remove_task(parse_task)
                    return(output)
                else:
                    _progress[1].remove_task(total_task)
                    _progress[1].remove_task(read_file_task)
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"readvariablefile:指定的文件[%s]不存在..."%(filepath))
                    return -1
        else:

            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:开始读取...")
            if exist(filepath):
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:打开文件：%s..."%filepath)
                reading_file = open(filepath,encoding=encoding,mode="r",errors=UnicodeDecodeError_Handle)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:读取文件...")
                content = reading_file.readlines()
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:关闭文件...")
                reading_file.close()
                if len(content) == 0:
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:此文件可能是空文件，将会返回-1")
                    return -1
                percentperline = (stagepercent)/len(content)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:设置每行的占比：%s"%(percentperline))
                output = {}
                for i in range(len(content)):
                    line_setting = content[i]
                    line_setting = str(line_setting)
                    line_setting = line_setting.split("=",2)
                    if len(line_setting) >= 2:
                        prop = str(line_setting[0])                       
                        value = line_setting[1]
                        value = value.split("\n",1)                       
                        value = value[0]                                
                    else:
                        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:该行[第%s行]格式不正确，跳过"%(i+1))
                        continue
                    if removespace == True:
                        value = value.split(" ",1)[0]

                    if value in ("false","False"):value = False
                    if value in ("True","true"):value = True
                    output [prop] = value
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:设置字典中的项目：%s:%s"%(prop,value))
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:顺利完成！")
                return(output)
            else:
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"readvariablefile:指定的文件[%s]不存在..."%(filepath))
                return -1
        
                
    else:

            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:开始读取...")
            if exist(filepath):
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:打开文件：%s..."%filepath)
                reading_file = open(filepath,encoding=encoding,mode="r",errors=UnicodeDecodeError_Handle)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:读取文件...")
                content = reading_file.readlines()
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:关闭文件...")
                reading_file.close()
                if len(content) == 0:
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:此文件可能是空文件，将会返回-1")
                    return -1
                percentperline = (stagepercent)/len(content)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:设置每行的占比：%s"%(percentperline))
                output = {}
                for i in range(len(content)):
                    line_setting = content[i]
                    line_setting = str(line_setting)
                    line_setting = line_setting.split("=",2)
                    if len(line_setting) >= 2:
                        prop = str(line_setting[0])                       
                        value = line_setting[1]
                        value = value.split("\n",1)                       
                        value = value[0]                                
                    else:
                        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,-2,"readvariablefile:该行[第%s行]格式不正确，跳过"%(i+1))
                        continue
                    if removespace == True:
                        value = value.split(" ",1)[0]

                    if value in ("false","False"):value = False
                    if value in ("True","true"):value = True
                    output [prop] = value
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:设置字典中的项目：%s:%s"%(prop,value))
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,0,"readvariablefile:顺利完成！")
                return(output)
            else:
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"readvariablefile:指定的文件[%s]不存在..."%(filepath))
                return -1
        



        


def write_variable_file(optionsict:dict,defaultstarttext:str="null",outputfile:str=OPTIONS_FILE_NAME,encoding="gbk"):
    "给定一个字典，将字典中的内容以<属性名>=<值>写到指定文件里面，返回值是配置文档的长度"
    writing_file = open(outputfile,mode="w+",encoding=encoding,errors=UnicodeDecodeError_Handle)
    if defaultstarttext == "null":                   # 没有给定开头的参数时留空列表
        writelist = []
    else:
        writelist = ['%s\n'%defaultstarttext]               # 给了的话就把输入的东西作为列表的第一项
    looptime = 0
    for i in optionsict.keys():
            prop = str(i)
            value = str(optionsict[i])
            content = str("%s=%s\n"%(prop,value))
            writelist.append(str(content))
            looptime+=1
    writing_file.writelines(writelist)
    writing_file.close()
    return looptime


def write_textfile(path:StrOrBytesPath,text:str="",encoding:str="gbk",cover:bool=True,numeric:bool=False):
    "在指定的文件里写入文字，可选择编码和覆盖方式"
    if not exist(path):
        writing_file = open(path,mode="a+",encoding=encoding,errors=UnicodeDecodeError_Handle)
        writing_file.close()
    os.chmod(path,0o777)
    if numeric:
        text = str(text)
        try:
            text = float(text)
            if text%1 == 0:
                text = int(text)
        except:
            pass
    if cover == True:
        writing_file = open(path,mode="w+",encoding=encoding,errors=UnicodeDecodeError_Handle)
    else:
        writing_file = open(path,mode="a+",encoding=encoding,errors=UnicodeDecodeError_Handle)
    returncode = writing_file.write(str(text))
    writing_file.close()
    return returncode


def write_bytesfile(path:StrOrBytesPath,byte:bytearray=b"",cover:bool=True):
    "在指定的文件里写入字节，可选覆盖方式"
    if not exist(path):
        writing_file = open(path,mode="a+")
        writing_file.close()

    if cover == True:
        writing_file = open(path,mode="wb")
    else:
        writing_file = open(path,mode="ab")
    returncode = writing_file.write(byte)
    writing_file.close()
    return returncode

def update_options(optionsdict, modification:Literal["add","remove"], prop:str, value, updatefilepath:str=OPTIONS_FILE_NAME, textinfront:str="//最好不要动这里面的东西，不然可能会炸",encoding:str="gbk"):
    "指定一个配置字典，更新配置，增加，修改(modification=add)或者删除(modification=remove)项目,增加和移除项目返回值是当前配置信息的长度，删除返回的是原来所删除项目的值，输入错误返回-1"
    options = get_variable("options")
    lambda s:optionsdict
    setvar_toutils(prop, value)
    if modification == "add":
        options[prop] = value
        write_variable_file(options,textinfront,updatefilepath,encoding=encoding)      
        return len(options)
    elif modification == "remove":
        if prop in options.keys():
            returnvalue = options.pop(prop)
        else:
            returnvalue = -1
        write_variable_file(options,textinfront,updatefilepath,encoding=encoding)
        return returnvalue


def text_file_readlines(filepath:str,encoding:str="ANSI"):
    "读取文件的内容，返回的是一个列表"
    reading_file = open(filepath,mode="r",encoding=encoding,errors=UnicodeDecodeError_Handle)
    file_content = reading_file.readlines()
    reading_file.close()
    return file_content


def line_list(inputlist:list,line:int=0):
    "指定一个读取的列表，可选返回指定行的字符或列表，line<=0即为返回所有行的列表"
    reading_line = 0
    return_list = []
    if line <= 0:   
        for reading_line in range(len(inputlist)):    
            return_list.append(inputlist[reading_line])
        return return_list
    else:
        for reading_line in range(len(inputlist)):
            if reading_line == line - 1:
                    return str(inputlist[reading_line])

    
def strip(string:str):
    "把文本结尾的空格和换行符删掉(在读取文件时很有用)"
    return string.strip()


def read_bytesfile(infile:str,readlen:int=1048576):
    "读取文件的内容，返回的是字节"
    f = open(infile,"rb")
    r = f.read(readlen)
    f.close()
    return r

def read_textfile(filepath:str,encoding:str="UTF-8"):
    "读取文件的内容，但返回的是一个字符串"
    reading_file = open(filepath,mode="r",encoding=encoding,errors=UnicodeDecodeError_Handle)
    file_content = reading_file.read()
    reading_file.close
    return file_content


def read_file_to_variables(path:str):
    "一键读取指定文件的文本并返回值，去除所有空格和换行符并直接返回值，读取单个文件专用（说白了就是懒得写）"
    content = text_file_readlines(path)
    content = line_list(content,1)
    content = strip(content)
    content = str(content)
    transstr = content
    if content.count(".") == 1:
        trans0 = content.maketrans("","",".") 
        transstr = content.translate(trans0)
    if transstr.isnumeric():
        content = float(content)
    return content

    
    

# logging:是否记录日志
# logname:日志保存的名字，当为"[default]"的时候直接以时间为名字
# logpath:日志记录的路径
# loglevel:日志记录等级，数字越多日志记录越详细
try:
    loglevel = read_file_to_variables(LOGLEVEL_FILEPATH) # 日志记录等级，数字越大记录越详细
    logkeep = read_file_to_variables(f"{SETTING_PATH}\\logging\\log_keep.txt")
    logname = read_file_to_variables(f"{SETTING_PATH}\\logging\\log_name.txt")
    if logname == "[default]":
        logpath = "t_"+str(get_saving_name()) # 先定义日志名
        logpath = log_path_formatter.format(logpath)   # 日志路径
    else:
        logpath = log_path_formatter.format(logname)
        
    if exist(f"{SETTING_PATH}\\logging\\logging_sign"):logging = True 
    else:logging=False
    if not logging and exist(logpath):
        os.remove(logpath)
    
    i = 0
    for f in list_tree(DATA_PATH+"\\log")[::-1]:
        i += 1
        if i >= logkeep and f.startswith("t_"):
            os.remove(DATA_PATH+"\\log\\"+f)

        
    loglevel = read_file_to_variables(LOGLEVEL_FILEPATH)
except:
    print("日志模块加载失败...请补齐文件或将工具箱放到正确的目录运行（按任意键退出）")
    pause(False)
    raise

# ----------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------

#写入取日志的函数，参数：（写入者，PID，信息类别，文本）
def write_log(writer:str=SCRIPT_FILE_NAME,writer_pid:int=pid,msgtype:Any=1,text:str="默认文本，没什么可看的",writer_max_display_len:int=48):
    """在data\\log中写入名称为当前时间的日志，转到定义看注释\n
    关于msgtype参数所代表的信息类型：\n
    -2 -> 超级调试    ->loglevel大于等于3（超级超级详细的）\n
    -1 -> 详细调试    ->loglevel大于等于2（比较详细）\n
    0  -> 正常调试    ->loglevel大于等于1（相对于详细）\n
    1  -> 普通信息    ->loglevel大于等于0（正常）\n
    2  -> 警告信息    ->loglevel大于等于-1（只显示警告和更高级错误）\n
    3  -> 错误信息    ->loglevel大于等于-2（只显示错误和更高级错误）\n
    4  -> 致命错误    ->loglevel大于等于-3（只显示和更高级错误）\n
    其他->自定义文本  ->loglevel没有要求（不管怎么样都会显示）
    """

    _dict = sys.modules["__main__"].__dict__
    logging = _dict["logging"]

    if logging:

        if writer_pid == -1:
            writer_pid = "未知"
        if not exist(logpath):
            write_textfile(logpath,"日志是Python记录的，比Bat好用的多\n","UTF-8")
            write_textfile(logpath,"格式：[时间]                            类型    记录者                      [PID]   信息\n","UTF-8",False)
            subprocess.run("if not exist data\\log md data\\log", shell=True,text=False,capture_output=False)

        writer_and_pid = "%s[%s]"%(writer,writer_pid)
        if len(writer_and_pid) > writer_max_display_len:
            writerlen = writer_max_display_len - 2 - len(str(writer_pid))
            writer = "%s..."%writer[0:writerlen]
            writer_and_pid = "%s[%s]"%(writer,writer_pid)

        writer_and_pid = writer_and_pid.ljust(writer_max_display_len + 4," ")
        for line in text.splitlines(): 
            if msgtype == 1:
                if loglevel >=  0:write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"信息",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_info_color}\[信息]{line}")
            elif msgtype == 2:
                if loglevel >= -1:write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"警告",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_warn_color}\[警告]{line}")
            elif msgtype == 3:
                if loglevel >= -2:write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"错误",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_err_color}\[错误]{line}")
            elif msgtype == 4:
                if loglevel >= -3:write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"严重",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_fatal_color}\[严重]{line}")
            elif msgtype == 0:
                if loglevel >= 1 :write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"调试",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_debug_color}\[调试]{line}")
            elif msgtype == -1:
                if loglevel >= 2 :write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"详细",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_extde_color}\[详细调试]{line}")
            elif msgtype == -2:
                if loglevel >= 3 :write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),"极详",writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.log(f"{debug_supde_color}\[超级调试]{line}")
            else:
                write_textfile(logpath,"[%s]   %s   %s%s\n"%(get_time(),msgtype,writer_and_pid,line),"UTF-8",False)
                if debugmode:debug_console.print(f"{debug_info_color}\[{msgtype}]{line}")

write_log(SCRIPT_FILE_NAME,pid,1,"日志模块已被加载。")            

# 写入速度测试，testtimes是循环次数，sendoutput是是否输出
# 返回值是每执行一次命令的时间（估计是个科学计数法的东西）
# 和execspeedtest没啥区别
# 举例：writespeedtest(1000,True) -> 进行一千次日志的写入再算出速度，会有输出
def write_speedtest(testtimes:int=100, sendoutput:bool=True):
    "写入文件的速度测试，可以指定执行次数和是否输出，返回执行一次命令的毫秒数，和execspeedtest差不多"
    starttime=time.time()
    for testedtimes in range(testtimes):
        nowtime=get_time()
        if sendoutput == True:console.print(f"{debug_extde_color}帧时间",nowtime)
        write_log(SCRIPT_FILE_NAME,pid,1,"writespeedtest:执行测试：次数%d/%d"%(testedtimes,testtimes))
    exectime=time.time()-starttime
    if sendoutput == True:console.print(f"{debug_info_color}执行",testtimes,"次耗费的时间：",exectime,"秒")
    write_log(SCRIPT_FILE_NAME,pid,1,"writespeedtest:完成，耗费时间：%s秒"%exectime)
    commandtime=round(exectime/testtimes,8)*1000
    if sendoutput == True:console.print(f"{debug_info_color}平均速度：",commandtime,"毫秒/次")
    write_log(SCRIPT_FILE_NAME,pid,1,"writespeedtest:平均速度：%sms/次"%commandtime)
    return commandtime


def title(title:str) -> int:
    "切换窗口标题"
    return os.system(f"title {title}")


def show_msgbox(title:str="信息",
                msg:str="好的非常棒，文本丢掉了",
                clearscreen:bool=True,
                showandexit:bool=False, 
                exitcode:int=0,
                color:str=info_color,
                use_console:bool=False):
    "展示一个文本框，可选择是否清屏和是否在展示后退出，如果showandexit为True的话就需要指定exitcode"
    if clearscreen:cls()
    split_line(title,color_style=color)
    if use_console:console.print(msg)
    else:print(msg)
    if showandexit:
        split_line()
        print("（按任意键退出）")
        pause()
        exit(exitcode)
    
        

def chcp(codepage:int=65001) -> int:
    "切换代码页"
    global on_running_code_page
    on_running_code_page = codepage
    return os.system("chcp %d >nul 2>&1"%codepage)
    

def show_fatalerror(errorsender:str,errorreason:str,showandexit=True):
    "致命错误，展示这个框后直接退出"
    cls()
    split_line(f"{err_color}出错了！",color_style=err_color)
    error_console.print("[#FF5050]出错的部分：")
    error_console.print("[#E0D050]\t%s"%(errorsender))
    error_console.print("[#FF5050]\n错误原因：")
    split_line(color_style=err_color)
    error_console.print(f"\n{errorreason}")
    split_line(color_style=err_color)
    print()
    write_log(SCRIPT_FILE_NAME,pid,4,"由于以下错误，脚本无法继续运行了...")
    write_log(SCRIPT_FILE_NAME,pid,4,"出错部分：%s"%errorsender)
    write_log(SCRIPT_FILE_NAME,pid,4,"详细（若debug已开启将会展示在屏幕上）：")
    if debugmode:
        error_console.print_exception()
    for errorreason_line in errorreason.splitlines(keepends=False):
        write_log(SCRIPT_FILE_NAME,pid,4,"\t%s"%errorreason_line)
    error_console.print("\n可以试着查看日志，它已经记录在了以下路径，说不定能找到问题")
    print("[",end="")
    error_console.print(f"{logpath}",style="underline",end="")
    print("]")

    if showandexit:
        pause("（按任意键退出）")
        exit(1)
    

def cecho(text:str):
    "输出带颜色的文字，语法看cecho /?的提示就行"
    if not exist(F"{BIN_PATH}\\cecho.exe"):
        global cecho_not_exist
        if cecho_not_exist == False:
            show_msgbox("警告","cecho.exe不存在，可能已经被移动或者删除了，将不会展示带特殊颜色的文字")
            write_log(SCRIPT_FILE_NAME,pid,2,"cecho.exe不见了...将不会展示有色文字")
            pause(showtext=True)
            cecho_not_exist = True
        print(text)
    else:
        os.system(f"{BIN_PATH}\\cecho {text}")

        
def cls():
    "清屏，简洁明了"
    os.system("cls")  
    
def choose(choices:list=["yes", "no"]) -> int:
    "让用户选择选项，返回项目的序号，如果都不符合就返回0，如果列表为空则返回-1"  
    if len(choices) == 0:
          write_log(SCRIPT_FILE_NAME,pid,2,"choose:给定的选择项目为空...将会直接返回-1")
          return -1
    else:
        write_log(SCRIPT_FILE_NAME,pid,-2,"choose:请求用户输入...")
        inputmsg = input_prompt("你的选项：",
            validator=lambda s:s.upper() in [item.upper() for item in choices],
            error_message=f"输入不合法，应符合{choices}中的一项")
        write_log(SCRIPT_FILE_NAME,pid,-2,"choose:用户输入了\[%s]"%(inputmsg))
        choicenum = 0
        for choice in choices:
            choice = str(choice)
            choicenum += 1
            if  inputmsg.upper() == choice.upper():
                write_log(SCRIPT_FILE_NAME,pid,-2,"choose:寻找到了符合要求的项目,将会返回%d"%(choicenum))
                return choicenum
        write_log(SCRIPT_FILE_NAME,pid,-2,"choose:没有符合要求的项目，将会返回0")
        return 0
    
def percentage_ui(percent:float=0,stage:str="unknown",stagecurrent:any=0,stagetotal:any=0) -> None:
        "加载动画，可以自定义进度和阶段名"
        os.system("cls")
        print("		启动进度    ")
        print("------------------------------------------") 
        print(" ",end="")
        if running_on_win11:
            for __count in range((round(percent/2.5))):print("■",end="")       # win11要输出两个
        else:
            for __count in range((round(percent/5))):print("■",end="")
        print()
        print("------------------------------------------")
        print("启动阶段：%s(%s/%s)"%(stage,stagecurrent,stagetotal))
        print("启动进度：%s%s"%(round(percent+0.0001,1),"%"))

def charinstr(inputstr:str,chars:str):
    "在inputstr里面只存在chars里面的字符的话返回True，不然就是False"
    if len(inputstr) == 0:
        return False
    for strchar in inputstr:
        if chars.find(strchar) == -1:
            return False
    return True

def random_string_generator(strpool:str="1234567890abcdef",strlen:int=8):
    "生成一串从strpool里面随机抽取并排列成一段strlen长度的随机字符（可能会重复）"
    returnstr = ""
    for __count in range(strlen):
        returnstr = str("%s%s"%(returnstr,strpool[random.choice(range(len(strpool)))]))
    return returnstr

def exit(exitcode:int=0):
    "直接退出，可以指定返回码（私人SystemExit）"
    os._exit(exitcode)
    

def isIpv4address(ipaddr:str="127.0.0.1:5555"):
    "判断输入的东西是不是一个ipv4地址(虽然没什么很大的用)"
    try:
        ipaddr = ipaddr.split(":")
        if len(ipaddr) > 2:return False
        ip = ipaddr[0]
        if len(ipaddr) == 2:
            port = ipaddr[1]
            if not port.isdigit():
                return False
            else:
                if not (int(port) >= 0 and int(port) <= 65535):
                    return False
                
        ip_split = ip.split(".")    
        if len(ip_split) != 4: 
            if ip.upper() == "LOCALHOST":return True
            return False
        for ip_num in ip_split:
            if not ip_num.isdigit():
                return False
            else:
                ip_num = int(ip_num)
                if not(ip_num >= 0 and ip_num <= 255):
                    return False
            return True
        return False
    except:
        return False

def isLocalVariable(__variablename:str):
    "判断变量名有没有在本地被定义，执行可能需要挺长时间，不建议用太多"
    if __variablename in locals().keys():
        return True
    else:
        return False
    
def isGlobalVariable(__variablename:str):
    "判断变量名有没有在全局被定义，执行可能需要挺长时间，不建议用太多"
    if __variablename in globals().keys():
        return True
    else:
        return False


def print_hex(infile:str,width:int=16,pause=(True,8),nul_or_unexpected_char=" "):
    "将指定的文件以16进制的形式排列出来"
    f = open(infile,"rb")
    i = j = line = 0
    hex_line = str_line = ""
    while True:
        i += 1
        if pause != False and pause[0] and j == pause[1]:
                with console.status(f"按任意键继续加载{pause[1]}行",spinner="dots"):
                    os.system("pause > nul")
                j = 0
        if i > width:
            line += 1
            print(F"[{str(line).zfill(8)}]  " + hex_line+ "   " + str_line)
            hex_line = str_line = ""
            j += 1
            i = 1
        c = f.read(1)
        if not c:
            break
        else:
            hex_line += hex(ord(c))[2:].zfill(2)+" "
            if ord(c) == 0:
                str_line += nul_or_unexpected_char + " "
            else:
                try:
                    if (ord(c) >= 0 and ord(c) <= 31) or ord(c) == 127:
                        str_line += nul_or_unexpected_char + " "
                    else:
                        str_line += c.decode() + " "
                except UnicodeDecodeError:
                    str_line += nul_or_unexpected_char + " "
    f.close()

def remove_in_list(inputlist:list,remove_object:Any) -> list:
    "移除inputlist中所有为remove_object的项目"
    return_list = []
    for obj in inputlist:
            if obj != remove_object:
                return_list.append(obj)
    return return_list



def parse_args(args:str) -> list:
    "将字符串形式的命令参数转换为列表。"
    args_split = args.split(" ")
    in_arg_parsing = False
    loop = 0
    arg_tmp = ""
    args_list = []
    while loop < len(args_split):
        arg = args_split[loop]

        if not in_arg_parsing:
            if arg == "":
                loop += 1
                continue
            if arg.startswith('"'):
                arg_tmp = ""
                in_arg_parsing = True
            else:
                args_list.append(arg)
                loop += 1
        else:
            if arg == "":
                arg_tmp += " "
                loop += 1
                if loop == len(args_split):
                    args_list.append(args.split('"')[-1])
                continue

            if arg.startswith('"') and arg_tmp == "":
                arg = arg[1:]
            if (arg.endswith('"') and len(arg) > 1) or arg == "\"":
                arg = arg[0:-1]
                arg_tmp += arg
                args_list.append(arg_tmp)
                arg_tmp = ""
                in_arg_parsing = False
                loop += 1
            else:
                arg_tmp += arg + " "
                loop += 1
                if loop == len(args_split):
                    args_list.append(args.split('"')[-1])
    return args_list
                

def parse_adb_shell_args(args:str) -> Tuple[List[str], List[str]]:
    "将字符串形式的命令参数转换为列表。"
    shell = False
    shell_args = []
    cmd_args = []
    for arg in args:
        if not shell:
            if arg == "shell":
                cmd_args.append("shell")
                shell = True
            elif "shell" in arg:
                try:
                    shell_args.append(arg.split("shell")[1])
                    cmd_args.append(arg.split("shell")[0] + " shell")
                    shell = True
                    continue
                except:
                    cmd_args.append(arg)
                    shell = True
            else:
                cmd_args.append(arg)
        else:
            shell_args.append(arg)
    return cmd_args, shell_args

def tee(command:str,redirect_path:str):
    "就是tee命令而已"
    return os.system(f"{command} | {LINUX_BIN_PATH}\\tee.exe {redirect_path}")


def remove(path:str):
    "删除一个文件。"
    try:
        if path.startswith("\"") and path.endswith("\""):
            path = path[1:][0:-1]
        os.remove(path)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：删除文件\[{path}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：删除文件[{path}]遇到错误：{error_desc}")



def mkdir(path:str,permission_mode:int=0o777):
    "创建一个目录。"
    try:
        if path.startswith("\"") and path.endswith("\""):
            path = path[1:][0:-1]
        os.makedirs(path,mode=permission_mode)
        os.chmod(path,permission_mode)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：创建目录\[{path}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：创建目录[{path}]遇到错误：{error_desc}")
    

def md(path:str,permission_mode:int=0o777):
    "创建一个目录。"
    try:
        if path.startswith("\"") and path.endswith("\""):
            path = path[1:][0:-1]
        os.makedirs(f"{path}",mode=permission_mode)
        os.chmod(path,permission_mode)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：创建目录\[{path}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：创建目录[{path}]遇到错误：{error_desc}")

def rmdir(path:str):
    "删除一个目录。"
    try:
        if path.startswith("\"") and path.endswith("\""):
            path = path[1:][0:-1]
        shutil.rmtree(f"{path}")
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：删除目录\[{path}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：删除目录[{path}]遇到错误：{error_desc}")

def rd(path:str):
    "删除一个目录。"
    try:
        if path.startswith("\"") and path.endswith("\""):
            path = path[1:][0:-1]
        shutil.rmtree(f"{path}")
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：删除目录\[{path}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：删除目录[{path}]遇到错误：{error_desc}")



def copytree(src:str,dst:str):
    "复制一个目录。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        if dst.startswith("\"") and dst.endswith("\""):
            dst = dst[1:][0:-1]
        shutil.copytree(src,dst)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：复制目录\[{src}]到\[{dst}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：复制目录[{src}]到[{dst}]遇到错误：{error_desc}")

def rmtree(src:str):
    "删除一个目录。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        shutil.rmtree(src)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：删除目录\[{src}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：删除目录[{src}]遇到错误：{error_desc}")

def cptree(src:str,dst:str):
    "复制一个目录。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        if dst.startswith("\"") and dst.endswith("\""):
            dst = dst[1:][0:-1]
        shutil.copytree(src,dst)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：复制目录\[{src}]到\[{dst}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：复制目录[{src}]到[{dst}]遇到错误：{error_desc}")


def rename(src:str,dst:str):
    "重命名或者移动一个文件。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        if dst.startswith("\"") and dst.endswith("\""):
            dst = dst[1:][0:-1]
        os.rename(src,dst)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：重命名\[{src}]到\[{dst}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：重命名[{src}]到[{dst}]遇到错误：{error_desc}")


def ren(src:str,dst:str):
    "重命名或者移动一个文件。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        if dst.startswith("\"") and dst.endswith("\""):
            dst = dst[1:][0:-1]
        os.rename(src,dst)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：重命名\[{src}]到\[{dst}]遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：重命名[{src}]到[{dst}]遇到错误：{error_desc}")


def cd(path:str):
    "更改运行路径。"
    try:
        if path.startswith("\"") and path.endswith("\""):
            path = path[1:][0:-1]
        os.chdir(path)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：更改路径遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：更改路径遇到错误：{error_desc}")


def copy(src:StrOrBytesPath, dst:StrOrBytesPath):
    "复制一个文件。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        if dst.startswith("\"") and dst.endswith("\""):
            dst = dst[1:][0:-1]
        if os.path.isdir(dst):
            if dst.endswith("\\"):
                dst += src.split("\\")[-1]
            else:
                dst += "\\" + src.split("\\")[-1]
        shutil.copyfile(src, dst)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：复制文件遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：复制文件遇到错误：{error_desc}")

    
    
def cp(src:StrOrBytesPath, dst:StrOrBytesPath):
    "复制一个文件。"
    try:
        if src.startswith("\"") and src.endswith("\""):
            src = src[1:][0:-1]
        if dst.startswith("\"") and dst.endswith("\""):
            dst = dst[1:][0:-1]
        if os.path.isdir(dst):
            if dst.endswith("\\"):
                dst += src.split("\\")[-1]
            else:
                dst += "\\" + src.split("\\")[-1]
        shutil.copyfile(src, dst)
    except Exception as error_desc:
        error_console.print(f"{warn_color}警告：复制文件遇到错误：{error_desc}")
        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：复制文件遇到错误：{error_desc}")



def generate_adb_code(input_number:str) -> Union[int, None]:
    "将输入的数字转化为adb校验码"
    if len(input_number) < 9:
        return
    try:
        int(input_number)
    except ValueError:
        print("输入的数字有误")
        return
    i = int(input_number[0:2])
    i2 = int(input_number[2:4])
    i3 = int(input_number[4:6])
    i4 = int(input_number[6:8])
    i5 = int(input_number[8:])
    i6 = i5 ^ (i3 + i4)
    i7 = i4 ^ i6
    i8 = i3 ^ i6
    i9 = i ^ i6
    i10 = i2 ^ i6
    input_number = str(i9).zfill(2) + str(i10).zfill(2) + str(i8).zfill(2) + str(i7).zfill(2) + str(i6)
    i = int(input_number[0:2])
    i2 = int(input_number[2:4])
    i3 = int(input_number[4:6])
    i4 = int(input_number[6:8])
    i5 = int(input_number[8:])
    i6 = i4 ^ i3
    i7 = i5 ^ i3
    i8 = i3 ^ (i6 + i7)
    i9 = i ^ i7
    i10 = i2 ^ i7
    result = str(i9).zfill(2) + str(i10).zfill(2) + str(i6).zfill(2) + str(i7).zfill(2) + str(i8)
    return result


def write_zipfile(*src:str,dst:str="file.zip",mode:Literal["w","x","a"]="w",build_base_dir:bool=True) -> int:
    "把文件/目录打包为zip文件。"
    _src = []
    for f in src:
        if f.startswith("\"") and f.endswith("\""):
            f = f[1:][0:-1]
        _src.append(f)

    if dst.startswith("\"") and dst.endswith("\""):
        dst = dst[1:][0:-1]

    src = _src

    try:
        zip_obj = zipfile.ZipFile(dst,mode,zipfile.ZIP_DEFLATED)
        
    except:
        return 1
    
    if mode in ("x","w","a"):   
        for item in src:
            if item.endswith("\\"):
                for file in list_tree(item):
                    if build_base_dir:
                        zip_obj.write(item+file)
                    else:
                        zip_obj.write(item+file,file)
            else:
                try:
                    if build_base_dir:
                        zip_obj.write(item)
                    else:
                        zip_obj.write(item,"\\".join(item.split("\\")[1:]))
                except FileNotFoundError:
                    pass
        zip_obj.close()
        

def extract_zipfile(src:str="file.zip",dst="files\\",targets:Optional[List[str]]=None):
    "将压缩文件解压到指定目录。"
    if src.startswith("\"") and src.endswith("\""):
        src = src[1:][0:-1]
    if dst.startswith("\"") and dst.endswith("\""):
        dst = dst[1:][0:-1]
    zip_obj = zipfile.ZipFile(src)
    if targets is None:
        for f in zip_obj.namelist():
            zip_obj.extract(f, dst)
    else:
        for f in targets:
            zip_obj.extract(f, dst)





def ranged_dict(*list_args:list, start:int=0, end:Optional[int]=None):
    """通过一个列表返回一个对列表元素标号的字典
例如 ranged_dict(["a", "b", "c"], start=1) 返回 {1: "a", 2: "b", 3: "c"} """
    if start > end:
        raise AttributeError(f"起始数 ({start}) 不能大于终止数 ({end})")
    full_list = []
    result = {}
    list_args = iter(list_args)
    while True:
        try:
            full_list += next(list_args)
        except StopIteration:
            break
    full_list = iter(full_list)
    while True:
        try:
            result[start] = next(full_list)
            start += 1
            if end != None and start >= end:
                    raise StopIteration
        except StopIteration:
            break
    return result


def input_prompt(question:str="请输入：",
                 default_text:str="",
                 validator=lambda s:True,
                 error_message="输入不合法",
                 is_password:bool=False) -> str:
    
    return InputPrompt(question=question,
                       default_text=default_text,
                       validator=validator,
                       error_message=error_message,
                       is_password=is_password).prompt(style=InputPrompt_style)

def list_prompt(question:str="请选择...",choices:List[Choice]=[Choice("默认选项",0)],
                annotation=ListPrompt_annotation,max_height:int=15) -> Choice:
    return ListPrompt(question=question,
                      choices=choices,
                      annotation=annotation,
                      pointer=ListPrompt_pointer,
                      max_height=max_height).prompt(style=ListPrompt_style)


def confirm_prompt(question:Optional[str]=None,default_select:bool=False):
    "进行是否确定的询问"
    if question is None:question = "请选择..."
    if default_select:
        choices = [Choice("是",True),Choice("否",False)]
    else:
        choices = [Choice("否",False),Choice("是",True)]
    return ListPrompt(question,
                       choices,
                       annotation=ListPrompt_annotation,
                       pointer=ListPrompt_pointer).prompt(style=ConfirmPrompt_style).data

def make_module_script(script_path:str=MODULE_SCRIPT_PUSH_PATH,module_path:str=MODULE_PUSH_PATH):
    "生成模块安装脚本(在手表里)"
    return os.system(rf"""adb shell "echo -e 'chmod 777 /data/adb/magisk/busybox\nDATABIN=\"/data/adb/magisk\"\nBBPATH=\"/data/adb/magisk/busybox\"\nUTIL_FUNCTIONS_SH=\"$DATABIN/util_functions.sh\"\nexport OUTFD=1\nexport ZIPFILE=\"{module_path}\"\nexport ASH_STANDALONE=1\n\"$BBPATH\" sh -c \". \\\"$UTIL_FUNCTIONS_SH\\\"; install_module\"' > {script_path}" """)


_T = TypeVar("_T")
def replace(obj:_T,_from:_T,_to:_T,_max_rep:int=-1) -> _T:
    "将指定内容替换为另一个"
    obj = obj.split(_from,_max_rep)
    return _to.join(obj)

def between(string:str,
            start:str,
            end:str,
            start_matching_priority:Literal["left","right"]="right",
            end_matching_priority:Literal["left","right"]="left",
            not_found:Any=None) -> Optional[str]:
    "返回在string中start和end中间的字符串，priority_..._match是优先从左/右边匹配"
    _rule = (start_matching_priority == "left", end_matching_priority == "left")
    if _rule == (True, True):
        try:
            return string.split(start,1)[1].split(end,1)[0]
        except:
            return not_found
    elif _rule == (True, False):
        try:
            return string.split(start,1)[1].rsplit(end,1)[0]
        except:
            return not_found
    elif _rule == (False, False):
        try:
            return string.rsplit(start,1)[1].rsplit(end,1)[0]
        except:
            return not_found
    elif _rule == (False, True):
        try:
            return string.rsplit(start,1)[1].split(end,1)[0]
        except:
            return not_found
        

def explore(args:str=cwd):
    "启动文件管理器打开指定目录"
    os.system(f"explorer.exe {args}")

class Script():
    "脚本的基层结构体。"

    class Function:
        "脚本中的执行功能"
        def __init__(self,name,data,desc,imports,executes):
            self.data:int = data
            self.name:str = name
            self.desc:str = desc
            self.imports:str = imports
            self.executes:str = executes

        def execute(self, stop_progress=True) -> Any:
            "尝试执行该功能"
            try:
                result = None

                exec(f"import {self.imports}")
                exec(f"result = {self.executes}")
            except:
                console.print(err_color+f"错误：执行\"{self.name}\"失败：\n{traceback.format_exc()}")
                write_log(SCRIPT_FILE_NAME,pid,3,f"错误：执行\"{self.name}\"失败：\n{traceback.format_exc()}")
                pause("出错了！（按任意键继续）")
            try:
                if stop_progress:
                    progress.stop()
            except:
                pass
            return result
        
        
                



    class Flag():
        "标志文件的结构。"
        def __init__(self,name,path):
            self.name:str=name
            self.path:str=path

        def get_status(self) -> bool:
            "获取标志状态。"
            return(exist(self.path))
                
        def change_status(self,stat:Any=None):
            "更改标志状态。"
            if stat == True:
                write_textfile(self.path,f"在脚本内强制更改，修改时间：({get_time()}) {time.time()})")
                write_log(SCRIPT_FILE_NAME,pid,0,"标志更改：%s (%s)更改为是（强制更改）"%(self.name,self))
            elif stat == False:
                if exist(self.path):remove(self.path)
                write_log(SCRIPT_FILE_NAME,pid,0,"标志更改：%s (%s)更改为否（强制更改）"%(self.name,self))
            elif stat == None:
                if exist(self.path):remove(self.path)
                write_log(SCRIPT_FILE_NAME,pid,0,"标志更改：%s (%s)更改为否（自动更改）"%(self.name,self))
            else:
                write_textfile(self.path,f"在脚本内自动更改，修改时间：({get_time()}) {time.time()})")
                write_log(SCRIPT_FILE_NAME,pid,0,"标志更改：%s (%s)更改为是（自动更改）"%(self.name,self))

    class Exceptions():
        "没关系，意外总是来得猝不及防（我早习惯了）"

        class Functions():
            "函数中的错误"
            class DeviceTimeOutError(ConnectionError):"设备超时未连接。"
            class OptionModificationError(TypeError):"请求的修改方式不正确。"
            class NotRunningAsMainError(RuntimeError):"运行模式不正确。"

        class Features():
            "功能中的错误"
            class WirelessConnectionPortError(ConnectionError):"无线连接的端口不正确"
            class ExtensionPackNotFoundError(LookupError):"所请求的拓展包不存在"
            class FlashSchemeNotFoundError(LookupError):"刷机方案不存在"

    class Items():
        "一些物件的集合。"

        class ByteOutput():
            "以字节为单位的输出。"
            def __init__(self,stdout:(bytes),stderr:bytearray):
                self.stdout=stdout
                self.stderr=stderr

            def decode(self,coding:str="utf-8"):
                if isinstance(self.stdout,bytes) and isinstance(self.stderr,bytes): 
                    self.stdout = self.stdout.decode(coding)
                    self.stderr = self.stderr.decode(coding)

        class ExtensionPack():
            "拓展包。"
            def __init__(self,nameid:str,num:int,path:str):
                "初始化结构体"
                self.nameid:str=nameid
                self.num:int=num
                self.path:str=path
                def get_data():
                    try:
                        data = {}
                        raw_data = read_textfile(f"{EXTENSION_PATH}\\data\\{self.nameid}.txt","gbk")
                        for line in raw_data.splitlines():
                            if "=" in line:
                                line_split = line.split("=",2)
                                data[line_split[0]] = line_split[1]
                        return data
                    except BaseException as err_info:
                        err_type = str(type(sys.exc_info()[1])).split("'")[1]
                        error_console.print(f"{warn_color}警告：读取拓展包{nameid}的配置文档失败：\[{err_type}]{err_info}")
                        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：读取拓展包{nameid}的配置文档失败：[{err_type}]{err_info}")
                        if "UnicodeDecodeError" in err_type:
                            return -2
                        else:
                            return -1

                self.data=get_data()

                if self.data == -1:
                    error_console.print(f"{warn_color}警告：无法读取拓展包{nameid}的信息，疑似配置文档丢失/无法访问")
                    self.name:str="未知[配置文档无法访问]"
                    self.author:str="未知"
                    self.version_name:str="未知"
                    self.description:str="（配置文档的编码不正确）"
                    self.start_mode:int=3

                elif self.data == -2:
                    error_console.print(f"{warn_color}警告：无法读取拓展包{nameid}的信息，配置文档编码错误")
                    self.name:str="未知[配置文档编码不正确]"
                    self.author:str="未知"
                    self.version_name:str="未知"
                    self.description:str="（配置文档的编码不正确）"
                    self.start_mode:int=3

                else:

                    try:
                        self.name:str=self.data["name"]
                        self.author:str=self.data["author"]
                        self.version_name:str=self.data["version"]
                        self.description:str=self.data["description"]
                        if "force_start_mode" in self.data.keys(): 
                            self.start_mode:int=int(self.data["force_start_mode"])

                    except Exception as err_info:
                        err_type = str(type(sys.exc_info()[1])).split("'")[1]
                        error_console.print(f"{warn_color}警告：无法读取拓展包{nameid}的信息：\[{err_type}]{err_info}")
                        write_log(SCRIPT_FILE_NAME,pid,2,f"警告：无法读取拓展包{nameid}的信息：[{err_type}]{err_info}")
                        self.name:str="未知"
                        self.author:str="未知"
                        self.version_name:str="未知"
                        self.description:str="（数据解析出错）"
                        self.start_mode:int=0

            def exec_inwindow(self):
                "在窗口内执行。"
                write_log(SCRIPT_FILE_NAME,pid,1,f"尝试在窗口内执行拓展包{self.nameid}...")
                try:
                    fixed_data = {}
                    for data_name in self.data.keys():
                        fixed_data[f"extension.{self.nameid}.{data_name}"] = self.data[data_name]
                    setvar_command = ""
                    for key in fixed_data.keys():
                        setvar_command += f"set {key}={fixed_data[key]}&"
                    write_log(SCRIPT_FILE_NAME,pid,1,f"命令：{setvar_command}{self.path}")
                    os.system(f"{setvar_command}{self.path}")

                except Exception as err_info:
                        err_type = str(type(sys.exc_info()[1])).split("'")[1]
                        error_console.print(f"{warn_color}错误：无法执行拓展包{self.nameid}：\[{err_type}]{err_info}")
                        write_log(SCRIPT_FILE_NAME,pid,3,f"错误：无法执行拓展包{self.nameid}：[{err_type}]{err_info}")

            def exec_outwindow(self):
                "在窗口外执行。"
                write_log(SCRIPT_FILE_NAME,pid,1,f"尝试在窗口内执行拓展包{self.nameid}...")
                try:
                    fixed_data = {}
                    for data_name in self.data.keys():
                        fixed_data[f"extension.{self.nameid}.{data_name}"] = self.data[data_name]
                    if fixed_data != {}:
                        setvar_command = ""
                        for key in fixed_data.keys():
                            setvar_command += f"set {key}={fixed_data[key]}&"
                    else:
                        setvar_command = ""
                    os.system(f"{setvar_command}start {self.path}")

                except Exception as err_info:
                        err_type = str(type(sys.exc_info()[1])).split("'")[1]
                        error_console.print(f"{warn_color}错误：无法执行拓展包{self.nameid}：\[{err_type}]{err_info}")
                        write_log(SCRIPT_FILE_NAME,pid,3,f"错误：无法执行拓展包{self.nameid}：[{err_type}]{err_info}")
            



first_start_flag:Script.Flag = Script.Flag("first_start",f"{SETTING_PATH}\\first_start_sign.sign")
show_percent_flag:Script.Flag = Script.Flag("show_percent",f"{SETTING_PATH}\\show_loaded_percent_sign.sign")
pre_load_tips_flag:Script.Flag = Script.Flag("pre-load_tips",f"{SETTING_PATH}\\pre-load_tip_text_sign.sign")
check_file_flag:Script.Flag = Script.Flag("check_files",f"{SETTING_PATH}\\check_file_sign.sign")
write_log_flag:Script.Flag = Script.Flag("write_log",f"{SETTING_PATH}\\logging\\logging_sign.sign")
running_on_win11_flag:Script.Flag = Script.Flag("running_on_win11",f"{SETTING_PATH}\\running_on_WIN11.sign")



firststart = first_start_flag.get_status()
showstartcompletedpercent = show_percent_flag.get_status()
preloadtips = pre_load_tips_flag.get_status()
checkfiles = check_file_flag.get_status()
logging = write_log_flag.get_status()
running_on_win11 = running_on_win11_flag.get_status()

from threading import Thread




class ReturnThread(Thread):
    def run(self):
        if self._target is not None:
            self._return = self._target(*self._args, **self._kwargs)

    def join(self):
        super().join()
        return self._return







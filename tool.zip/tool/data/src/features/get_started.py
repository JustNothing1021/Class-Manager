from src.init_utils import *


"""
初始引导
"""

SCRIPT_FILE_NAME = f"script:{__name__}"


def guide():
    """引导"""
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    title("真的啥也不是啊的工具箱-引导")
    cls()
    split_line("引导")
    console.print(info_color+f"欢迎来到真的啥也不是啊的工具箱{tip_color}{versionname}！")
    time.sleep(2.0)
    split_line("")
    print("本次更新的内容如下：")
    for whats_new_text in text_file_readlines("data\\whats_new.txt"):
        if whats_new_text[0:7] == "[pause]":
            write_log(SCRIPT_FILE_NAME,pid,-1,"暂停...")
            pause(True)
        elif whats_new_text[0:7] == "[sleep:":
            write_log(SCRIPT_FILE_NAME,pid,-1,f"延迟{float(strip(whats_new_text)[8:-1])}秒...")
            time.sleep(float(strip(whats_new_text)[8:-1]))
        else:
            if not whats_new_text.isspace() and whats_new_text != " ":cecho(whats_new_text)
            print()
    write_log(SCRIPT_FILE_NAME,pid,1,"更新文本展示完成！")
    print("那么最近更新的就是这些了，在使用之前，需要先尝试连接设备吗？\n输入yes(不分大小写)将会进入连接教程，其他将会跳过")
    print("输入完之后需要按下回车（Enter）按键才算是输入完，不然我怎么知道你输没输完啊")
    print("如果输入不了可以点一下这个窗口，因为可能是这个窗口不在最上层，输入的东西跑到别的地方去了")
    write_log(SCRIPT_FILE_NAME,pid,1,"询问用户是否查看连接教程...")
    if choose(["yes","no"]) == 1:
        write_log(SCRIPT_FILE_NAME,pid,1,"将会进入连接设备教程...")
        write_log(SCRIPT_FILE_NAME,pid,1,"展示第1页文本...")
        print("""那么将会进入连接设备教程...

首先，想要破解手表，需要一根四点线
可以在各大购物平台上搜索"小天才四点线"找到对应型号的线
但是新版本的几个机型（Z7A,Z9等）的数据触点藏在SIM卡槽里面
所以个别型号需要自制四点线，可以在网上搜索教程（也可以上别处买到，但很贵）
如果你已经拥有了四点线，按任意键继续""")
        pause(False)
        print()
        write_log(SCRIPT_FILE_NAME,pid,1,"展示第2页文本...")
        print("""使用工具箱时，建议把版本降到2022-2023年发布的，效果最好
因为新版本的各种限制，工具箱不能在新版本发挥最大作用
所以在可能的情况下（新手建议在大佬指导下降级）
尽量把版本降低一点（比如Z6癫疯（巅峰）版的2.3.0，1.4.2也行但有些过于古老）
降级文件（小天才超级系统恢复）可以在各种小天才破解群的群文件里找到，
可以在各个平台搜索，说不定能找到
注：如果你是新手要进这些群的话不建议在里面问问题
最好是拿了东西就走，不要在群里当死人（bushi）
                      
但是值得注意的是，如果直接降级的话，会导致数据丢失
这会直接导致使用不了小天才的服务
所以在开始降级之前，先看一下板块1-4的信息（暂时还没写，下次修复）
千万不要盲目降级！！！！！！
                      
按任意键继续""")
        pause(False)
        write_log(SCRIPT_FILE_NAME,pid,1,"展示第3页文本...")
        print()
        print("""在连接以前，需要在拨号内输入*#0769651#*打开ADB
但是新版本打开adb需要算adb验证码（这个我也不会，别问我了）
如果验证码是8位建议找大佬来算，不是8位可以用功能2-9
用到电脑破解，需要用四点线把电脑和手表连接起来
提示：Z6癫疯版的四点线连接时线头是朝左边，不是右边
如果需要刷机，务必保持数据线的稳定
在连接好之后，按任意键继续（没连接好也没事）""")
        pause(False)
        write_log(SCRIPT_FILE_NAME,pid,1,"展示第4页文本...")
        print()
        print("""在使用ADB（Android Debug Bridge的缩写，安卓调试桥）破解前
需要先安装ADB驱动，接下来会自动打开安装界面
看到中间那几栏（没有设备连接/设备没打开adb就是空的）有设备以后按Install就可以安装了
可以先适应一下操作然后关掉，在引导走完之后找大佬把adb开了
打开adb之后在工具箱主界面->设置与其他->拓展包->安装安卓ADB驱动就可以再次打开安装界面了
5秒钟之后会打开，看完之后回到这个窗口按任意键继续""")
        write_log(SCRIPT_FILE_NAME,pid,1,"延迟5秒...")
        time.sleep(5.0)
        write_log(SCRIPT_FILE_NAME,pid,1,"启动ADB驱动安装程序...")
        if not exist(f"{EXTENSION_PATH}\\ADBDriverInstaller.exe"):
            write_log(SCRIPT_FILE_NAME,pid,1,"ADB驱动文件丢失...将会无法启动")
            pause("文件丢失...将会无法启动（按任意键继续）")
        else:
            subprocess.run(f"start {EXTENSION_PATH}\\ADBDriverInstaller.exe",shell=True)
        pause(False)
        print()
        write_log(SCRIPT_FILE_NAME,pid,1,"展示第5页文本...")
        print("""如果需要刷机，则需要用到高通的驱动
接下来也同样会打开安装界面，但操作会相对复杂
但是这个不需要设备连接，可以选择先安装这个
在弹出的窗口中，首先点击Next，再点一次Next
接着在协议界面点击左边的I accept...选项，点击Next
最后点击Install，在安装驱动的询问窗口全部点击安装就行了
安装完以后，回到这个窗口按任意键继续（5秒后打开）""")
        write_log(SCRIPT_FILE_NAME,pid,1,"延迟5秒...")
        time.sleep(5.0)
        write_log(SCRIPT_FILE_NAME,pid,1,"启动高通驱动安装程序...")
        if not exist(f"{EXTENSION_PATH}\\QualcommUSBDriversForWindows.exe"):
            write_log(SCRIPT_FILE_NAME,pid,1,"高通驱动文件丢失...将会无法启动")
            pause("文件丢失...将会无法启动（按任意键继续）")
        else:
            subprocess.run(f"start {EXTENSION_PATH}\\QualcommUSBDriversForWindows.exe",shell=True)
        pause(False)
        print()
        write_log(SCRIPT_FILE_NAME,pid,1,"展示第6页文本...")
        print("""如果一切就绪后，可以在工具箱中的功能2-6（连接与检测设备->检测设备连接状态）检测设备连接
那么接下来将会进入工具箱（按任意键继续）""")
        pause(False)

    else:
        write_log(SCRIPT_FILE_NAME,pid,1,"将会跳过教程...")
        print("那么将会跳过教程")
        write_log(SCRIPT_FILE_NAME,pid,1,"教程展示完成！")


            
def set_settings():
    """初始设置"""
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    write_log(SCRIPT_FILE_NAME, pid, 1, "展示前言...")
    notice = text_file_readlines("data\\notice.txt")
    console.print(Rule(f"{info_color}前言"))
    for text in notice:
        print(text, end="")
    pause(showtext=True)
    split_line("初入")

    print("""在开始使用以前，需要了解一些关于你的信息
emmm...你是否有光敏性癫痫病史？（输入yes为是，no为否，不分大小写）
小提示：输入文本的时候需要在输入完以后按一下回车（Enter）键脚本才会继续运行
如果发现按了按键却没有显示输入内容可以试着点击一次命令窗口后再输入
(这个东西就是用来测试你会不会用终端的)""")
    write_log(SCRIPT_FILE_NAME, pid, 1, "先测试一下用户会不会用终端输入，问一下有没有癫痫")
    choosenum = choose(["yes", "no"])
    if choosenum != 2:
        write_log(SCRIPT_FILE_NAME, pid, 1, "好吧看来他有。。。将变量noflashlight设置为True...")
        print("了解了，接下来这个程序不会有高频的彩色闪烁\n我真的不想摊上事，谢谢你的理解")
        noflashlight = True
        update_options(options, "add", "noflashlight", True)
        update_options(options, "add", "firststart", False)
        first_start_flag.change_status(False)
    else:
        write_log(SCRIPT_FILE_NAME, pid, 1, "并没有，将变量noflashlight设置为False...")
        print("了解了，接下来这个程序将会在需要强调的地方适当闪烁\n我怕某些人没有注意到那些需要强调的地方\n\
所以，谢谢你的理解")
        noflashlight = False
        update_options(options, "add", "noflashlight", False)
        update_options(options, "add", "firststart", False)
        first_start_flag.change_status(False)
    pause(showtext=True)
    console.print(info_color+"将会在3秒后重新读取...")
    time.sleep(3.0)
    gls = globals()
    lcs = locals()
    for key in lcs:
        gls[key] = lcs[key]
    return gls

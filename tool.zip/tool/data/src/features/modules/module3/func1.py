
from src.init_utils import *

from src.features.modules.module3.boot_patch import boot_patch_25200_special, boot_patch_23000, boot_patch_20400, boot_patch

SCRIPT_FILE_NAME = f"script:{__name__}"


def main():
    version = ListPrompt("请选择版本...",
                        [
                            Choice("Magisk 25.2（小天才专用，适用aboot+boot方案）",25200),
                            Choice("Magisk 23.0（小天才专用，适用recovery+misc方案）",23000),
                            Choice("Magisk 20.4（小天才专用，适用boot方案）",20400),
                            Choice("自定义选项（支持少数magisk包，除ChormeOS通用，看你自己了）",0)
                        ],
                        pointer=ListPrompt_pointer,
                        annotation=ListPrompt_annotation
                        ).prompt(style=ListPrompt_style).data

    if version == 25200:
        boot_patch_25200_special.main()

    elif version == 23000:
        boot_patch_23000.main()
        
    elif version == 20400:
        boot_patch_20400.main()
    
    elif version == 0:
        boot_patch.main()
    




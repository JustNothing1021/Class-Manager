
from src.init_utils import *




def main():

    payloadfile = input_prompt("请输入payload.bin的路径：",validator=lambda s:exist(s),error_message="请输入一个存在的路径")

    out = input_prompt("请输入解压到的目录：",validator=lambda s:s != "",error_message="请输入一个存在的路径",default_text=f"{CACHE_PATH}\\payload_extract\\")



    if not os.path.isdir(out):
        md(out)
    else:
        if confirm_prompt("路径已经存在，是否清理该目录并继续？",default_select=True):
            rmtree(out)
            md(out)
        else:
            return
    time.sleep(3)
    output = os.system(f"{BIN_PATH}\\payload_dumper.exe -o {out} {payloadfile}")

    if not output:
        pause(success_color+"完成！（按任意键继续）")   
    else:
        pause(err_color+"疑似出错了...（按任意键继续）")   

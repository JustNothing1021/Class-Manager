from src.init_utils import *
from src.features.modules.module4.func6 import to_human_readable_size
class Partition(NamedTuple):
    name:str
    startLBA:int
    sizeInLBA:int


def get_gpt(port:str="COM3") -> List[Partition]:
    status, output = run_command(f"emmcdl -p {port} -f {COMMON_MBN_PATH} -gpt",return_type="statusoutput",show_output=False,encoding="gbk")
    if status:
        console.print(err_color+"获取分区表失败...")
        try:
            console.print(err_color+output.strip().splitlines()[-1])
        except:
            pass
        return []
    return_list = []
    try:
        for line in output.splitlines():
            if "Partition Name:" in line:
                return_list.append(
                    Partition(
                        # 举例： 5. Partition Name: sbl1bak Start LBA: 394264 Size in LBA: 1024
                        between(line,"Partition Name: "," "),
                        int(between(line,"Start LBA: "," ")),
                        int(between(line,"Size in LBA: "," "))
                    )
                )
    except:
        console.print(err_color+"获取分区表失败...")
        return []

    return return_list

def extract(list:List[Partition],
            save_path:StrOrBytesPath,
            port:str,
            max_retry:int=3,
            skip_userdata=True) -> int:
    progress.start()
    total_lba = sum([s.sizeInLBA for s in list])
    t = progress.add_task(f"备份分区中...{str(0).rjust(2)}/{len(list)}",total=total_lba)
    processed_partition = 0
    succeed = 0
    retry = 1
    for partition in list:
        processed_partition += 1
        while retry <= 3:
            if partition.name == "userdata" and skip_userdata:
                console.print(tip_color+"由于时间过长设备会重启，将跳过userdata分区的备份")
                break
            console.print(info_color+ \
                          f"备份{value_color}{partition.name}{tip_color}[{to_human_readable_size(partition.sizeInLBA * 512)}]{close_tag*2}" + \
                          (f"{tip_color}({retry}/{max_retry}){close_tag}") +"...")
            write_bytesfile(save_path+"\\rawprogram0.xml",
                            f"""\t<program  SECTOR_SIZE_IN_BYTES="512" file_sector_offset="0" filename="{partition.name}.img" label="{partition.name}" num_partition_sectors="{partition.sizeInLBA}" physical_partition_number="0" sparse="false" start_sector="{partition.startLBA}"/>\n""".encode("utf-8"),
                            False)
            stat = extract_partition(port,mode=("by_name", partition.name),
                                     output_file=f"{save_path}\\{partition.name}.img",
                                     reset=False,show_progress=True)
            if stat:
                console.print(err_color+f"备份{partition.name}失败...")
                retry += 1
            else:
                succeed += 1
                retry = 1
                break
        if retry >= 3:
            console.print(err_color+"备份失败！")
            return succeed
        
        progress.update(t,
                        description=f"备份分区中...{str(processed_partition).rjust(2)}/{len(list)}",
                        advance=partition.sizeInLBA)
    progress.remove_task(t)
    progress.stop()
    return succeed

def main():
    mode = wait_for_device(mode="any")
    if mode == "adb":
        save_path = input_prompt("请输入保存的路径: ",default_text=F"{BACKUP_PATH}\\partitions_bak\\{getprop('ro.product.model')}_{get_saving_name()}\\")
        console.print(info_color+"重启至edl...")
        run_command("adb reboot edl")
        wait_for_device(mode="edl")
    elif mode == "edl":
        save_path = input_prompt("请输入保存的路径: ",default_text=F"{BACKUP_PATH}\\partitions_bak\\edldev_{get_saving_name()}\\")
    else:
        console.print(err_color+"请重启到edl/正常模式再使用此功能...")
        pause()
        return
    if not exist(save_path):md(save_path)
    
    console.print(tip_color+"当前连接设备：",end="")
    port = between(run_command("lsusb"),"(",")",not_found=None)
    if port is None:
        console.print(err_color+"获取端口失败...")
        return
    console.print(info_color+"端口："+value_color+port)
    console.print(info_color+"获取分区表...")
    gpt = get_gpt(port)
    if gpt == []:
        console.print(warn_color+"获取分区表失败/分区表长度为0？")
        pause()
        return

    extract([p for p in gpt if p.name == "userdata"], save_path, port, skip_userdata=False)
    write_bytesfile(save_path+"\\rawprogram0.xml","</data>\n".encode("utf-8"),False)
    
    console.print(info_color+"重启设备...")
    run_command(rf"fh_loader --port=\\.\{port} --noprompt --reset",encoding="gbk",show_output=False)
    console.print(success_color+"执行完成！")
    progress.stop()
    pause()


def main_2():
    mode = wait_for_device(mode="any")
    if mode == "adb":
        save_path = input_prompt("请输入保存的路径: ",default_text=F"{BACKUP_PATH}\\partitions_bak\\{getprop('ro.product.model')}_{get_saving_name()}\\")
        console.print(info_color+"重启至edl...")
        run_command("adb reboot edl")
        wait_for_device(mode="edl")
    elif mode == "edl":
        save_path = input_prompt("请输入保存的路径: ",default_text=F"{BACKUP_PATH}\\partitions_bak\\edldev_{get_saving_name()}\\")
    else:
        console.print(err_color+"请重启到edl/正常模式再使用此功能...")
        pause()
        return
    if not exist(save_path):md(save_path)
    
    console.print(tip_color+"当前连接设备：",end="")
    port = between(run_command("lsusb"),"(",")",not_found=None)
    if port is None:
        console.print(err_color+"获取端口失败...")
        return
    console.print(info_color+"端口："+value_color+port)
    console.print(info_color+"获取分区表...")
    gpt = get_gpt(port)
    if gpt == []:
        console.print(warn_color+"获取分区表失败/分区表长度为0？")
        pause()
        return
    
    write_bytesfile(save_path+"\\rawprogram0.xml","""<?xml version="1.0" ?>
<data>
\t<!-- 由提取分区功能自动生成的刷机脚本-->
""".encode("utf-8"))
    
    extract(gpt, save_path, port)
    write_bytesfile(save_path+"\\rawprogram0.xml","</data>\n".encode("utf-8"),False)
    
    console.print(info_color+"重启设备...")
    run_command(rf"fh_loader --port=\\.\{port} --noprompt --reset",encoding="gbk",show_output=False)
    console.print(success_color+"执行完成！")
    progress.stop()
    pause()


from src.init_utils import *



CONTENT_BOOT_ALL = """\n\n
on property:sys.boot_completed=1
    setprop persist.sys.usb.config diag,serial_cdev,rmnet,dpl,adb
    setprop sys.usb.config diag,serial_cdev,rmnet,dpl,adb
    setprop persist.sys.adb.install 1"""

CONTENT_BOOT_FORMATTER = """\n\n
on property:sys.boot_completed=1
    setprop persist.sys.usb.config {}
    setprop sys.usb.config {}"""

content = {
    "auto_all": CONTENT_BOOT_ALL,
}

def patch(path:str, patch:Literal["auto_all"]="auto_all"):
    f = open(path,"r")
    if content[patch] not in f.read():
        f.close()
        f = open(path,"a")
        f.write(CONTENT_BOOT_ALL)
    f.close()

def unpatch(path:str, patch:Literal["auto_all"]="auto_all"):
    f = open(path, "r")
    S = f.read()
    if content[patch] not in S:
        f.close()
        f = open(path, "w")
        f.write(S.replace(content[patch], ""))
    f.close()




import src.features.modules.module3
from src.init_utils import *
from src.init_utils import SysCommand as SC, ScriptCommand as RC, FlashProgram as FC


SCRIPT_FILE_NAME = f"script:{__name__}"

def _print(*args,**kwargs) -> str:
    "根据给定的参数来生成一个字符串用来exec()"
    para = ""
    for key in kwargs.keys():
        if isinstance(kwargs[key],str):
            kwargs[key] = "\"" + kwargs[key] + "\""
        para += str(key) + "=" + str(kwargs[key]) + ","
    para = para[0:-1]
    _args = []
    for item in args:
        _args.append(item)
    if len(_args) == 1:
        _args = _args[0]
        if isinstance(_args,str):
            _args = "\"" + _args + "\""
    else:
        _args = str(_args)[0:-1][1:]

    return f"console.print({_args},{para})"


def _sleep(time:float):
    "和_print一样"
    return f"time.sleep({time})"

def _timeout(time:int):
    "和_sleep一样"
    return f"os.system('timeout {time}')"

flash_schemes:Dict[str, Union[str, Dict[str, List[str]]]] = {
    "desc": "通过将修补过后的boot镜像刷回去实现root",
    "supports": {
        "Z2Y":   ["3.0.2"],
        "Z3":    ["3.0.2"],
        "Z5A":   ["1.9.1"],
        "Z5PRO": ["1.1.5"],
        "Z5Q":   ["3.5.1"],
        "Z6":    ["1.4.6"]
    }

}


flash_schemes_2:Dict[str, Union[str, Dict[str, List[str]]]] = {
    "desc": "通过将修补过后的boot镜像刷入recovery并启动recovery实现root",
    "supports": {
        "Z6_DFB": ["1.4.2", "2.3.0"],
        "Z7":     ["1.7.2", "2.0.0"],
        "Z7A":    ["1.4.0"],
        "Z8":     ["2.2.1"],
        "Z8_SNB": ["2.2.1"]
    }
}

flash_schemes_3:Dict[str, Union[str, Dict[str, List[str]]]] = {
    "desc": "通过将修补过后的boot镜像刷入boot并启动修改aboot实现root",
    "supports": {
        "Z7":     ["2.3.0"],
        "Z7S":    ["1.3.2"],
        "Z8":     ["2.7.4"],
        "Z8_SNB": ["2.7.4"],
        "Z8A":    ["1.0.8"],
        "Z9":     ["2.4.5"]
    }
}

special_flash_schemes:Dict[str, Dict[str, List[Union[RC, SC, FC]]]] = {
    "D3": {
        "2.3.8": [
                RC("wait_for_device()"),
                RC(_print(info_color+"将设备重启到fastboot模式...")),
                SC("adb reboot bootloader"),
                RC(_print(info_color+"刷入boot镜像...")),
                SC(f"fastboot flash boot {FIRMWARE_PATH}\\D3\\D3_2.3.8.img"),
                RC(_print(info_color+"重启设备...")),
                SC("fastboot reboot"),
                RC(_print(success_color+r"完成！（步骤1/3）\n")),
                RC(_print(info_color+"等待设备开机（60秒，按任意键可以继续）")),
                RC(_timeout(60)),
                RC(_print(info_color+"开始修复环境...")),
                RC("fix_magisk_env()"),
                RC(_print(success_color+r"完成！（步骤2/3）\n")),
                RC(_print(info_color+"等待设备开机（60秒，按任意键可以继续）")),
                RC(_timeout(60)),
                RC(_print(info_color+"开始安装模块...")),
                RC(f"install_module('{FILE_PATH}\\module.zip',True)"),
                RC(_print(success_color+"全部完成！（步骤3/3）"))
        ]
    }
}


def get_flash_scheme(model:str="Z8",version:str="2.7.4") -> Union[List[Union[RC, SC, FC]], None]:
    "获取刷机方案（只有root的方案）"
    global flash_schemes, flash_schemes_2, flash_schemes_3




    try:
        special_flash_schemes[model]
    except:
        console.print(err_color+f'目前貌似没有适配{model}的{version}版本的刷机方案...')
        raise Script.Exceptions.Features.FlashSchemeNotFoundError(f'目前貌似没有适配{model}的{version}版本的刷机方案...')

    try:
        return special_flash_schemes[model][version]
    except:
        console.print(err_color+f'目前貌似没有适配{model}的{version}版本的刷机方案...')
        raise Script.Exceptions.Features.FlashSchemeNotFoundError(f'目前貌似没有适配{model}的{version}版本的刷机方案...')
        


        
def main():
    pause("目前仅适用D3_2.3.8，如果对不上不要继续运行，按任意键继续")
    for item in get_flash_scheme("D3", "2.3.8"):
        item.execute()
    pause()



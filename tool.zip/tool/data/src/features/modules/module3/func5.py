from src.init_utils import *

import src.features.modules.module3.boot_patch.boot_patch_25200_special as patch

SCRIPT_FILE_NAME = f"script:{__name__}"


def test():
    console.print(warn_color+"此功能用于测试最新现场修补方案（aboot+boot），暂不稳定")
    if not confirm_prompt("是否继续？",True):
        return
    console.print(tip_color+"是否尝试在开机时自动开启adb？（有小概率会卡住导致开不了）")
    console.print(tip_color+"提示：如果用了这项功能后adb没了可以用功能3-6修复，但是需要短接")
    patch_usb = confirm_prompt("是否启用？")
    flash_userdata = confirm_prompt("是否清除userdata？")

    if wait_for_device(mode="any") == "adb":
        console.print(info_color+"重启至edl...")
        run_command("adb reboot edl")
    wait_for_device(mode="edl")
    console.print(tip_color+"当前连接设备：",end="")
    port = between(run_command("lsusb"),"(",")",not_found="None")
    if port == "None":
        console.print(err_color+"获取端口失败...")
        return
    console.print(info_color+"端口："+value_color+port)
    console.print(info_color+"提取boot...")
    tmp_boot_path = f"{CACHE_PATH}\\boot.img"
    tmp_boot_out = f"{CACHE_PATH}\\new-boot.img"
    stat = extract_partition(port,mode=("by_name", "boot"),output_file=tmp_boot_path,reset=False)
    if stat:
        console.print(err_color+f"提取boot分区失败...({stat})")
        return
    console.print(info_color+"修补boot...")
    stat = patch.patch(tmp_boot_path,tmp_boot_out,patch_usb=patch_usb)
    if stat:
        console.print(err_color+f"修补boot失败...({stat})")
        return 
    if wait_for_device(mode="any") == "adb":
        console.print(info_color+"重启至edl...")
        run_command("adb reboot edl")
    wait_for_device(mode="edl")
    console.print(tip_color+"当前连接设备：",end="")
    port = between(run_command("lsusb"),"(",")")
    if port is None:
        console.print(err_color+"获取端口失败...")
        return
    console.print(info_color+"端口："+value_color+port)
    console.print(info_color+"刷入boot, aboot和userdata...")
    mode = [("boot", tmp_boot_out),
            ("aboot",f"{FIRMWARE_PATH}\\aboot.img"),
            ("userdata",f"{FIRMWARE_PATH}\\userdata.img")]
    if not flash_userdata:
        mode = mode[:-1]
    flash_partition(port=port,
                    mode=mode,
                    reset=True)
    console.print(info_color+"完成！")
    wait_for_device()
    console.print(info_color+"完成！")

    wait_for_device()
    console.print(info_color+"延迟5秒等待系统运行...")
    time.sleep(5)
    run_command("adb shell dumpsys battery unplug")
    run_command("adb shell wm density 200")
    pause("""在进行接下来的操作以前，需要帮忙操作一下
做完新手引导之后，
打开Magisk（黑屏的话右滑退出重进就行）
点击右上角的三个点来打开设置界面,
往下翻，找到自动响应，设置为允许,
超级用户提示设置为无,
点击底边栏的盾牌,
打开shell访问权限的开关（字显示不出来，如果有开关的话直接打开）
操作完后按任意键继续""")
    console.print(info_color+"完成！")
    

    
    
    
        


def main():
    test()
    pause()
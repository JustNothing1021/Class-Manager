from src.init_utils import *

import src.features.modules.module3.boot_patch.boot_patch as boot_patch

SCRIPT_FILE_NAME = f"script:{__name__}"

"笑死，我对着boot_patch.sh写出来的"

def replace_adbd(show_output):
   console.print(info_color+"替换adbd...")

   run_command(["magiskboot", "cpio", "ramdisk.cpio",
                f"add 0750 sbin/adbd {FILE_PATH}\\android\\adbd\\adbd_new"],
                show_output=True)

def main():
   
   in_img = input_prompt("请输入需要修补的镜像的路径：",
                        validator=lambda string:not(string == "" or " " in string),
                        error_message="请输入路径/路径中不含有空格")
   out_img = input_prompt("请输入保存镜像的路径：",
                         validator=lambda string:not(string == "" or " " in string),
                         error_message="请输入路径/路径中不含有空格",
                         default_text=cwd+"\\new-boot.img")
   
   
   if os.path.isdir(out_img):
      if not out_img.endswith("\\"):
         out_img += "\\"
      out_img += "new-boot.img"
      console.print(tip_color+"输入的为一个文件夹，将保存到该文件夹的new-boot.img中")

   boot_patch.patch(in_img,
                    out_img, 
                    f"{FILE_PATH}\\Magisk-v23.0.apk")
   pause()
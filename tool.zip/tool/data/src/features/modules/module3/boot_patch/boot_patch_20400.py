from src.init_utils import *
import src.features.modules.module3.boot_patch.boot_patch as boot_patch
SCRIPT_FILE_NAME = f"script:{__name__}"

"笑死，我对着boot_patch.sh写出来的"

def main():
   
   in_img = input_prompt("请输入需要修补的镜像的路径：",
                        validator=lambda string:not(string == "" or " " in string),
                        error_message="请输入路径/路径中不含有空格")
   out_img = input_prompt("请输入保存镜像的路径：",
                         validator=lambda string:not(string == "" or " " in string),
                         error_message="请输入路径/路径中不含有空格",
                         default_text=cwd+"\\new-boot.img")
   if exist(out_img):
      console.print(warn_color+"该文件已经存在，继续可能导致打包失败")
   boot_patch.patch(in_img,out_img,f"{FILE_PATH}\\Magisk-v20.4.zip")
   pause()
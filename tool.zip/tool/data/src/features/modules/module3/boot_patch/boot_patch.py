from src.init_utils import *
SCRIPT_FILE_NAME = f"script:{__name__}"

"笑死，我对着boot_patch.sh写出来的"


def foo():
    "传个函数给magisk_patch可以额外修补"
    time

def unpack_magisk(magisk:StrOrBytesPath, 
                  arch:Literal["arm64-v8a","armeabi-v7a","x86_64","x86"]="armeabi-v7a",
                  show_output=True) -> Tuple[StrOrBytesPath, bool, Optional[str], Optional[Union[str, int]]]:
                                    #        原cwd         是否成功   magisk版本      版本号
    cwd_old = os.getcwd()
    try:
        extract_zipfile(magisk,f"{CACHE_PATH}\\magisk_arch")
        
    except:
        console.print(err_color+F"指定的Magisk包不存在/不为压缩包...\[{magisk}]")
        return (cwd_old, False, None, None)
    
    os.chdir(CACHE_PATH+"\\magisk_arch")
    cwd=CACHE_PATH+"\\magisk_arch"

    if show_output:console.print(info_color+"解包工具中...")
    get_list = []
    if arch == "arm64-v8a":
        get_list = [
            "lib\\armeabi-v7a\\libmagiskinit.so",
            "lib\\armeabi-v7a\\libmagisk32.so",
            "lib\\armeabi-v7a\\libmagisk64.so",
            "lib\\arm64-v8a\\libmagiskinit.so",
            "lib\\arm64-v8a\\libmagisk64.so",       # 如果存在是会覆盖掉的
            "arm\\magiskinit",
            "arm\\magiskinit64"
        ]
    elif arch == "armeabi-v7a":
        get_list = [
            "lib\\armeabi-v7a\\libmagiskinit.so",
            "lib\\armeabi-v7a\\libmagisk32.so",
            "arm\\magiskinit",
        ]
    elif arch == "x86_64":
        get_list = [
            "lib\\x86\\libmagiskinit.so",
            "lib\\x86\\libmagisk32.so",
            "lib\\x86\\libmagisk64.so",
            "lib\\x86_64\\libmagiskinit.so",
            "lib\\x86_64\\libmagisk64.so",
            "x86\\magiskinit",
            "x86\\magiskinit64"
        ]

    elif arch == "x86":
        get_list = [
            "lib\\x86\\libmagiskinit.so",
            "lib\\x86\\libmagisk32.so",
            "x86\\magiskinit"
        ]
    get_list.append("assets\\stub.apk") # 老/新版本管理器

    for f in get_list:
        if exist(f):
            cp(f, cwd)
    if exist("magiskinit64"):
        if exist("magiskinit"):
            remove("magiskinit")
        ren("magiskinit64","magiskinit")
    if exist("libmagiskinit.so"):
        if exist("magiskinit"):
            remove("magiskinit")
        ren("libmagiskinit.so","magiskinit")
    if exist("libmagisk32.so"):
        run_command("magiskboot.exe compress=xz libmagisk32.so magisk32.xz",write_in_log=False)
        remove("libmagisk32.so")
    if exist("libmagisk64.so"):
        run_command("magiskboot.exe compress=xz libmagisk64.so magisk64.xz",write_in_log=False)
        remove("libmagisk64.so")
    if exist("stub.apk"):
        run_command("magiskboot.exe compress=xz stub.apk stub.xz",write_in_log=False)
        remove("stub.apk")
    try:
        magisk_ver = read_textfile("assets\\util_functions.sh").split("MAGISK_VER=")[1][1:].split("\n")[0][0:-1]
        magisk_ver_code = int(read_textfile("assets\\util_functions.sh").split("MAGISK_VER_CODE=")[1].split("\n")[0])
    except:
        try:
            magisk_ver = read_textfile("common\\util_functions.sh").split("MAGISK_VER=")[1][1:].split("\n")[0][0:-1].strip()
            try:
                magisk_ver_code = int(read_textfile("common\\util_functions.sh").split("MAGISK_VER_CODE=")[1].split("\n")[0])
            except:
                magisk_ver_code = read_textfile("common\\util_functions.sh").split("MAGISK_VER_CODE=")[1].split("\n")[0].strip()
        except:
            console.print(err_color+f"指定的压缩文件\[{magisk}]不是一个magisk包...")
            os.chdir(cwd_old)
            return (cwd_old, False, None, None)
    if show_output:
        console.print(info_color+f"Magisk版本：{info_color}{magisk_ver}{close_tag}({value_color}{magisk_ver_code}{close_tag})")
        console.print(success_color+"完成！")
    return (cwd_old, True, magisk_ver, magisk_ver_code)


def unpack_boot(image:StrOrBytesPath, cwd_old:StrOrBytesPath, show_output:bool) -> \
                Tuple[StrOrBytesPath, bool, Optional[int], Optional[bool], Optional[str]]:
                #      cwd_old       is_OK    status        CHORMEOS         SHA1     懒得写中文了
    CHORMEOS = False
    status, output = run_command(f"magiskboot unpack {image}",return_type="statusoutput",output_by_tuple=True,encoding="gbk",show_output=show_output)
    if output.stderr != "":
        print(output.stderr)
    if status == 2:
        if show_output:
            console.print(warn_color+"检测到此镜像为ChromeOS镜像，不会做特殊操作，但是会继续")
        CHORMEOS = True
    elif status == 1:
        if show_output:
            console.print(err_color+"此镜像为未知或不支持的boot镜像...")
        os.chdir(cwd_old)
        return (cwd_old, False, status, None, None)
    elif status == 0 and show_output:
            console.print(success_color+"解包完成！\n")
    else:
        if show_output:
            console.print(err_color+"未知原因解包失败...")
        os.chdir(cwd_old)
        return (cwd_old, False, status, None, None)

    OS_VERSION = between(output.stderr,"OS_VERSION      [","]",not_found="未知")
    BUILD_SOFT_VERSION = between(output.stderr,"buildsoftversion=","builduser=",not_found="未知")
    KERNEL_SZ = between(output.stderr,"KERNEL_SZ       [","]",not_found="未知")
    RAMDISK_SZ = between(output.stderr,"RAMDISK_SZ      [","]",not_found="未知")

    if show_output:
        console.print(info_color+"基本信息："+F"""{tip_color}
内核大小：   {value_color}{KERNEL_SZ}{close_tag}
ramdisk大小：{value_color}{RAMDISK_SZ}{close_tag}
Android版本：{value_color}{OS_VERSION}{close_tag}
系统版本：   {value_color}{BUILD_SOFT_VERSION}{close_tag}
""")
        
    if show_output:
        console.print(info_color+"\n检测ramdisk状态...")


    if os.path.isfile("ramdisk.cpio"):
        status = run_command("magiskboot cpio ramdisk.cpio test",return_type="status",show_output=show_output)
    else:
        status = 0

    SHA1 = ""

    if status & 3 == 0:
        if show_output:
            console.print(tip_color+"检测到该镜像为常规镜像")
        SHA1 = run_command(F"magiskboot sha1 {image} 2>nul",show_output=show_output)  # 获取SHA1
        copy(image, "stock_boot.img")
        cp("ramdisk.cpio", "ramdisk.cpio.orig")

    elif status & 3 == 1:
        if show_output:
            console.print(tip_color+"检测到该镜像为被Magisk修补过的镜像")
        try:
            SHA1 = os.getenv("SHA1")
        except:
            SHA1 = ""
        if SHA1 is None:
            SHA1 = ""
        if len(SHA1) <= 1:
            SHA1 = run_command("magiskboot cpio ramdisk.cpio sha1 2>nul",show_output=show_output) # 获取原本镜像的SHA1
            run_command("magiskboot cpio ramdisk.cpio restore",show_output=show_output) # 恢复原来的ramdisk
            cp("ramdisk.cpio","ramdisk.cpio.orig")
            if exist("stock_boot.img"):
                remove("stock_boot.img")


    elif status & 3 == 2:
        if show_output:
            console.print(err_color+"该boot镜像已被其他程序修补过...")
        os.chdir(cwd_old)
        return (cwd_old, False, status, None, None)

    if show_output:
        console.print(tip_color+f"SHA1:{value_color}{SHA1}")
    return (cwd_old, True, status, CHORMEOS, SHA1)


def magisk_patch(
    status:int,
    SHA1:str,
    magisk_ver_code:int,
    cwd_old:StrOrBytesPath,
    arch:Literal["arm64-v8a","armeabi-v7a","x86_64","x86"]="armeabi-v7a",
    keep_verity=False,              # 修补AVB 2.0/verity
    keep_force_encrypt=False,       # 保持强制加密
    patch_vbmeta_flag=False,       # 修补vbmeta标记
    recovery_mode=False,           # 安装到Recovery
    system_root=True,              # 强制开启rootfs(26000以下自动为True)
    show_output=False,
    extra=foo,
) -> Union[StrOrBytesPath, bool]:
    #        cwd_old       is_ok
    INIT = "init"

    if magisk_ver_code >= 25200:
        
        if (status & 4) != 0:
            INIT = "init.real"
    if magisk_ver_code < 26000 and not system_root:
        system_root = True
        if show_output:
            console.print(warn_color+"SYSTEMROOT目前只有高于26000的版本才能指定，自动设置为True")

    SKIP32 = "#"        # 因为井号是注释，如果要跳过这一步的话就把变量设成井号
    SKIP64 = "#"
    if show_output:
        console.print(info_color+"\n修补ramdisk...")
        console.print(info_color+"配置：")

    if magisk_ver_code == 26000:
        if show_output:
            console.print(warn_color+"由于技术原因，将会跳过PREINITDEVICE的设置（我是sb，不会）")
        config = {  "KEEPVERITY" : str(keep_verity).lower(),
                    "KEEPFORCEENCRYPT" : str(keep_force_encrypt).lower(),
                    "PATCHVBMETAFLAG" : str(patch_vbmeta_flag).lower(),
                    "RECOVERYMODE" : str(recovery_mode).lower(),
                    "RANDOMSEED" : "0x"+random_string_generator(strlen=16)}
        if SHA1 != "":
            config["SHA1"] = SHA1
        if arch in ("arm64-v8a", "x86_64"):
            SKIP64 = ""
        if arch in ("armeabi-v7a", "x86"):
            SKIP32 = ""
        patch_cpio_cmd = [  "magiskboot", "cpio", "ramdisk.cpio",
                            f"add 0750 {INIT} magiskinit",
                            "mkdir 0750 overlay.d",
                            "mkdir 0750 overlay.d/sbin",
                            f"{SKIP32} add 0644 overlay.d/sbin/magisk32.xz magisk32.xz",
                            f"{SKIP64} add 0644 overlay.d/sbin/magisk64.xz magisk64.xz",
                            "add 0644 overlay.d/sbin/stub.xz stub.xz",
                            "patch",
                            "backup ramdisk.cpio.orig",
                            "mkdir 000 .backup",
                            "add 000 .backup/.magisk config"]



    elif magisk_ver_code == 25200:
        config = {  "KEEPVERITY" : str(keep_verity).lower(),
                    "KEEPFORCEENCRYPT" : str(keep_force_encrypt).lower(),
                    "PATCHVBMETAFLAG" : str(patch_vbmeta_flag).lower(),
                    "RECOVERYMODE" : str(recovery_mode).lower()}
        if SHA1 != "":config["SHA1"] = SHA1
        if arch in ("arm64-v8a", "x86_64"):
            SKIP64 = ""
        if arch in ("armeabi-v7a", "x86"):
            SKIP32 = ""
        patch_cpio_cmd = ["magiskboot", "cpio", "ramdisk.cpio",
                         f"add 0750 {INIT} magiskinit",
                          "mkdir 0750 overlay.d",
                          "mkdir 0750 overlay.d/sbin",
                         f"{SKIP32} add 0644 overlay.d/sbin/magisk32.xz magisk32.xz",
                         f"{SKIP64} add 0644 overlay.d/sbin/magisk64.xz magisk64.xz",
                          "patch",
                          "backup ramdisk.cpio.orig",
                          "mkdir 000 .backup",
                          "add 000 .backup/.magisk config"]
 


    elif magisk_ver_code == 23000:
        if exist("recovery_dtbo"):
            recovery_mode = True
            if show_output:
                console.print(tip_color+"解包时发现recovery_dtbo，强制设置RECOVERYMODE为true")

        config = {  "KEEPVERITY" : str(keep_verity).lower(),
                    "KEEPFORCEENCRYPT" : str(keep_force_encrypt).lower(),
                    "RECOVERYMODE" : str(recovery_mode).lower()}
        if SHA1 != "":config["SHA1"] = SHA1
        if arch in ("arm64-v8a", "x86_64"):
            SKIP64 = ""
        if arch in ("armeabi-v7a", "x86"):
            SKIP32 = ""
        patch_cpio_cmd = ["magiskboot", "cpio", "ramdisk.cpio",
                         f"add 0750 {INIT} magiskinit",
                          "mkdir 0750 overlay.d",
                          "mkdir 0750 overlay.d/sbin",
                         f"{SKIP32} add 0644 overlay.d/sbin/magisk32.xz magisk32.xz",
                         f"{SKIP64} add 0644 overlay.d/sbin/magisk64.xz magisk64.xz",
                          "patch",
                          "backup ramdisk.cpio.orig",
                          "mkdir 000 .backup",
                          "add 000 .backup/.magisk config"]
        
    elif magisk_ver_code == 20400:
        if exist("recovery_dtbo"):
            recovery_mode = True
            if show_output:
                console.print(tip_color+"解包时发现recovery_dtbo，强制设置RECOVERYMODE为true")
        if status & 8 != 0:
            os.environ["TWOSTAGEINIT"]="true"
        config = {  "KEEPVERITY" : str(keep_verity).lower(),
                    "KEEPFORCEENCRYPT" : str(keep_force_encrypt).lower(),
                    "RECOVERYMODE" : str(recovery_mode).lower()}
        if SHA1 != "":config["SHA1"] = SHA1
        if arch in ("arm64-v8a", "x86_64"):
            SKIP64 = ""
        if arch in ("armeabi-v7a", "x86"):
            SKIP32 = ""
        patch_cpio_cmd = ["magiskboot", "cpio", "ramdisk.cpio",
                          "add 750 init magiskinit",
                          "patch",
                          "backup ramdisk.cpio.orig",
                          "mkdir 000 .backup",
                          "add 000 .backup/.magisk config"]
        
        
    else:
        if show_output:
            console.print(err_color+"当前版本不支持！")
        return (cwd_old, False)
    


    cf = open("config",mode="w")
    for k in config.keys():
        v = config[k]
        os.environ[k] = v
        cf.write(str(k) + "=" + str(v))
        if show_output:
            console.print(tip_color + "\t" + k + "=" + value_color + v)
    cf.close()

    run_command(patch_cpio_cmd,show_output=show_output)
    if magisk_ver_code == 20400:
        if status & 4 != 0:
            if show_output:
                console.print(info_color+"压缩ramdisk...")
            run_command("magiskboot cpio ramdisk.cpio compress")
        dtb_list = ["dtb", "kernel_dtb", "extra", "recovery_dtbo"]
    else:
        dtb_list = ["dtb", "kernel_dtb", "extra"]


    for dt in dtb_list:
        if exist(dt):
            if run_command(f"magiskboot dtb {dt} test",return_type="status",show_output=show_output) != 0:    # 用返回值是否为0判断是否出错
                if show_output:
                    console.print(err_color+"镜像不支持的老版本修补过了...")
                os.chdir(cwd_old)
                return (cwd_old, False)
            if run_command(f"magiskboot dtb {dt} patch",return_type="status",show_output=show_output) == 0:
                if show_output:
                    console.print(info_color+f"修补了{dt}中的fstab")

    patched_kernel = False
    if os.path.isfile("kernel"):

        if show_output:
            console.print(info_color+"\n修补kernel...")
        # 虽然小棺材应该不用这个但还是写一下吧
        # 移除三星设备的RKP（远程密钥配置）
        output = run_command(["magiskboot", "hexpatch", "kernel",
"49010054011440B93FA00F71E9000054010840B93FA00F7189000054001840B91FA00F7188010054",
"A1020054011440B93FA00F7140020054010840B93FA00F71E0010054001840B91FA00F7181010054"],show_output=show_output)
        if strip(output) != "":
            patched_kernel = True


        
        # 也是和三星有关的，直接搬原文了
        # Remove Samsung defex
        # Before: [mov w2, #-221]   (-__NR_execve)
        # After:  [mov w2, #-32768]
        output = run_command("magiskboot hexpatch kernel 821B8012 E2FF8F12",show_output=show_output)
        if strip(output) != "":
            patched_kernel = True

        # 强制内核加载rootfs（这个基本都要用到）
        # skip_initramfs -> want_initramfs
        if system_root:
            output = run_command(["magiskboot",
                                  "hexpatch",
                                  "kernel",
                                  "736B69705F696E697472616D667300",
                                  "77616E745F696E697472616D667300"],
                                  show_output=show_output)
            if strip(output) != "":
                patched_kernel = True
            
        if magisk_ver_code >= 26000:
            if not patched_kernel:
                remove("kernel")
                if show_output:
                    console.print(warn_color+"由于并未对kernel做任何修补，已经把kernel删除")
            else:
                if show_output:
                    console.print(success_color+"完成！")
        extra(show_output)
        return (cwd_old, True)
    
            
def repack_boot(image:StrOrBytesPath,
                target_image:StrOrBytesPath,
                show_output=False):
    return run_command(f"magiskboot repack {image} {target_image}",return_type="status",encoding="gbk",show_output=show_output)

def patch(image:str,
    target:str,
    magisk:str=f"{FILE_PATH}\\Magisk-v25.2.apk",       # 借用了某贼的整合思路（懒得一个个分类写了          
    arch:Literal["arm64-v8a","armeabi-v7a","x86_64","x86"]="armeabi-v7a", #cpu架构
    show_output=False,
    keep_verity=False,              # 修补AVB 2.0/verity
    keep_force_encrypt=False,       # 保持强制加密
    patch_vbmeta_flag=False,       # 修补vbmeta标记
    recovery_mode=False,           # 安装到Recovery
    system_root=True,              # 强制开启rootfs(26000以下自动为True)
    patch_extra=foo
    ) -> int:
    "用magisk修补一个boot镜像。"
    
    cwd_old, is_ok, magisk_ver, magisk_ver_code = unpack_magisk(magisk, arch, show_output)
    if not is_ok:
        console.print(err_color+"解包工具失败...")
        return 1

    if not os.path.isfile(image):
        console.print(err_color+f"指定的文件{warn_color}{image}{close_tag}并不存在...")
        os.chdir(cwd_old)
        return 1
    console.print(info_color+"解包boot镜像...")
    cwd_old, is_ok, status, CHORMEOS, SHA1 = unpack_boot(image, cwd_old, True)
    if not is_ok:
        console.print(err_color+f"解包boot失败...({status})")
        return status

    cwd_old, is_ok = magisk_patch(status, SHA1, magisk_ver_code, cwd_old, 
                                  arch, keep_verity, keep_force_encrypt,
                                  patch_vbmeta_flag, recovery_mode, system_root,
                                  show_output, patch_extra)
    
    if not is_ok:
        console.print(err_color+"修补boot失败...")
        return 1

    console.print(info_color+"\n重新打包镜像...")
    if not repack_boot(image, target, show_output):
        console.print(success_color+"完成！")
        if CHORMEOS:
            console.print(warn_color+"警告：当前并未对chormeos做任何特殊操作（因为这应该和小棺材没关系）")
    else:
        console.print(err_color+"打包失败...")
    cwd = os.getcwd()
    os.chdir(cwd_old)
    rmtree(cwd)
    return 0



def main():
    cwd_old = os.getcwd()
    try:
        console.print(warn_color+"该功能目前还在测试，可能有未知风险")
        console.print(warn_color+f"目前该功能{err_color}不会对ChormeOS镜像做任何特殊处理{close_tag}，请注意")
        image = input_prompt("请输入boot镜像的路径:",
                            validator=lambda s:s != "",
                            error_message="请输入路径!")
        if " " in image and not (image.startswith("\"") and image.endswith("\"")):
            image = "\" "+ image + "\""

        target = input_prompt("请输入boot镜像修补后保存的路径:",
                            validator=lambda s:s != "",
                            error_message="请输入路径!")
        if " " in target and not (target.startswith("\"") and target.endswith("\"")):
            target = "\" "+ target + "\""
        if os.path.isdir(target):
            if target.endswith("\\"):
                target += "new-boot.img"
            else:
                target += "\\new-boot.img"

        magisk = input_prompt("请输入Magisk包的路径:",
                            validator=lambda s:s != "",
                            error_message="请输入路径!")
        if " " in magisk and not (magisk.startswith("\"") and magisk.endswith("\"")):
            magisk = "\" "+ magisk + "\""

        arch = ListPrompt("请选择CPU架构",
                        [Choice("aremabi-v7a(arm_32)","aremabi-v7a"),
                        Choice("arm64-v8a(arm_64)","arm64-v8a"),
                        Choice("x86(x86_32)","x86"),
                        Choice("x86_64","x86_64")],
                        annotation=ListPrompt_annotation,
                        pointer=ListPrompt_pointer).prompt(style=ListPrompt_style).data
        

        keep_verity = confirm_prompt("是否需要保留AVB 2.0/dm-verity?（小天才不建议保留）")
        keep_force_encrypt = confirm_prompt("是否保持强制加密？",default_select=True)
        patch_vbmeta_flag = confirm_prompt("是否修补vbmeta标记?")
        recovery_mode = confirm_prompt("安装到Recovery(230000及以下解包出现recovery_dtbo自动为True)？")
        system_root = confirm_prompt("是否强制开启rootfs(26000以下自动为True) ？",default_select=True)

        console.print(info_color+"开始修补...")




        patch(image=image,
            target=target,
            magisk=magisk,
            keep_verity=keep_verity,
            keep_force_encrypt=keep_force_encrypt,
            patch_vbmeta_flag=patch_vbmeta_flag,
            recovery_mode=recovery_mode,
            system_root=system_root,
            arch=arch,
            show_output=True)
        pause(success_color+"完成！（按任意键继续）")
    except:
        os.chdir(cwd_old)
        raise



            










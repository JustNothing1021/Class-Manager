from src.init_utils import *

def patch(image:StrOrBytesPath,
          target:StrOrBytesPath,
          patch_usb:bool=True,
          show_output:bool=False,
          output_log_level:Literal[0, 1, 2, 3]=2) -> int:
    "用magisk修补一个boot镜像，但是这是特殊方案"
    cwd_old = os.getcwd()

    if exist(f"{CACHE_PATH}\\magisk_arch"):rmtree(f"{CACHE_PATH}\\magisk_arch")
    extract_zipfile(f"{FILE_PATH}\\Magisk-v25.2.apk", f"{CACHE_PATH}\\magisk_arch")
    os.chdir(CACHE_PATH+"\\magisk_arch")
    cwd = CACHE_PATH+"\\magisk_arch"

    if output_log_level >= 2:
        console.print(info_color+"解包工具中...")

    get_list = [
            "lib\\armeabi-v7a\\libmagiskinit.so",
            "lib\\armeabi-v7a\\libmagisk32.so",
            "arm\\magiskinit"
            ]


    for f in get_list:
        if exist(f):
            cp(f, cwd)

    if exist("libmagiskinit.so"):
        if exist("magiskinit"):
            remove("magiskinit")
        ren("libmagiskinit.so","magiskinit")

    if exist("libmagisk32.so"):
        run_command("magiskboot.exe compress=xz libmagisk32.so magisk32.xz",write_in_log=False)
        remove("libmagisk32.so")

    rmtree("assets")
    rmtree("lib")
    rmtree("META-INF")
    rmtree("org")
    rmtree("res")
    remove("AndroidManifest.xml")
    remove("classes.dex")
    remove("resources.arsc")


    if not os.path.isfile(image):
        if output_log_level >= 1:
            console.print(err_color+f"指定的文件{warn_color}{image}{close_tag}并不存在...")
        os.chdir(cwd_old)
        return 1


    if output_log_level >= 2:
        console.print(info_color+"解包boot镜像...")
    status, output = run_command(f"magiskboot unpack -h {image}",return_type="statusoutput",encoding="gbk",show_output=show_output)
    if status == 2:
        if output_log_level >= 1:
            console.print(warn_color+"检测到此镜像为ChromeOS镜像，不会做特殊操作，但是会继续")
    elif status == 1:
        if output_log_level >= 1:
            console.print(err_color+"此镜像为未知或不支持的boot镜像...")
        os.chdir(cwd_old)
        return 1
    elif status == 0:
            if output_log_level >= 2:
                console.print(success_color+"解包完成！")
            if output_log_level >= 3:
                print()
    else:
        if output_log_level >= 1:
            console.print(err_color+"未知原因解包失败...")
        os.chdir(cwd_old)
        return 1

    OS_VERSION = between(output,"OS_VERSION      [","]",not_found="未知")
    BUILD_SOFT_VERSION = between(output,"buildsoftversion=","builduser=",not_found=success_color+"未知，可能在修补时已经移除"+close_tag)
    KERNEL_SZ = between(output,"KERNEL_SZ       [","]",not_found="未知")
    RAMDISK_SZ = between(output,"RAMDISK_SZ      [","]",not_found="未知")

    if output_log_level >= 3:
        console.print(info_color+"基本信息："+F"""{tip_color}
内核大小：   {value_color}{KERNEL_SZ}{close_tag}
ramdisk大小：{value_color}{RAMDISK_SZ}{close_tag}
Android版本：{value_color}{OS_VERSION}{close_tag}
系统版本：   {value_color}{BUILD_SOFT_VERSION}{close_tag}
""")
    
    if output_log_level >= 3:
        console.print(info_color+"\n检测ramdisk状态...")


    if os.path.isfile("ramdisk.cpio"):
        status = run_command("magiskboot cpio ramdisk.cpio test",return_type="status",show_output=show_output)
    else:
        status = 0

    SHA1 = ""

    if status & 3 == 0:
        if output_log_level >= 3:
            console.print(tip_color+"检测到该镜像为常规镜像")
        SHA1 = run_command(F"magiskboot sha1 {image}",show_output=show_output)  # 获取SHA1
        copy(image, "stock_boot.img")
        cp("ramdisk.cpio", "ramdisk.cpio.orig")


    

    elif status & 3 == 1:
        if output_log_level >= 3:
            console.print(tip_color+"检测到该镜像为被Magisk修补过的镜像")

        try:
            SHA1 = os.getenv("SHA1")
        except:
            SHA1 = ""
        if SHA1 is None:
            SHA1 = ""

        if len(SHA1) <= 1:
            SHA1 = run_command("magiskboot cpio ramdisk.cpio sha1",show_output=show_output) # 获取原本镜像的SHA1
            run_command("magiskboot cpio ramdisk.cpio restore",show_output=show_output) # 恢复原来的ramdisk
            cp("ramdisk.cpio","ramdisk.cpio.orig")
            if exist("stock_boot.img"):
                remove("stock_boot.img")


    elif status & 3 == 2:
        if output_log_level >= 1:
            console.print(err_color+"该boot镜像已被其他程序修补过...")
        os.chdir(cwd_old)
        return 1

    if output_log_level >= 3:
        console.print(tip_color+f"SHA1:{value_color}{SHA1}")

    INIT = "init"
    if (status & 4) != 0:
        INIT = "init.real"

    SKIP32 = ""
    SKIP64 = "#"

    if output_log_level >= 3:
        print()
    if output_log_level >= 2:
        console.print(info_color+"修补ramdisk...")
    if output_log_level >= 3:
        console.print(info_color+"配置：")

    config = {  "KEEPVERITY" : "true",
                "KEEPFORCEENCRYPT" : "true",
                "PATCHVBMETAFLAG" : "false",
                "RECOVERYMODE" : "false"}
    if SHA1 != "":config["SHA1"] = SHA1





    cf = open("config",mode="wb")

    for k in config.keys():
        v = config[k]
        os.environ[k] = v
        cf.write(str(str(k) + "=" + str(v) + "\n").encode("utf-8"))
        if output_log_level >= 3:
            console.print(tip_color + "\t" + k + "=" + value_color + v)

    cf.close()
    if output_log_level >= 3:
        console.print(info_color+"Magisk修补...")
    run_command(["magiskboot", "cpio", "ramdisk.cpio",
                f"add 0750 {INIT} magiskinit",
                 "mkdir 0750 overlay.d",
                 "mkdir 0750 overlay.d/sbin",
                f"{SKIP32} add 0644 overlay.d/sbin/magisk32.xz magisk32.xz",
                f"{SKIP64} add 0644 overlay.d/sbin/magisk64.xz magisk64.xz",
                 "patch",
                 "backup ramdisk.cpio.orig",
                 "mkdir 000 .backup",
                 "add 000 .backup/.magisk config"],show_output=show_output)
    
    if output_log_level >= 3:
        console.print(info_color+"替换adbd...")

    run_command(["magiskboot", "cpio", "ramdisk.cpio",
                f"add 0750 sbin/adbd {FILE_PATH}\\android\\adbd\\adbd_new"],
                show_output=show_output)
    if patch_usb:
    
        if output_log_level >= 3:
            console.print(info_color+"修改init.usb.rc...")

        run_command(["magiskboot", "cpio", "ramdisk.cpio",
                    "extract init.usb.rc init.usb.rc"],
                    show_output=show_output)
        
        from src.features.modules.module3.file_patch.init_usb import patch as _patch_usb
        cp("init.usb.rc", "init.usb.rc.orig")
        _patch_usb("init.usb.rc")

        run_command(["magiskboot", "cpio", "ramdisk.cpio",
                    "add 0644 init.usb.rc init.usb.rc"],
                    show_output=show_output)
        if output_log_level >= 2:
            console.print(success_color+"完成！")
        if output_log_level >= 3:
            print()

    else:
        from src.features.modules.module3.file_patch.init_usb import unpatch as _unpatch_usb
        cp("init.usb.rc", "init.usb.rc.orig")
        _unpatch_usb("init.usb.rc")


    if output_log_level >= 2:
        console.print(info_color+"修改header...")
    f = open("header", "rb")
    content = f.read()
    f.close()
    if "buildvariant=user".encode("utf-8") in content \
    and "buildvariant=userdebug".encode("utf-8") not in content:  # header修改："buildvariant=user" -> "buildvariant=userdebug"
        content = \
            content.split("buildvariant=".encode("utf-8"))[0] + \
            "buildvariant=userdebug ".encode("utf-8") + \
            content.split("buildvariant=".encode("utf-8"),1)[1].split(" ".encode("utf-8"),1)[1]


    if "buildsoftversion=".encode("utf-8") in content:               # header修改："buildsoftversion=x.x.x" -> ""
        content = content.split("buildsoftversion=".encode("utf-8"))[0] + \
                   content.split("buildsoftversion=".encode("utf-8"),1)[1].split(" ".encode("utf-8"),1)[1]

    if "androidboot.selinux=permissive".encode("utf-8") not in content: # header修改："" -> "androidboot.selinux=permissive"
        content = content.split("\n".encode("utf-8"))
        content_new = bytearray()
        for line in content:
            if line.decode("utf-8").startswith("cmdline="):
                line += bytearray(" androidboot.selinux=permissive".encode("utf-8"))
            content_new += line + "\n".encode("utf-8")
        content = content_new

    ren("header", "header_orig")
    f = open("header", "wb")
    f.write(content)
    f.close()


    dtb_list = ["dtb", "kernel_dtb", "extra"]


    for dt in dtb_list:
        if exist(dt):
            if run_command(f"magiskboot dtb {dt} test",return_type="status",show_output=show_output) != 0:    # 用返回值是否为0判断是否出错
                if output_log_level >= 1:
                    console.print(err_color+"镜像不支持的老版本修补过了...")
                os.chdir(cwd_old)
                return 1
            if run_command(f"magiskboot dtb {dt} patch",return_type="status",show_output=show_output) == 0:
                if output_log_level >= 2:
                    console.print(info_color+f"修补了{dt}中的fatab")


    if os.path.isfile("kernel"):
        if output_log_level >= 3:
            print()
        if output_log_level >= 2:
            console.print(info_color+"修补kernel...")
        # 虽然小棺材应该不用这个但还是写一下吧
        # 移除三星设备的RKP（远程密钥配置）
        output = run_command(["magiskboot", "hexpatch", "kernel",
"49010054011440B93FA00F71E9000054010840B93FA00F7189000054001840B91FA00F7188010054",
"A1020054011440B93FA00F7140020054010840B93FA00F71E0010054001840B91FA00F7181010054"],show_output=show_output)


        
        # 也是和三星有关的，直接搬原文了
        # Remove Samsung defex
        # Before: [mov w2, #-221]   (-__NR_execve)
        # After:  [mov w2, #-32768]
        output = run_command("magiskboot hexpatch kernel 821B8012 E2FF8F12",show_output=show_output)


        # 这里禁用rootfs
        # want_initramfs -> skip_initramfs 
        # （如果有的话，一般没有，除了我自己拿那个自己做的跟sh**一样的magisk修补器修过的boot）

        output = run_command(["magiskboot",
                              "hexpatch",
                              "kernel",
                              "77616E745F696E697472616D667300",
                              "736B69705F696E697472616D667300"],show_output=show_output)

    if output_log_level >= 3:
        print()        
    if output_log_level >= 2:
        console.print(info_color+"重新打包镜像...")
    if run_command(f"magiskboot repack {image} {target}",return_type="status",encoding="gbk",show_output=show_output) == 0:

        if output_log_level >= 2:
            console.print(success_color+"打包完成！")
    else:
        if output_log_level >= 1:
            console.print(err_color+"打包失败...")
    os.chdir(cwd_old)
    rmtree(cwd)
    cwd = cwd_old
    return 0

def main():
   
   in_img = input_prompt("请输入需要修补的镜像的路径：",
                        validator=lambda string:not(string == "" or " " in string),
                        error_message="请输入路径/路径中不含有空格")
   out_img = input_prompt("请输入保存镜像的路径（尽量指定文件）：",
                         validator=lambda string:not(string == "" or " " in string),
                         error_message="请输入路径/路径中不含有空格",
                         default_text=cwd+"\\new-boot.img")
   if os.path.isdir(out_img):
        if not out_img.endswith("\\"):
           out_img += "\\"
        out_img += "new-boot.img"
        console.print(tip_color+"输入的为一个文件夹，将保存到该文件夹的new-boot.img中")
        

   patch(in_img, out_img)
   pause()

from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"

def main(model:str, version:str):
    global OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH, BIN_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH, FIRMWARE_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, LOGLEVEL_FILEPATH, COMMON_MBN_PATH
    global cmd_executables
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global WIRELESS_PORT,IMPORTABLE
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global on_running_code_page
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, output
    global progress, support_error_desc, localtime
    wait_for_device()
    console.print(info_color+"将设备重启到9008模式...")
    run_command("adb reboot edl")
    flash_rawprogram(FIRMWARE_PATH, f"{model}_{version}.xml", False, send_mbn=F"{FIRMWARE_PATH}\\prog_emmc_firehose_8909w_ddr_{model}.mbn")
    console.print(info_color+"等待设备重启完成...（按任意键跳过）")

    target_magisk_version = get_firmware_info(f"{FIRMWARE_PATH}\\{model}_{version}.xml")["magisk_version"]
    console.print(info_color+"Magisk版本：",end="\n")
    magisk_version = run_command("adb wait-for-device shell magisk -v")
    print()
    if target_magisk_version in magisk_version:
        console.print(success_color + f"Magisk {target_magisk_version} 安装成功！")
    elif "not found" in magisk_version:
        console.print(err_color + "Magisk安装失败...")
    else:
        console.print(warn_color + "Magisk疑似安装失败...将会尝试继续")
    install_apk(f"{FILE_PATH}\\Magisk_20.4.apk")

import src

import src.features
import src.features.modules
from src.init_utils import *






SCRIPT_FILE_NAME = f"script:{__name__}"

module_name = "module3"

namespace = src.features.modules.module_list[module_name]["namespace"]

function_list:List[Script.Function] = []

prompt_list_max_height = 15

try:
    chcp(src.features.modules.module_list[module_name]["codepage"])
except:
    pass

for name in src.features.modules.module_list[module_name]["functions"].keys():
    info = src.features.modules.module_list[module_name]["functions"][name]
    function_list.append(Script.Function(info["name"],
                                         info["data"],
                                         info["desc"],
                                         info["imports"],
                                         info["executes"]))



def load_menu_prompt():
    "加载菜单，询问，执行"
    while True:
        global function_list, prompt_list_max_height
        function_list_iter = iter(function_list)
        choices = {}
        executes:Dict[Any,Script.Function] = {}
        while True:
            try:
                next_function = next(function_list_iter)
                choices[next_function.data] = next_function.name
                executes[next_function.data] = next_function
            except StopIteration:
                break

        result = load_functionmenu(
            src.features.modules.module_list[module_name]["name"],
            src.features.modules.module_list[module_name]["desc"],
            src.features.modules.module_list[module_name]["prompt"],
            choices,
            src.features.modules.module_list[module_name]["tip"],
            listmaxheight=prompt_list_max_height
        )
        if result == 0:
            return
        for data in choices:
            if data == result:
                executes[result].execute()
        

def run_function(name:str="func1",namespace:str=namespace,execution:str="main()") -> Any:
    "运行当前模块指定的功能。"
    result = None
    exec(f"import {namespace}.{name}")
    exec(f"result = {namespace}.{name}.{execution}")
    return result


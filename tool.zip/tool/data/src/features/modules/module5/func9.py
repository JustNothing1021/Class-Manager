from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    cwd_old = os.getcwd()
    console.print(info_color+"启动cmd...")
    try:
        os.chdir(BIN_PATH)
        os.system("cmd")
        os.chdir(cwd_old)
        console.print(success_color+"执行完成！")
    except:
        os.chdir(cwd_old)
        console.print(err_color+"执行遇到错误...")
    finally:
        pause()
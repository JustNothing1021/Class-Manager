from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了优化系统板块（6）中的管理软件包（3）。")
    while True:
        inputmsg = str(load_functionmenu("管理软件包","这里可以管理几乎所有的软件（但是看着头疼）","想进行什么操作？",
                        {1:"所有软件",
                        2:"所有第三方软件",
                        3:"所有系统软件",
                        4:"按照软件包名搜索"},
                        tiptext="注：软件包列表是可以用方向键往下翻的"))


        if inputmsg == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")
            break

        elif inputmsg == "1":
            write_log(SCRIPT_FILE_NAME,pid,1,"获取所有软件列表...")
            console.print("\n")
            wait_for_device()
            console.print(info_color+"获取设备软件包列表...")
            package_search_range_desc = "任何软件"
            output = run_command("adb shell pm list packages",show_output=False)
            device_package_num = 0
            device_packages = {}
            for package in str(output).splitlines():
                device_package_num += 1
                device_packages[str(device_package_num)] = str(package)[8:]

        elif inputmsg == "2":
            write_log(SCRIPT_FILE_NAME,pid,1,"获取所有第三方软件列表...")
            console.print("\n")
            wait_for_device()
            console.print(info_color+"获取第三方软件包列表...")
            package_search_range_desc = "第三方软件"
            output = run_command("adb shell pm list packages -3",show_output=False)
            device_package_num = 0
            device_packages = {}
            for package in str(output).splitlines():
                device_package_num += 1
                device_packages[str(device_package_num)] = str(package)[8:]

        elif inputmsg == "3":
            write_log(SCRIPT_FILE_NAME,pid,1,"获取所有系统软件列表...")
            console.print("\n")
            wait_for_device()
            console.print(info_color+"获取系统软件包列表...")
            package_search_range_desc = "系统软件"
            output = run_command("adb shell pm list packages -s",show_output=False)
            device_package_num = 0
            device_packages = {}
            for package in str(output).splitlines():
                device_package_num += 1
                device_packages[str(device_package_num)] = str(package)[8:]

        elif inputmsg == "4":
            write_log(SCRIPT_FILE_NAME,pid,1,"请求输入自定义字符串...")
            console.print("\n请输入需要过滤的字符串...")
            inputmsg = input_prompt("你的选项：",
                                   validator=lambda s:s != "",
                                   error_message="请输入信息...")
            console.print("\n")
            wait_for_device()
            console.print(info_color+"获取软件包列表...")
            write_log(SCRIPT_FILE_NAME,pid,1,"获取包含字符串[%s]的软件列表...")
            package_search_range_desc = "包含字符串[%s]的软件"%inputmsg
            output = run_command("adb shell pm list packages",show_output=False)
            device_package_num = 0
            device_packages = {}
            for package in str(output).splitlines():
                device_package_num += 1
                if inputmsg in package:
                    device_packages[str(device_package_num)] = str(package)[8:]
        
        write_log(SCRIPT_FILE_NAME,pid,1,"获取到的列表：%s"%str(device_packages))
        while True:
            if device_packages == {}:
                load_functionmenu("管理所有软件包",
                                  "当前搜索范围：%s"%package_search_range_desc,
                                  "检测到的所有软件包：\n",{},
                                  "没有搜索到%s或它们已经被卸载了..."%package_search_range_desc,
                                  autopropmpt=False)
                write_log(SCRIPT_FILE_NAME,pid,1,"寻找到的软件列表为空...将会返回上级")
                pause()
                break
            write_log(SCRIPT_FILE_NAME,pid,0,"加载菜单...")
            device_packages[0] = "返回上一级（为防止看不见又放了一个）"
            inputmsg = load_functionmenu("管理所有软件包","当前搜索范围：%s"%package_search_range_desc,"检测到的所有软件包：",device_packages,
                "要对哪一个进行操作？\n注：输入0可返回上一级",listmaxheight=25)


            if inputmsg == 0:
                write_log(SCRIPT_FILE_NAME,pid,1,"返回上一级...")
                break
        
            elif inputmsg not in device_packages.keys():
                write_log(SCRIPT_FILE_NAME,pid,1,"未找到代号为[%s]的软件包..."%inputmsg)
                pause("没有找到代号为\[%s]的软件包...（按任意键返回菜单）"%inputmsg)


                
            else:
                selected_package_name = device_packages[inputmsg]
                selected_package_num = inputmsg
                write_log(SCRIPT_FILE_NAME,pid,1,"选中软件包：[%s:%s]"%(selected_package_num,selected_package_name))
                app_labels = {}
                if exist("%s\\app_labels.txt"%DATA_PATH):
                    app_labels = read_variable_file("%s\\app_labels.txt"%DATA_PATH,stagename="读取中",_progress=("none"),encoding="utf-8")
                while True:
                    if app_labels == -1:
                        selected_app_label = "未读取，需解析（使用功能3）"
                        app_labels = {}
                    elif selected_package_name not in app_labels.keys():
                        selected_app_label = "未读取，需解析（使用功能3）"
                    else:
                        selected_app_label = app_labels[selected_package_name]
                    inputmsg = load_functionmenu("管理应用","""当前选中的软件包：\[%s]（代号%s）\n软件名称：%s"""%(selected_package_name,selected_package_num,selected_app_label),
    "要进行什么操作吗？",
                        {1:"获取关于它的信息",
                        2:"将它的安装包提取出来",
                        3:"将安装包提取出来并解析（不会保存安装包）",
                        4:"启用这个应用",
                        5:"禁用这个应用（藏起来但不卸载，但也打不开）",
                        6:"清除这个软件的所有数据",
                        7:"卸载它（不建议卸载系统应用）"})

                    inputmsg = str(inputmsg)
                    if inputmsg == "0":
                        write_log(SCRIPT_FILE_NAME,pid,1,"返回上一级...")
                        break

                    elif inputmsg == "1":
                        write_log(SCRIPT_FILE_NAME,pid,1,"获取软件在dumpsys中的信息...")
                        console.print("\n")
                        wait_for_device()
                        console.print(info_color+"获取软件信息...")
                        split_line()
                        write_log(SCRIPT_FILE_NAME,pid,1,"开始获取...")
                        output = run_command("adb shell dumpsys package %s"%selected_package_name,encoding="utf-8")
                        if not exist(F"{SAVE_PATH}\\package_info\\dumpsys"):
                            os.mkdir(F"{SAVE_PATH}\\package_info\\dumpsys")
                            write_textfile(F"{SAVE_PATH}\\package_info\\dumpsys\\fixed",
                                "由于未知原因修复过一次，时间：%s(%s)"%(get_time(),time.time()))
                        save_file_name = "%s\\package_info\\dumpsys\\package_info_%s_%s.txt"%\
    (SAVE_PATH,selected_package_name,get_saving_name())
                        write_textfile(save_file_name,output)
                        write_log(SCRIPT_FILE_NAME,pid,1,"完成，已经显示在屏幕上并保存在了%s。"%save_file_name)
                        console.print(success_color+"(保存在"+tip_color+save_file_name+close_tag+")")
                        pause("以后会提供翻译的，因为我实在懒得写一大堆权限的中文说明（也是以后了，按任意键返回菜单）")


                    elif inputmsg == "2":
                        write_log(SCRIPT_FILE_NAME,pid,1,"提取软件的安装包...")
                        console.print(warn_color+"\n请确定你已经解开了push锁！")
                        wait_for_device()
                        write_log(SCRIPT_FILE_NAME,pid,1,"获取安装包目录...")
                        console.print(info_color+"获取软件安装包在系统中的目录...")
                        package_path_in_device = run_command("adb shell pm path %s"%selected_package_name,show_output=False)
                        package_path_in_device = package_path_in_device[8:]
                        write_log(SCRIPT_FILE_NAME,pid,1,"安装包目录为[%s]。"%package_path_in_device)
                        console.print(tip_color+"软件包在设备中的路径：%s"%value_color+package_path_in_device)
                        console.print("要把它提取到什么地方？")
                        write_log(SCRIPT_FILE_NAME,pid,1,"请求输入路径...")
                        save_file_path = "%s\\extracted_packages\\%s\\%s"%\
    (SAVE_PATH,selected_package_name,get_saving_name())
                        console.print("（如果留空则提取到默认目录[%s]内）"%save_file_path)
                        inputmsg = input_prompt("你的选项：")
                        if inputmsg == "":
                            console.print("将会把文件保存到\\[%s]..."%save_file_path)
                            if not exist(save_file_path):md(save_file_path)
                        else:
                            save_file_path = inputmsg
                            console.print("将会把文件保存到\\[%s]..."%save_file_path)
                            if not exist(str(save_file_path).capitalize()) and ":\\" in save_file_path: # 是绝对路径，有盘符
                                pass
                            write_log(SCRIPT_FILE_NAME,pid,1,"将会保存在[%s]。"%(save_file_path))
                        output = os.system("adb pull %s %s"%(package_path_in_device,save_file_path))
                        if output:
                            write_log(SCRIPT_FILE_NAME,pid,2,"安装包提取失败...")
                            pause(err_color+"提取失败...可能是因没有解开push锁或者别的问题（按任意键继续）")
                        else:
                            write_log(SCRIPT_FILE_NAME,pid,1,"提取成功！")
                            pause(success_color+"提取成功！（按任意键继续）")


                    elif inputmsg == "3":
                        write_log(SCRIPT_FILE_NAME,pid,1,"临时提取安装包并分析...")
                        console.print(warn_color+"\n请确定你已经解开了push锁！")
                        wait_for_device()
                        write_log(SCRIPT_FILE_NAME,pid,1,"获取安装包目录...")
                        console.print(info_color+"获取软件安装包在系统中的目录...")
                        package_path_in_device = run_command("adb shell pm path %s"%selected_package_name,show_output=False)
                        package_path_in_device = package_path_in_device[8:]
                        write_log(SCRIPT_FILE_NAME,pid,1,"安装包目录为[%s]。"%package_path_in_device)
                        console.print(tip_color+"软件包在设备中的路径：%s"%value_color+package_path_in_device)
                        write_log(SCRIPT_FILE_NAME,pid,1,"将会保存到缓存目录...")
                        console.print(info_color+"把文件保存到缓存目录...")
                        os.system(F"del {CACHE_PATH}\\*.apk >nul 2>&1")
                        output = os.system("adb pull %s %s"%(package_path_in_device,F"{CACHE_PATH}\\"))
                        if output:
                            write_log(SCRIPT_FILE_NAME,pid,2,"在尝试分析安装包时提取文件失败...")
                            pause(err_color+"提取文件出错了...按任意键返回菜单")
                            continue
                        write_log(SCRIPT_FILE_NAME,pid,0,"重命名...")
                        os.system(F"ren {CACHE_PATH}\\*.apk test.apk")
                        console.print(success_color+"完成！")
                        save_file_path = "%s\\package_info\\aapt\\%s\\%s"%(SAVE_PATH,selected_package_name,get_saving_name())
                        write_log(SCRIPT_FILE_NAME,pid,1,"开始分析...")
                        if not exist(f"{SAVE_PATH}\\package_info\\aapt"):
                            md(f"{SAVE_PATH}\\package_info\\aapt")
                            write_textfile(f"{SAVE_PATH}\\package_info\\aapt\\fixed",
                                "由于未知原因修复过一次，时间：%s(%s)"%(get_time(),time.time()))
                        md(save_file_path)
                        console.print(info_color+"\n软件的信息如下：")
                        split_line()
                        console.print(info_color+"\n基本信息：")
                        write_log(SCRIPT_FILE_NAME,pid,1,"分析badging...")
                        output = run_command(f"aapt dump badging {CACHE_PATH}\\test.apk",write_in_log=False)
                        write_textfile("%s\\badging.txt"%save_file_path,output,"UTF-8")
                        if "application-label-zh-CN" in output:
                            selected_app_label = str(output[str(output).find("application-label-zh-CN"):]).splitlines()[0].split(":'")[1][0:-1]
                        elif "application-label" not in output:
                            selected_app_label = "未知"
                        else:
                            selected_app_label = str(output[str(output).find("application-label"):]).splitlines()[0].split(":'")[1][0:-1]
                        pause()
                        split_line()
                        console.print(info_color+"权限：")
                        write_log(SCRIPT_FILE_NAME,pid,1,"分析permissions...")
                        output = run_command(F"aapt dump permissions {CACHE_PATH}\\test.apk",write_in_log=False)
                        write_textfile("%s\\permissions.txt"%save_file_path,output,"UTF-8")
                        pause()
                        split_line()
                        console.print(info_color+"文本配置：")
                        write_log(SCRIPT_FILE_NAME,pid,1,"分析configurations...")
                        output = run_command(F"aapt dump configurations {CACHE_PATH}\\test.apk",write_in_log=False)
                        write_textfile("%s\\configurations.txt"%save_file_path,output,"UTF-8")
                        pause()
                        split_line()
                        console.print(info_color+"资源信息：")
                        write_log(SCRIPT_FILE_NAME,pid,1,"分析resources...")
                        output = run_command(F"aapt dump resources {CACHE_PATH}\\test.apk",write_in_log=False)
                        write_textfile("%s\\resources.txt"%save_file_path,output,"UTF-8")
                        pause()
                        split_line()
                        console.print(info_color+"字符串常量池：")
                        write_log(SCRIPT_FILE_NAME,pid,1,"分析strings...")
                        output = run_command(F"aapt dump strings {CACHE_PATH}\\test.apk",write_in_log=False,encoding="UTF-8")
                        write_textfile("%s\\strings.txt"%save_file_path,output,"UTF-8")
                        write_log(SCRIPT_FILE_NAME,pid,0,"移除临时文件...")
                        os.remove(F"{CACHE_PATH}\\test.apk")
                        update_options(app_labels,"add",selected_package_name,selected_app_label,"%s\\app_labels.txt"%DATA_PATH,
    "//用来记录解析过的软件名的，不要删了",encoding="utf-8")
                        write_log(SCRIPT_FILE_NAME,pid,1,"完成，保存在了[%s]。"%save_file_path)
                        console.print(success_color+"都已经保存在[%s]中了，可以去看看。"%\
    (tip_color+save_file_path+close_tag))
                        pause()


                    elif inputmsg == "4":
                        console.print()
                        wait_for_device()
                        console.print(info_color+"启用中...")
                        write_log(SCRIPT_FILE_NAME,pid,1,"启用应用...")
                        output = run_command("adb shell pm enable %s"%selected_package_name)
                        if "new state: enabled" not in output:
                            write_log(SCRIPT_FILE_NAME,pid,2,"启用应用可能失败了...")
                            console.print(err_color+"可能出错了...")
                        else:
                            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                            console.print(success_color+"完成！")
                        pause()


                    elif inputmsg == "5":
                        console.print("\n")
                        wait_for_device()
                        console.print(info_color+"禁用中...")
                        write_log(SCRIPT_FILE_NAME,pid,1,"禁用应用...")
                        output = run_command("adb shell pm disable-user --user 0 %s"%selected_package_name)
                        if "new state: disabled-user" not in output:
                            write_log(SCRIPT_FILE_NAME,pid,2,"禁用应用可能失败了...")
                            console.print(info_color+"可能出错了...")
                        else:
                            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                            console.print(success_color+"完成！")
                        pause()


                    elif inputmsg == "6":
                        write_log(SCRIPT_FILE_NAME,pid,1,"询问是否继续清理应用数据...")
                        split_line(warn_color+"警告",warn_color)
                        console.print(warn_color+f"""接下来的操作将会{err_color}清除该应用的所有数据{close_tag}。""")
                        if confirm_prompt("是否继续？"):
                            console.print("\n")
                            wait_for_device()
                            write_log(SCRIPT_FILE_NAME,pid,1,"清理应用数据...")
                            console.print(info_color+"清除数据中...")
                            output = run_command("adb shell pm clear %s"%selected_package_name)
                            if "Success" not in output:
                                write_log(SCRIPT_FILE_NAME,pid,2,"清理应用数据可能失败了...")
                                console.print(f"{err_color}可能出错了...")
                            else:
                                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                                console.print(f"{success_color}完成！")
                            pause()
                        else:
                            write_log(SCRIPT_FILE_NAME,pid,1,"取消...")
                            pause("已取消...（按任意键继续）")


                    elif inputmsg == "7":
                        write_log(SCRIPT_FILE_NAME,pid,1,"询问是否继续卸载应用...")
                        split_line(warn_color+"警告",warn_color)
                        console.print(warn_color+f"接下来的操作将会{warn_color}卸载该应用{close_tag}。\n要继续或者备份一下安装包吗？")
    
    
                        choosenum = ListPrompt("请选择...",
                                               [Choice("1.不做任何操作，继续卸载",1),
                                                Choice("2.备份安装包后继续卸载",2),
                                                Choice("0.取消",114514)]).prompt().data

                        if choosenum == 1:
                            write_log(SCRIPT_FILE_NAME,pid,1,"将不做其他操作，按任意键后卸载...")
                            pause("按任意键继续卸载...")
                            wait_for_device()
                            console.print(info_color+"卸载中...")
                            output = run_command("adb shell pm uninstall --user 0 %s"%selected_package_name)
                            if "Success" not in output:
                                write_log(SCRIPT_FILE_NAME,pid,2,"卸载应用失败...")
                                console.print(err_color+"可能出错了...")
                            else:
                                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                                console.print(success_color+"完成！")
                            pause()
                            write_log(SCRIPT_FILE_NAME,pid,1,"在列表中移除代号为%s的软件..."%selected_package_num)
                            device_packages.pop(selected_package_num)
                            break

                        elif choosenum == 2:
                            write_log(SCRIPT_FILE_NAME,pid,1,"将在备份后卸载...")
                            console.print(warn_color+"\n请确定你已经解开了push锁！")
                            wait_for_device()
                            write_log(SCRIPT_FILE_NAME,pid,1,"获取安装包目录...")
                            console.print(info_color+"获取软件安装包在系统中的目录...")
                            package_path_in_device = run_command("adb shell pm path %s"%selected_package_name,show_output=False)
                            package_path_in_device = package_path_in_device[8:]
                            write_log(SCRIPT_FILE_NAME,pid,1,"安装包目录为[%s]。"%package_path_in_device)
                            console.print(tip_color+"软件包在设备中的路径：%s"%value_color+package_path_in_device)
                            console.print(info_color+"把文件保存到备份目录...")
                            save_file_path = "backups\\packages\\%s-%s"%(selected_package_name,get_saving_name())
                            write_log(SCRIPT_FILE_NAME,pid,1,"把文件保存到备份目录：%s..."%save_file_path)
                            if not exist(save_file_path):os.mkdir(save_file_path)
                            output = os.system("adb pull %s %s"%(package_path_in_device,save_file_path))
                            if output:
                                write_log(SCRIPT_FILE_NAME,pid,2,"在卸载应用前备份时出错...")
                                console.print("出错了...按任意键返回菜单")
                                continue
                            write_log(SCRIPT_FILE_NAME,pid,1,"完成，按任意键后将会卸载...")
                            console.print(success_color+"完成！")
                            console.print(info_color+f"把备份文件保存到了[{value_color+save_file_path+close_tag}]。")
                            write_log(SCRIPT_FILE_NAME,pid,2,"把备份文件保存到了[%s]，请检查备份是否成功！"%save_file_path)
                            pause(warn_color+f"备份命令执行完成，{err_color}请检查备份是否成功后再继续执行！！{close_tag}（按任意键继续卸载）")
                            console.print(info_color+"\n卸载中...")
                            output = run_command("adb shell pm uninstall --user 0 %s"%selected_package_name)
                            if "Success" not in output:
                                write_log(SCRIPT_FILE_NAME,pid,2,"卸载应用失败...")
                                console.print(err_color+"可能出错了...")
                            else:
                                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                                console.print(success_color+"完成！")
                            pause()
                            write_log(SCRIPT_FILE_NAME,pid,1,"在列表中移除代号为%s的软件..."%selected_package_num)
                            device_packages.pop(selected_package_num)
                            break

                        else:
                            pause("已取消...（按任意键继续）")



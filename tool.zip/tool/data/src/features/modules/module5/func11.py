from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    while True:
        inputmsg = load_functionmenu("其他拓展功能","给进阶的玩家们用的，萌新不建议使用","需要干些啥？",
            {1:"安装Magisk模块",
            2:"安装Edxposed系统框架",
            3:"查看和记录安卓日志",
            4:"从某网站\"轰炸\"出ota升级包（没什么事别用，费电脑）"})


        if inputmsg == 0:
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")
            break

        if inputmsg == 1:
            while True:
                show_msgbox("安装Magisk模块","请确定你已经解开了push锁（详情见功能6-4）！\n接下来这个脚本会循环执行，除非输入数字0\n提示：没有用magisk管理root是不能装模块的\n请输入模块所在的路径或者把它拖进这个窗口")
                write_log(SCRIPT_FILE_NAME,pid,0,"请求用户输入路径...")
                inputmsg = input_prompt("模块路径：",validator=lambda s:s != "",error_message="请输入路径！")
                write_log(SCRIPT_FILE_NAME,pid,0,"获得的路径：%s"%inputmsg)
                if inputmsg == "0":
                    break
                install_module(inputmsg)
                console.print(info_color+"\n安装执行完毕了，要重启吗？")
                if confirm_prompt():
                    console.print(info_color+"重启中...")
                    run_command("adb reboot")
                else:
                    console.print(tip_color+"那么设备将不会重启")
                pause("全部执行完成！（按任意键返回）")

                
        elif inputmsg == 2:
            split_line("安装Edxposed（转载自热铁）")
            console.print(warn_color+f"请确认你{tip_color}安装了Magisk{close_tag}，{tip_color}没有安装别的Edxposed{close_tag}，{tip_color}安卓版本>=8.1{close_tag}并且{tip_color}解开了push锁{close_tag}！\n要继续吗？")

            if confirm_prompt():
                console.print(info_color+"\n安装Edxposed Manager...")
                output, status = install_apk(FILE_PATH+"\\Edxposed_manager.apk")
                if not status and "without first uninstalling" not in output:
                    console.print(err_color+"管理器安装失败...")
                    pause()
                    continue
            
                console.print(info_color+"\n安装riru-core...")
                install_module(FILE_PATH+"\\edxposed\\riru-core.zip")
                console.print(info_color+"\n安装Edxposed...")
                install_module(FILE_PATH+"\\edxposed\\Edxposed.zip")
                console.print(info_color+"\n安装执行完毕了，要重启吗？")
                if confirm_prompt():
                    console.print(info_color+"重启中...")
                    run_command("adb reboot")
                else:
                    console.print(tip_color+"那么设备将不会重启")
                pause("全部执行完成！（按任意键返回）")


        elif inputmsg == 3:
            console.print(info_color+f"本功能将会把安卓日志显示到屏幕上并保存\n{tip_color}请输入要记录的行数，若无限制则留空")
            write_log(SCRIPT_FILE_NAME,pid,0,"请求用户输入...")

            inputmsg = input_prompt("你的选项：",
                                   validator=lambda s:s.isdigit() or s == "")
            write_log(SCRIPT_FILE_NAME,pid,0,"用户输入了[%s]。"%inputmsg)
            if inputmsg == "":
                log_line_count = "no_limit"
            else:
                log_line_count = int(inputmsg)
            if log_line_count == 0:
                break
            elif log_line_count == "no_limit":
                console.print(tip_color+"将会输出所有记录的日志，直到数据线拔出...")

                save_path = f"{SAVE_PATH}\\android_logs\\log_{get_saving_name()}"
                md(save_path,777)
                write_log(SCRIPT_FILE_NAME,pid,1,"将会记录所有日志，保存到%s"%save_path)
                console.print(info_color+f"将会把日志同步保存到\[{save_path}]中。")
                wait_for_device()
                time.sleep(1.5)
                write_log(SCRIPT_FILE_NAME,pid,1,"开始记录...")
                print()
                run_sync_command(f"adb {device_sn_args} shell logcat",return_output=False,redirect_path=save_path)
                split_line()
                rename(f"{save_path}\\command_output.txt",f"{save_path}\\log.txt")
                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                pause("完成！（按任意键返回上级）")
            else:
                print("将会输出所有记录的日志，总共输出%d行..."%log_line_count)
                save_path = f"{SAVE_PATH}\\android_logs\\log_{get_saving_name()}"
                md(save_path,777)
                write_log(SCRIPT_FILE_NAME,pid,1,"将会记录%d行日志，保存到%s"%(log_line_count,save_path))
                console.print(info_color+f"将会把日志同步保存到\[{save_path}]中。")
                wait_for_device()
                time.sleep(1.5)
                write_log(SCRIPT_FILE_NAME,pid,1,"开始记录...")
                print()
                run_sync_command(f"adb {device_sn_args} logcat -t {log_line_count}",return_output=False,redirect_path=save_path)
                split_line()
                rename(f"{save_path}\\command_output.txt",f"{save_path}\\log.txt")
                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                pause("完成！（按任意键返回上级）")

        elif inputmsg == 4:
            if input_prompt("输入yes以继续：",is_password=True) == "yes":
                try:
                    import src.features.modules.module5.func11_extd.boom_ota
                    src.features.modules.module5.func11_extd.boom_ota.main()
                except:
                    pass
                try:
                    
                    progress.stop()
                except:
                    pass

from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    inputmsg = list_prompt("需打开什么页面？",
        [Choice("1.打开自检主程序","1"),
        Choice("2.打开adb界面（但是没打开adb就不能用这个，有啥用啊）","2"),
        Choice("3.打开调试设置界面","3"),
        Choice("4.打开网络设置界面","4"),
        Choice("0.取消","0")]).data

    if inputmsg == "0":
        write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")


    elif inputmsg == "1":
        wait_for_device()
        write_log(SCRIPT_FILE_NAME,pid,1,"打开指定的activity...")
        console.print(info_color+"打开指定的activity...")
        output = run_command(return_type="status",args="adb wait-for-device shell am start com.xtc.selftest/.MainActivity")
        if not output:
            console.print(success_color+"完成！")
            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
        else:
            console.print(warn_color+"好像出错了...")
            write_log(SCRIPT_FILE_NAME,pid,2,"执行貌似出错了...")
        pause()


    elif inputmsg == "2":
        write_log(SCRIPT_FILE_NAME,pid,1,"等待设备连接...")
        wait_for_device()
        write_log(SCRIPT_FILE_NAME,pid,1,"打开指定的activity...")
        console.print(info_color+"打开指定的activity...")
        output = run_command(return_type="status",args="adb wait-for-device shell am start com.xtc.selftest/.ui.DebugActivity")
        if not output:
            console.print(success_color+"完成！")
            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
        else:
            console.print(warn_color+"好像出错了...")
            write_log(SCRIPT_FILE_NAME,pid,2,"执行貌似出错了...")
        pause()


    elif inputmsg == "3":
        write_log(SCRIPT_FILE_NAME,pid,1,"等待设备连接...")
        wait_for_device()
        write_log(SCRIPT_FILE_NAME,pid,1,"打开指定的activity...")
        console.print(info_color+"打开指定的activity...")
        output = run_command(return_type="status",args="adb wait-for-device shell am start com.xtc.selftest/.ui.ControllerActivity")
        if not output:
            console.print(success_color+"完成！")
            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
        else:
            console.print(warn_color+"好像出错了...")
            write_log(SCRIPT_FILE_NAME,pid,2,"执行貌似出错了...")
        pause()


    elif inputmsg == "4":
        write_log(SCRIPT_FILE_NAME,pid,1,"等待设备连接...")
        wait_for_device()
        write_log(SCRIPT_FILE_NAME,pid,1,"打开指定的activity...")
        console.print(info_color+"打开指定的activity...")
        output = run_command(return_type="status",args="adb wait-for-device shell am start com.xtc.selftest/.ui.NetworkSettingsActivity")
        if not output:
            console.print(success_color+"完成！")
            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
        else:
            console.print(warn_color+"好像出错了...")
            write_log(SCRIPT_FILE_NAME,pid,2,"执行貌似出错了...")
        pause()

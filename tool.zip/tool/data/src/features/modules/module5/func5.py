from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    console.print(warn_color+"请确定你已经解开了push锁！")
    wait_for_device()
    write_log(SCRIPT_FILE_NAME,pid,1,"开始投屏...")
    split_line("投屏输出")
    output = run_sync_command("scrcpy")
    split_line()
    status = subprocess.getoutput(r"echo %errorlevel%").splitlines()[0]
    write_log(SCRIPT_FILE_NAME,pid,1,f"已退出，返回值为{status}")
    write_log(SCRIPT_FILE_NAME,pid,"输出","输出：")
    for line in output.splitlines():
        write_log(SCRIPT_FILE_NAME,pid,"输出",f"\t{line}")
    console.print(info_color+f"(返回值：{status}）")
    if status == "0":
        console.print(success_color+"完成！")
        write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
    else:
        write_log(SCRIPT_FILE_NAME,pid,2,"scrcpy投屏退出返回值异常：%s"%status)
        console.print(warn_color+"返回值不为0，可能出现了一些小问题（比如手表没连上或者断连了）")
    pause()

from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def run(cmd,root=False):
    if root:
        return os.system(f"adb {device_sn_args} shell su -c "+cmd)
    else:
        return os.system(f"adb {device_sn_args} shell "+cmd)
    
def test(timeout=5):
    os.system("adb wait-for-device devices >nul 2>&1")
    try:
        subprocess.run("adb shell echo",capture_output=True,shell=True,timeout=timeout)
        subprocess.run("adb shell su -c echo",capture_output=True,shell=True,timeout=timeout)
    except:
        return False
    return True



def shell():

    _keep_thread = threading.Thread(target=_detect_device)
    _keep_thread.start()
    split_line("优化终端")
    console.print(info_color+"这里如果设备断开连接了可能不会退出")
    if device_sn_args != "":
        console.print(desc_color+"* 当前操作设备："+success_color+device_sn_args.split(" ")[-1])
    wait_for_device()
    device = getprop("ro.product.name")

    is_root = False
    failure = False
    dev_color = tip_color
    stat = 0

    while True:

        if failure:
            pointer_color = err_color
        else:
            pointer_color = success_color

        if is_root:
            pointer = ":/ # "
        else:
            pointer = ":/ $ "
        console.print(dev_color+device+pointer_color+pointer+close_tag+close_tag,end="")
        try:
            cmd = input()
        except KeyboardInterrupt:
            return
        
        start = time.time()

        try:
            if all([c == " " for c in cmd]):
                stat = 0
                failure = True
                console.print()

            elif cmd[0:2] == "su" and all([c == " " for c in cmd[2:]]):
                console.print()
                if has_root():
                    is_root = True
                    stat = 0
                    failure = False
                else:
                    console.print(err_color+"当前设备没有root权限...")
                    stat = 127


            elif cmd[0:4] == "exit" and all([c == " " for c in cmd[4:]]):
                if is_root:
                    console.print()
                    is_root = False
                    stat = 0
                else:
                    return
            
            else:
                
                stat = run(cmd, is_root)

        except:
            pass

        


        total_time = time.time() - start

        if stat:
            failure = True
            stat_color = err_color
        else:
            failure = False
            stat_color = success_color

        console.print(tip_color+f"执行时间:{value_color}{round(total_time,4)}{close_tag}s, 返回值{stat_color}{stat}",justify="right")

class DeviceDisconnected(LookupError):"设备断开连接"

def _detect_device():
    while True:
        time.sleep(1)
        return_status, _ = subprocess.getstatusoutput("adb shell echo")
        if return_status != 0:
            raise DeviceDisconnected
        






def main():
    console.print(info_color+"目前我做了一个优化终端，但是bug很多")
    console.print(info_color+"打算试一下吗？（虽然估计会很逆天）")
    if confirm_prompt():
        console.print(tip_color+"那就试试吧，接下来会启动\"优化\"终端")
        try:
            shell()
        except DeviceDisconnected:
            console.print(warn_color+"\n设备已断开连接...")
    else:
        console.print(tip_color+"明智的选择")
        console.print(info_color+"将会启动终端...")
        try:
            output = run_sync_command("adb shell")
        except UnicodeError:
            console.print(warn_color+"由于解码错误，使用过的命令将不会写入日志")
            write_log(SCRIPT_FILE_NAME,text="由于解码错误，使用过的命令将不会写入日志")
        else:
            write_log(SCRIPT_FILE_NAME,text="退出了shell，使用过的命令:"+output)
    pause()
    
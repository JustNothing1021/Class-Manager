from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了优化系统板块（5）中的卸载系统更新（2）。")
    console.print(warn_color+f"这个功能将会{err_color}卸载负责系统更新的应用{close_tag}。")
    write_log(SCRIPT_FILE_NAME,pid,1,"询问用户是否继续...")
    if confirm_prompt("是否继续？"):
        write_log(SCRIPT_FILE_NAME,pid,1,"将会在按任意键后继续...")
        pause("按任意键继续卸载...")
        write_log(SCRIPT_FILE_NAME,pid,1,"开始卸载...")
        wait_for_device()
        output = run_command("adb shell pm uninstall --user 0 com.xtc.systemupdate_i11")
        if "Success" not in output:
            console.print(err_color+"卸载失败了...")
            write_log(SCRIPT_FILE_NAME,pid,1,"卸载失败了...")
            if "installed for" in output:
                write_log(SCRIPT_FILE_NAME,pid,1,"应该是已经卸载过了")
                console.print(tip_color+"已经卸载过了，不用再卸载了")
        else:
            write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
            console.print(success_color+"完成！")
        pause()

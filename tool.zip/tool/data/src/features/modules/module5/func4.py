from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    wait_for_device()
    write_log(SCRIPT_FILE_NAME,pid,1,"启动Activity...")
    if run_command("adb shell am start com.qualcomm.qti.qmmi/.framework.MainActivity",return_type="status"):
        console.print(warn_color+"可能出错了...")
    else:
        console.print(success_color+"启动完成！\n")
    pause("""接下来将会有用手操作手表的要求
刚刚已经打开了一个界面（如果成功了的话），请检查手表上有没有出现一个灰色的界面
如果有，按任意键继续，并按接下来的步骤操作""")
    pause("""按下右下角的重启按钮，往下划屏幕找到重启到QMMI （不要点别的，别问我怎么知道的）
勾选后再往下翻，按确定；手表会重启一次回到这个页面；
同样按右下角的重启按钮，往下划屏幕找到重启至正常模式，勾选后再往下翻，按确定；
(按任意键继续)
""")        
    pause("完成！（按任意键返回菜单）")


from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    wait_for_device()
    write_log(SCRIPT_FILE_NAME,pid,1,"获取设备基本信息...")
    device_model = getprop("ro.product.model")
    device_system_version = getprop("ro.product.current.softversion")
    console.print(info_color+f"当前连接的设备：{device_model}-{device_system_version}")
    console.print(tip_color+"这个输出会有点长，建议慢慢看")
    pause()
    split_line()
    write_log(SCRIPT_FILE_NAME,pid,1,"获取设备的build.prop...")
    console.print(info_color+"build.prop:")
    output = run_command("adb shell getprop",write_in_log=False)
    if not exist("saves\\props"):
        os.mkdir("saves\\props")
        write_textfile("saves\\props\\fixed",
            "由于未知原因修复过一次，时间：%s(%s)"%(get_time(),time.time()))
    save_file_name = "saves\\props\\config_%s-%s_%s.txt"%\
        (device_model,device_system_version,get_saving_name())
    write_textfile(save_file_name,output,"UTF-8")
    write_log(SCRIPT_FILE_NAME,pid,1,"已经保存到了[%s]..."%save_file_name)
    console.print(success_color+f"已经把输出保存到了\[{save_file_name}].")
    split_line()
    write_log(SCRIPT_FILE_NAME,pid,1,"获取设备网络信息...")
    console.print(info_color+"网络信息：")
    run_command("adb shell ifconfig")
    split_line()
    write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
    split_line()
    pause("完成！（按任意键返回菜单）")
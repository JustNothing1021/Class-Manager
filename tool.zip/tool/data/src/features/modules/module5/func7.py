from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    inputmsg = list_prompt("请选择需要进行的操作",[Choice("1.重启设备","1"),
                                                 Choice("2.操控设备","2"),
                                                 Choice("0.取消","0")]).data
    write_log(SCRIPT_FILE_NAME,pid,0,"用户输入了[%s]。"%inputmsg)
    if inputmsg == "0":
        write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")


    elif inputmsg == "1":
        inputmsg = list_prompt("请选择重启到的模式",[Choice("1.正常模式","1"),
                                                 Choice("2.fastboot模式","2"),
                                                 Choice("3.recovery模式","3"),
                                                 Choice("4.edl模式","4"),
                                                 Choice("0.取消","0")])
        mode = inputmsg.name
        inputmsg = inputmsg.data

        if inputmsg == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")

        
        else:
            write_log(SCRIPT_FILE_NAME,pid,1,"等待设备连接...")
            wait_for_device()
            console.print(info_color+f"下达重启到{mode.split('.')[1]}的命令中...")

            if inputmsg == "1":
                write_log(SCRIPT_FILE_NAME,pid,1,"下达重启到正常模式的命令...")
                run_command("adb reboot")

            elif inputmsg == "2":
                write_log(SCRIPT_FILE_NAME,pid,1,"下达重启到fastboot模式的命令...")
                run_command("adb reboot bootloader")

            elif inputmsg == "3":
                write_log(SCRIPT_FILE_NAME,pid,1,"下达重启到recovery模式的命令...")
                run_command("adb reboot recovery")

            elif inputmsg == "4":
                write_log(SCRIPT_FILE_NAME,pid,1,"下达重启到edl模式的命令...")
                run_command("adb reboot edl")
            write_log(SCRIPT_FILE_NAME,pid,1,"执行完成！")
            console.print(success_color+"完成！")
            pause()



    elif inputmsg == "2":
        write_log(SCRIPT_FILE_NAME,pid,1,"用户选择了进行操作（2）。")
        inputmsg = list_prompt("请选择需要进行的操作",[Choice("1.发送按键信息","1"),
                                                 Choice("2.代替输入自定义文本","2"),
                                                 Choice("3.点击屏幕指定位置","3"),
                                                 Choice("4.划动屏幕指定位置","4"),
                                                 Choice("0.取消","0")]).data

        if inputmsg == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")

        
        elif inputmsg == "1":
            inputmsg = list_prompt("请选择需要发送的事件",[Choice("1.按下电源键","26"),
                                                 Choice("2.按下返回键","4"),
                                                 Choice("3.按下回车键","66"),
                                                 Choice("4.按下删除键","67"),
                                                 Choice("5.按下音量加键","24"),
                                                 Choice("6.按下音量减键","25"),
                                                 Choice("7.自定义按键编号","EDIT"),
                                                 Choice("0.取消","0")]).data




            if inputmsg == "EDIT":
                inputmsg = input_prompt("请输入按键代号：",validator=lambda s:s.isdigit(),error_message="请输入一个数字！")
            elif inputmsg == "0":
                return

            wait_for_device()
            console.print(info_color+f"向设备发送按键信息，按键代号为{inputmsg}...")
            write_log(SCRIPT_FILE_NAME,pid,1,f"向设备发送按键信息{inputmsg}.....")
            run_command(f"adb shell input keyevent {inputmsg}")
            pause(success_color+"完成！（按任意键继续）")

        elif inputmsg == "2":
            write_log(SCRIPT_FILE_NAME,pid,1,"进入了输入自定义文本（2）。")
            try:
                while True:
                    exit_code = random_string_generator(strlen=16)
                    load_functionmenu("自定义输入",
                                      f"这个脚本将会循环执行，输入以下文本或按ctrl+c即可退出（方括号不要输进去）\n\[{exit_code}]",
                                      tip_color+"应该不会有人输入这么奇怪的东西的，所以就定为退出的文本了",
                                      {},
                                      info_color+"请在底下的对话框输入需要代替输入的内容",
                                      autopropmpt=False)
                    inputmsg = input_prompt("文本：",validator=lambda s:s != "",error_message="请输入文本")
                    if inputmsg == exit_code:
                        return
                    write_log(SCRIPT_FILE_NAME,pid,1,"代替输入文本：[%s]"%inputmsg)
                    wait_for_device()
                    console.print("代替输入中...")
                    output = run_command("adb shell input text %s"%inputmsg)
                    if output != "":
                        console.print("好像出错了...")
                    else:
                        console.print("完成！")
                    pause()
                    continue
            except:
                console.print(info_color+"退出...")

        elif inputmsg == "3":
            write_log(SCRIPT_FILE_NAME,pid,1,"用户选择了点击屏幕（3）。")
            console.print("\n请输入点击点在屏幕上的坐标（左上角为原点）")
            input_tap_posx = input_prompt("X坐标：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            input_tap_posy = input_prompt("Y坐标：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            write_log(SCRIPT_FILE_NAME,pid,1,"发送点击屏幕上(%s, %s)的请求..."%(input_tap_posx,input_tap_posy))
            wait_for_device()
            console.print(info_color+f"发送点击屏幕上{value_color}({input_tap_posx}, {input_tap_posy}){close_tag}的请求...")
            output = run_command("adb shell input tap %s %s"%(input_tap_posx,input_tap_posy))
            if output != "":
                console.print(warn_color+"好像出错了...")
            else:
                console.print(success_color+"完成！")
            pause()


        elif inputmsg == "4":
            write_log(SCRIPT_FILE_NAME,pid,1,"用户选择了划动屏幕（4）。")
            write_log(SCRIPT_FILE_NAME,pid,1,"请求用户输入信息...")
            console.print(info_color+f"\n请输入划动的{tip_color}起始点{close_tag}在屏幕上的坐标（左上角为原点）")
            input_swipe_start_posx = input_prompt("X坐标：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            input_swipe_start_posy = input_prompt("Y坐标：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            console.print(info_color+f"\n请输入划动的{tip_color}结束点{close_tag}在屏幕上的坐标（同样是左上角为原点）")
            input_swipe_end_posx = input_prompt("X坐标：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            input_swipe_end_posy = input_prompt("Y坐标：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            console.print(info_color+f"\n请输入{tip_color}整个划动动作的持续时间{close_tag}（单位为毫秒，可以留空视为瞬间完成）")
            input_swipe_duration = input_prompt("持续时间：",validator=lambda s:s.isdigit(),error_message="请输入一个数字")
            write_log(SCRIPT_FILE_NAME,pid,1,"发送在屏幕上于%s毫秒由(%s, %s)划动到(%s, %s)的请求..."%
                (input_swipe_duration,input_swipe_start_posx,input_swipe_start_posy,input_swipe_end_posx,input_swipe_end_posy))
            wait_for_device()
            console.print(info_color+f"发送在屏幕上于{value_color}{input_swipe_duration}{close_tag}毫秒由{value_color}({input_swipe_start_posx}, {input_swipe_start_posy}){close_tag}划动到{value_color}({input_swipe_end_posx}, {input_swipe_end_posy}){close_tag}的请求...")
            output = run_command(f"adb shell input swipe {input_swipe_start_posx} {input_swipe_start_posy} {input_swipe_end_posx} {input_swipe_end_posy} {input_swipe_duration}")
            if output != "":
                console.print("好像出错了...")
                write_log(SCRIPT_FILE_NAME,pid,2,"执行貌似出错了...")
            else:
                console.print("完成！")
                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
            pause()

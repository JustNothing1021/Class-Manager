from src.init_utils import *

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了优化系统板块（5）中的修改屏幕参数（1）。")
    inputmsg = ListPrompt("请选择需要修改的项目...",
                          [Choice("1.分辨率","1"),
                           Choice("2.DPI（屏幕密度）","2"),
                           Choice("0.取消","0")],
                          pointer=ListPrompt_pointer,
                          annotation=ListPrompt_annotation).prompt(style=ListPrompt_style).data
    write_log(SCRIPT_FILE_NAME,pid,1,"请求用户输入...")
    write_log(SCRIPT_FILE_NAME,pid,1,"用户输入了[%s]。"%(inputmsg))

    if inputmsg == "0":
        return
    

    elif inputmsg == "1":
        console.print(info_color+"当前连接的设备的分辨率：")
        write_log(SCRIPT_FILE_NAME,pid,1,"检测当前的分辨率...")
        output = run_command("adb shell wm size",show_output=False)
        if "Physical size: " in output:
            write_log(SCRIPT_FILE_NAME,pid,1,"分析中...")
            device_physical_size = str(output.split("Physical size: ")[1]).split("\n")[0]
            if len(device_physical_size.split("x")) != 2:
                console.print(tip_color+f"\n原生分辨率： \t{value_color}{device_physical_size}")
                write_log(SCRIPT_FILE_NAME,pid,1,f"原生分辨率： \t{device_physical_size}")
            else:
                console.print(tip_color+f'\n原分辨率： \t宽{value_color}{device_physical_size.split("x")[0]}{close_tag}像素，高{value_color}{device_physical_size.split("x")[1]}{close_tag}像素')
                write_log(SCRIPT_FILE_NAME,pid,1,"原生分辨率： \t宽%s像素，高%s像素"%(device_physical_size.split("x")[0],
                    device_physical_size.split("x")[1]))
            if "Override size: " in output:
                write_log(SCRIPT_FILE_NAME,pid,0,"分辨率被修改过，将会尝试分析修改后的分辨率...")
                device_override_size = str(output.split("Override size: ")[1]).split("\n")[0]
                if len(device_override_size.split("x")) != 2:
                    console.print(info_color+f"当前分辨率： \t{value_color}{device_physical_size}")
                    write_log(SCRIPT_FILE_NAME,pid,1,"当前分辨率： \t%s"%device_physical_size)
                else:
                    console.print(info_color+f'当前分辨率： \t宽{value_color}{device_override_size.split("x")[0]}{close_tag}像素，高{value_color}{device_override_size.split("x")[1]}{close_tag}像素')
                    write_log(SCRIPT_FILE_NAME,pid,1,"当前分辨率： \t宽%s像素，高%s像素"%(device_override_size.split("x")[0],
                        device_override_size.split("x")[1]))
        else:
            console.print(warn_color+"（获取失败）")
            write_log(SCRIPT_FILE_NAME,pid,2,"分辨率获取失败...")
        console.print(info_color+"\n那么，现在你想要将它修改为什么呢？")
        console.print(tip_color+"注:小天才高版本屏幕的宽比高=8:9")
        console.print(tip_color+"（输入0返回上级，两项都留空恢复默认）")
        write_log(SCRIPT_FILE_NAME,pid,1,"请求用户输入宽度...")
        device_adjusting_width = input_prompt("\n宽度：",
                                                 validator=lambda s:s.isdigit() or s == "",
                                                 error_message="请输入一个数字")
        write_log(SCRIPT_FILE_NAME,pid,1,"用户输入了[%s]。"%(device_adjusting_width))


        if device_adjusting_width == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")
            return

        write_log(SCRIPT_FILE_NAME,pid,1,"请求用户输入高度...")

        device_adjusting_height = input_prompt("\n高度：",
                                                 validator=lambda s:s.isdigit() or s == "",
                                                 error_message="请输入一个数字")
        write_log(SCRIPT_FILE_NAME,pid,1,"用户输入了[%s]。"%(device_adjusting_height))

            
        if device_adjusting_height == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")
            return
        
        if device_adjusting_height == device_adjusting_width == "":
            write_log(SCRIPT_FILE_NAME,pid,1,"将分辨率恢复为默认...")
            console.print(info_color+"\n将会把分辨率恢复为默认。")
            wait_for_device()
            output = run_command("adb shell wm size reset")
            if output != "":
                write_log(SCRIPT_FILE_NAME,pid,1,"疑似出错了...?")
                console.print(warn_color+"貌似出错了...")
            else:
                console.print(success_color+"完成！")

        else:
            console.print(info_color+"\n将会把分辨率修改为%s%sx%s%s。"%(value_color,device_adjusting_width,device_adjusting_height,close_tag))
            write_log(SCRIPT_FILE_NAME,pid,1,"将分辨率更改为%sx%s..."%(device_adjusting_width,device_adjusting_height))
            wait_for_device()
            output = run_command("adb shell wm size %sx%s"%(device_adjusting_width,device_adjusting_height))
            if output != "":
                write_log(SCRIPT_FILE_NAME,pid,1,"疑似出错了...?")
                console.print(warn_color+"貌似出错了...")
            else:
                console.print(success_color+"完成！")

        pause()


    elif inputmsg == "2":
        console.print(info_color+"\n当前连接的设备的DPI：")
        write_log(SCRIPT_FILE_NAME,pid,1,"获取设备DPI...")
        output = run_command("adb shell wm density",show_output=False)
        if "Physical density: " in output:
            write_log(SCRIPT_FILE_NAME,pid,1,"分析中...")
            device_physical_density = str(output.split("Physical density: ")[1]).split("\n")[0]
            console.print(tip_color+"原生DPI： \t%s"%value_color+device_physical_density)
            write_log(SCRIPT_FILE_NAME,pid,1,"原生DPI： \t%s"%device_physical_density)
            if "Override density: " in output:
                write_log(SCRIPT_FILE_NAME,pid,1,"DPI被修改过，尝试分析当前DPI...")
                device_override_density = str(output.split("Override density: ")[1]).split("\n")[0]
                console.print(info_color+"当前DPI： \t%s"%value_color+device_override_density)
                write_log(SCRIPT_FILE_NAME,pid,1,"当前DPI： \t%s"%device_override_density)
        else:
            write_log(SCRIPT_FILE_NAME,pid,2,"获取失败...")
            console.print(warn_color+"（获取失败）")
        console.print(info_color+"\n那么，现在你想要将它修改为什么呢？")
        console.print(tip_color+"注:数字越小手表上的界面越小，而且数字必须大于等于72")
        console.print(tip_color+"如默认为320，设置为160会使界面缩小为原来的160/320=0.5倍")
        console.print(tip_color+"这个和把分辨率修改为原来的2倍从大体上来说是一样的")
        console.print(tip_color+"高版本桌面修改DPI会反复重启，建议修改分辨率")
        console.print(tip_color+"输入0返回上级，留空将恢复默认")
        write_log(SCRIPT_FILE_NAME,pid,1,"请求用户输入...")
        device_adjusting_density = input_prompt("\nDPI：",
                                                 validator=lambda s:s.isdigit() or s == "",
                                                 error_message="请输入一个数字"
                                                   )
        write_log(SCRIPT_FILE_NAME,pid,1,"用户输入了[%s]。"%(device_adjusting_density))


        if device_adjusting_density == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"返回上级...")
            return

        if device_adjusting_density == "":
            console.print(info_color+"\n将会把DPI恢复为默认。")
            wait_for_device()
            output = run_command("adb shell wm density reset")
            if output != "":
                write_log(SCRIPT_FILE_NAME,pid,1,"疑似出错了...?")
                console.print(warn_color+"貌似出错了...")
            else:
                write_log(SCRIPT_FILE_NAME,pid,1,"修改成功！")
                console.print(success_color+"完成！")
        else:
            console.print(info_color+"\n将会把DPI更改为%s。"%(device_adjusting_density))
            wait_for_device()
            output = run_command("adb shell wm density %s"%device_adjusting_density)
            if output != "":
                write_log(SCRIPT_FILE_NAME,pid,1,"疑似出错了...?")
                console.print(warn_color+"貌似出错了...")
            else:
                console.print(success_color+"完成！")
        pause()


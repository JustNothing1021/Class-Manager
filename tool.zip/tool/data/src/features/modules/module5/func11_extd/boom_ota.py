from src.init_utils import *



def boom(base_url:str = "https://smartwatch.qiniucdn.com/ota_f_v2.0.5_t{}.zip",
         utc_range:Tuple[int, int] = (1722182400, 1722268800),
         max_thread_count:int = 8192,
         show_failed_output:bool = False):
    
    global thread_count, threads, succeed_threads
    tmp_console = Console()

    progress = Progress(
                *Progress.get_default_columns(),
                console=tmp_console,
                transient=False)


    thread_count = 0






    succeed_threads = []
    threads = []

    def get_response(url:str):
        global thread_count
        thread_count += 1
        threads.append(url)
        while True:
            try:
                response = requests.get(url)
                if response.status_code != 404:
                    tmp_console.print(f"[#00f0f0]线程{url}返回[#0070F0]{response.status_code}[/]，成功")
                    succeed_threads.append(url)
                    break
                else:
                    if show_failed_output:tmp_console.print(f"[#f00000]线程{url}返回[#F07000]{response.status_code}，失败")
                    break
            except:
                if show_failed_output:tmp_console.print(f"[#f0c000]线程{url}执行出错，重新执行")
                continue

        thread_count -= 1
        threads.remove(url)


    tmp_console.print("[#F0F000]轰炸中...")
    utc = utc_range[0]
    progress.start()
    t2 = progress.add_task("进度")
    t = progress.add_task("线程数")




    completed = 0

    while utc <= utc_range[1]:

        if thread_count <= max_thread_count:
            thread = threading.Thread(target=get_response,kwargs={"url": base_url.format(utc)})
            thread.start()
            completed += 1
            utc += 1
        progress.update(t,total=max_thread_count,completed=thread_count,description=f"线程占用：{str(thread_count).rjust(4)}/{max_thread_count}")
        progress.update(t2,total=utc_range[1] - utc_range[0],completed=utc-utc_range[0],description=f"已完成：{str(completed).rjust(6)}/{utc_range[1] - utc_range[0]}")

    tmp_console.print("[#20F080]线程全部启动完成")
    progress.remove_task(t)
    progress.remove_task(t2)
    progress.stop()
    progress.start()
    t = progress.add_task("线程数")
    def update_alive_thread_count():
        while thread_count >= 1:
            progress.update(t,total=max_thread_count,completed=thread_count,description=f"剩余线程：{str(thread_count).rjust(4)}/{max_thread_count}")

    threading.Thread(target=update_alive_thread_count).start()

    try:
        while True:
            time.sleep(10)    
            if threads != []:
                console.print(Rule("仍然存活的线程"))
                console.print("[#20F0F0]"+'\n'.join(threads),end="")
            console.print(Rule("执行成功的线程"))
            if succeed_threads == []:
                console.print("[#F0F000]（暂无）")
            else:
                console.print("[#20F0F0]"+'\n'.join(succeed_threads),end="")
            console.print(Rule())
    except:
        pass

    progress.remove_task(t)
    progress.stop()


        

def main():
    try:
        console.print(info_color+"请输入url，示例：https://smartwatch.qiniucdn.com/ota_f_v2.0.5_t{}.zip")
        base_url = input_prompt("输入url（用'{}'代替utc）", validator=lambda s:s.count("{}") == 1,error_message="请输入包含'{}'的字符串",default_text="https://smartwatch.qiniucdn.com/ota_f_vx.x.x_t{}.zip")
        console.print(info_color+"\n请输入utc范围")
        utc_range = (int(input_prompt("输入utc起始数:", validator=lambda s:s.isdigit())),
                    int(input_prompt("输入utc终止数:", validator=lambda s:s.isdigit())))
        console.print()
        max_thread_count = int(input_prompt("请输入最大线程数（建议1024）","1024",lambda s:s.isdigit()))
        show_err = confirm_prompt("是否显示错误信息？")
        pause(info_color+f"设置完成，按任意键开始...{tip_color}（如果得到结果了按ctrl+c退出）")
        try:
            boom(base_url,utc_range,max_thread_count,show_err)
        except KeyboardInterrupt:
            pass
        console.print(success_color+"完成！")
        pause()
    except:
        pass



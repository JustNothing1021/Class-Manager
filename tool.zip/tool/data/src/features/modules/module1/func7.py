from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global device_sn_args
    exist_offlined_device = False
    exist_unauthorized_device = False
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的检测当前连接（7）。")
    write_log(SCRIPT_FILE_NAME,pid,1,"在2秒后检测ADB设备...")
    if device_sn_args != "":
        show_msgbox("检测设备",tip_color+"已经取消强制指向设备！\n将在2秒后检测设备...",use_console=True)
        device_sn_args = ""
        set_variable("device_sn_args","")
        write_log(SCRIPT_FILE_NAME,pid,1,"设备强制指向已取消。")
    else:
        show_msgbox("检测设备",tip_color+"将在2秒后检测设备...",use_console=True)
    time.sleep(2)
    console.print(info_color+"\n检测ADB设备连接...")
    output = run_command("adb devices",point_to_device=False,silent=True)
    console.print(tip_color+"当前连接的设备：\n")
    device_count = 0
    output = output.splitlines()
    if len(output) > 1:
        for device in range(1,len(output)):
            if len(output[device].split("\t")) == 2:
                device_count += 1
                device = output[device]
                console.print(value_color+device.split('\t')[0]+f"  {tip_color}->{close_tag}   ",end="")
                if "offline" in str(device).split("\t")[1]:
                    console.print(warn_color+"已离线")
                    write_log(SCRIPT_FILE_NAME,pid,1,"检测到设备%s，状态：离线"%device.split("\t")[0])
                    exist_offlined_device = True 
                elif "unauthorized" in str(device).split("\t")[1]:
                    console.print(tip_color+"未授权")
                    write_log(SCRIPT_FILE_NAME,pid,1,"检测到设备%s，状态：未授权"%device.split("\t")[0])
                    exist_unauthorized_device = True
                elif "device" in str(device).split("\t")[1]:
                    write_log(SCRIPT_FILE_NAME,pid,1,"检测到设备%s，状态：已连接"%device.split("\t")[0])
                    console.print(success_color+"已连接")
    else:
        device_count = 0
    if device_count == 0:
        console.print(warn_color+"（暂无设备）")
        write_log(SCRIPT_FILE_NAME,pid,1,"暂未检测到设备...")
        console.print(tip_color+"\n可能是驱动没安装好，手表adb没打开或者数据线没接好")
    if exist_offlined_device:
        write_log(SCRIPT_FILE_NAME,pid,1,"有离线的设备，将会提示用户...")
        console.print(tip_color+"\n检测到了离线的设备，可以试着把设备拔了重新连接一下")
    if exist_unauthorized_device:
        write_log(SCRIPT_FILE_NAME,pid,1,"有未授权的设备，将会提示用户...")
        console.print(tip_color+"\n检测到了未授权的设备，可以试着设备重启一下")
    if (not exist_offlined_device) and (not exist_unauthorized_device) and len(output) > 1 and device_count > 0:
        write_log(SCRIPT_FILE_NAME,pid,1,"连接正常！")
        console.print(success_color+"\n 一切正常！")
    del exist_offlined_device,exist_unauthorized_device
    pause()
    console.print("────────────────────────────────")
    write_log(SCRIPT_FILE_NAME,pid,1,"检测高通设备连接...")
    console.print(info_color+"检测高通的设备连接...")
    output = run_command("lsusb",show_output=False)
    console.print(tip_color+"当前连接的设备：\n")
    if output == "":
        write_log(SCRIPT_FILE_NAME,pid,1,"暂未检测到设备")
        console.print(warn_color+"（暂无设备）")
        console.print(tip_color+"\n可能是驱动没安装好或者数据线没接好")
    else:
        write_log(SCRIPT_FILE_NAME,pid,1,"检测到的设备：%s"%output)
        print(output)
        if "9008" in output:
            console.print(success_color+"\n检测到了在9008（刷机模式）的设备，应该是没问题了")
            write_log(SCRIPT_FILE_NAME,pid,1,"检测到在9008的设备")
        elif "90B8" in output:
            write_log(SCRIPT_FILE_NAME,pid,1,"检测到在90B8的设备")
            console.print(success_color+"\n检测到了在90B8（正常模式）的设备，应该是没问题了")
        elif "900E" in output:
            write_log(SCRIPT_FILE_NAME,pid,1,"检测了砖头（900E）设备")
            console.print(tip_color+"\n检测到了在900E（可能是砖头模式）的设备，驱动没问题了，恭喜你有了一个砖头（开个玩笑，赶紧去救砖吧）")
        elif "9091" in output:
            write_log(SCRIPT_FILE_NAME,pid,1,"检测到在9091的设备")
            console.print(success_color+"\n检测到了在9091（应该也是正常模式）的设备，应该是没问题了")
        else:
            write_log(SCRIPT_FILE_NAME,pid,1,"检测到了设备，应该没问题")
            console.print(success_color+"\n检测到了设备，应该没问题")
    write_log(SCRIPT_FILE_NAME,pid,1,"将在按任意键后返回菜单...")
    pause()


from src.init_utils import *
from payload_dumper.dumper import Dumper




def main():

    payloadfile = input_prompt("请输入payload.bin的目录：",validator=lambda s:exist(s),error_message="请输入一个存在的路径")
    if payloadfile.startswith('"') and payloadfile.endswith('"'):payloadfile = payloadfile[0:-1][1:]

    out = input_prompt("请输入解压到的目录：",validator=lambda s:exist(s),error_message="请输入一个存在的路径",default_text=f"{CACHE_PATH}\\payload_extract")
    if out.startswith('"') and out.endswith('"'):out = out[0:-1][1:]


    if not os.path.isdir(out):
        md(out)
        Dumper(payloadfile,out).run()
    pause(success_color+"完成！（按任意键继续）")
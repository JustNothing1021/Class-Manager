from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"


def read_key(file:FileDescriptorOrPath):
    str_key = None
    if file.startswith('"') and file.endswith('"'):
        file = file[1:][0:-1]
    try:
        f = open(file,mode="rb")
        b = f.read(3608)
        stat = [False] * 3              # 因为有3个key所以*3
        read_stat = False
        for count in range(3):             # key会重复三次，从0x800(2048)开始，每0x208(520)字节重复一次
            start_pos = count * 520 + 2048
            stat[count] = False
            key_len = struct.unpack("<I", b[start_pos:start_pos+4])[0]    
            # 计算第2048-2051（0x800-0x803）的数据，存储key的长度，若小于等于512则判定为接下来为key
            # 注：此处key_len标记的是key的长度，比如我这次测试得到的是161
            if key_len <= 512:
                crc = struct.unpack("<I", b[start_pos+4:start_pos+8])[0]   # crc标记的是0x804-0x807(2052-2055)包含的数据，后面做校验会用到
                # 取首个（因为读到的是元组）
                key = b[start_pos+8:start_pos+8+key_len]                   # 根据获取到的起始位置（start_pos+8）和长度i4读取指定位置
                calculated_crc = calculate_crc(key, key_len)               # 对数据做校验（方法是固定的）
                if crc == calculated_crc:                                  # 如果两个数据是能对上的，说明没有问题
                    stat[count] = True                                     # 如果读取成功了，做个标记(没读取成功的话就还是false)
                    if not read_stat:
                        str_key = key.decode("utf-8")
                        read_stat = True                                   # 如果有一个读取成功了就不需要读取了
    except Exception as e:
        console.print(err_color+"读取key遇到错误："+str(sys.exc_info()[1].__name__)+":"+e)
    finally:
        f.close()
    return str_key


def set_key(info_path:FileDescriptorOrPath,key:str,out_path:FileDescriptorOrPath):
    if info_path.startswith('"') and info_path.endswith('"'):
        info_path = info_path[1:][0:-1]
    if out_path.startswith('"') and out_path.endswith('"'):
        out_path = out_path[1:][0:-1]
    if not os.path.isfile(info_path):
        raise ValueError("请指定一个xtcinfo文件...")

    
    info_b_arr = bytearray(3608)

    try:
        with open(info_path,"rb") as file_input_stream:
            file_input_stream.readinto(info_b_arr)   # 将指定的xtcinfo文件写入bytearray
        file_input_stream.close()

    except IOError as e:
        console.print(err_color+"读取文件遇到错误："+str(sys.exc_info()[1].__name__)+":"+e)
        return

    try:
        with open(out_path,"wb") as file_output_stream:
            bytes_key = key.encode("utf-8")                                 # 将key转换为字节
            calculated_crc = calculate_crc(bytes_key, len(bytes_key))       # 计算crc值
            # 接下来写入key内容前面的8字节
            info_b_arr[2048] = len(bytes_key) & 255                        # key的长度 & 255（位运算，与）
            info_b_arr[2049] = (len(bytes_key) >> 8) & 255                 # 二进制向右位移8位数，移出去的直接丢了，空出来的补上0（这里基本只会出现0和1了）
            info_b_arr[2050] = (len(bytes_key) >> 16) & 255                # 只可能是0，象征性写一下
            info_b_arr[2051] = (len(bytes_key) >> 24) & 255
            info_b_arr[2052] = calculated_crc & 255                        # 同理
            info_b_arr[2053] = (calculated_crc >> 8) & 255
            info_b_arr[2054] = (calculated_crc >> 16) & 255
            info_b_arr[2055] = (calculated_crc >> 24) & 255
            info_b_arr[2056:2056 + len(bytes_key)] = bytes_key
            
            for i in range(2):
                info_b_arr[i*520+2048:i*520+2048+520] = info_b_arr[2048:2048+520]   # 再写两次，520字节重复一次

            file_output_stream.write(info_b_arr)        # 修改完后存回去

    except IOError as e:
        console.print(err_color+"写入key遇到错误："+str(sys.exc_info()[1].__name__)+":"+e)
        return

    security_key_from_xtc_info = read_key(out_path)                # 看一下生成的xtcinfo能不能对上

    return security_key_from_xtc_info is not None and security_key_from_xtc_info == key



def calculate_crc(b_arr, i):    # 做校验的函数，根据获取到的key做校验会获得一个数字，看这个数字和key前面的几个字节给出的能不能对上
    i2 = 65535
    for i3 in range(i):
        i2 ^= b_arr[i3] << 8
        for _ in range(8):
            i2 = (0x8000 & i2) != 0 and (i2 << 1) ^ 4129 or (i2 << 1)
    return i2 & 0xffff


def read_key_from_file():
    file = input_prompt("请输入文件路径/托载后回车：")
    selfRsaPublicKey = read_key(file)
    if selfRsaPublicKey is None:
        console.print(warn_color+"提取失败...确定这是一个新版的xtcinfo文件吗？")
    else:
        console.print(info_color+"提取出来的selfRsaPublicKey：\n"+value_color+selfRsaPublicKey)

def read_key_from_watch(output:bool=True,decrypt:bool=True) -> Tuple[str,bool]:
    if decrypt:
        if output:console.print(info_color+"从手表中提取xtcinfo...")
        run_command("adb shell su -c cp /dev/block/bootdevice/by-name/xtcinfo /data/local/tmp/xtcinfo",show_output=output)
        run_command(f"adb pull /data/local/tmp/xtcinfo {CACHE_PATH}\\",show_output=output)
        run_command("adb shell rm -r /data/local/tmp/xtcinfo",show_output=output)
        if not exist(f"{CACHE_PATH}\\xtcinfo"):
            console.print(warn_color+"提取失败...手表中或许没有这个分区/版本太低/没有su权限？\n可以尝试用QFIL提取xtcinfo后单文件分析")
            return None, True
        selfRsaPublicKey = read_key(f"{CACHE_PATH}\\xtcinfo")
        if selfRsaPublicKey is None:
            console.print(warn_color+"提取失败...")
        else:
            if output:console.print(info_color+"提取出来的selfRsaPublicKey"+success_color+F"（已解密）{close_tag}：\n"+value_color+selfRsaPublicKey)
            remove(f"{CACHE_PATH}\\xtcinfo")
        return selfRsaPublicKey, True
    else:
        try:
            output = run_command("adb shell content query --uri content://com.xtc.initservice/item --projection selfRsaPublicKey")
            selfRsaPublicKey = strip(output.split("selfRsaPublicKey=")[1])
        except:
            console.print(err_color+"selfRsaPublicKey提取失败...")
            return None, False
        console.print(info_color+"提取出来的selfRsaPublicKey"+warn_color+F"（未解密）{close_tag}：\n"+value_color+selfRsaPublicKey)
        return selfRsaPublicKey, False

def write_key_to_file():
    path = input_prompt("请输入xtcinfo文件的路径：",validator=lambda s:s != "",error_message="请输入路径")
    key = input_prompt("请输入解密后的key：",validator=lambda s:s != "",error_message="key")
    out = input_prompt("请输入保存新xtcinfo文件的路径：",validator=lambda s:s != "",error_message="请输入路径")
    if os.path.isdir(out):
        if out.startswith("\"") and out.endswith("\""):
            out = out[1:][0:-1]
        if out.endswith("\\"):
            out += "xtcinfo.img"
        else:
            out += "\\xtcinfo.img"

    console.print(info_color+"开始写入...")
    if exist(out):
        pause(warn_color+f"当前保存的路径({out})已经存在该文件，按任意键继续覆盖")
    if set_key(path, key, out):
        console.print(success_color+"写入成功！")
    else:
        console.print(err_color+"写入失败！")
    pause()
    

def main():
    data = ListPrompt("需要进行什么操作？",
               [Choice("1.从文件中尝试提取（可用QFIL提取xtcdata分区后使用）",read_key_from_file),
                Choice("2.从手表中尝试提取（需要root和用户分区内内至少1MB空余）",read_key_from_watch),
                Choice("3.向现有的xtcinfo文件写入key（需已解密的key）",write_key_to_file),
                Choice("0.取消","exit")],
                pointer=ListPrompt_pointer,
                annotation=ListPrompt_annotation).prompt(ListPrompt_style).data
    if data == "exit": return
    data()
    pause("执行完成！（按任意键继续）")










from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global device_sn_args, SCRIPT_FILE_NAME, console
    if device_sn_args != "":
        device_sn_args = ""
        write_log(SCRIPT_FILE_NAME,pid,1,"设备强制指向已取消。")
        console.print(tip_color+"已经取消了当前强制指向的的设备！")
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的断开所有连接（6）。")
    write_log(SCRIPT_FILE_NAME,pid,1,"断开所有连接...")
    console.print(info_color+"断开所有连接...")
    output = run_command("adb disconnect")
    if "disconnected everything" not in output:
        console.print(warn_color+"不知道是不是出错了，没有看到正确的输出")
        write_log(SCRIPT_FILE_NAME,pid,2,"断开连接貌似失败了...")
    else:
        console.print(success_color+"完成！（按任意键返回菜单）")
    write_log(SCRIPT_FILE_NAME,pid,1,"将在按任意键后返回菜单...")
    pause(False)
from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes, defaultcolor
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH, COMMON_MBN_PATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    global cwd, device_sn_args
    device_sn_args = get_variable("device_sn_args","__main__")
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的查看ip地址（4）。")
    write_log(SCRIPT_FILE_NAME,pid,1,"等待设备连接...")
    wait_for_device()
    console.print(info_color+"详细输出：")
    console.print("─────────────────────────────")
    output = run_command("adb shell ifconfig wlan0")
    console.print("─────────────────────────────")
    if len(output.splitlines()) <= 6:
        write_log(SCRIPT_FILE_NAME,pid,1,"当前设备貌似没有连接到局域网...将在按任意键后返回上一级")
        console.print(warn_color+"当前设备貌似没有连接到局域网...（按任意键返回菜单）")
    else:
        deviceip = "null"
        if "inet addr" in output:
            deviceip = str(output[output.find("inet addr:")+len("inet addr:"):]).split(" ")[0] # 从inet addr:开始到出现空格的字符
        if isIpv4address(deviceip):
            write_log(SCRIPT_FILE_NAME,pid,1,"读取成功，ip为[%s]。将在按任意键后返回上一级..."%deviceip)
            console.print(info_color+f"当前设备在局域网的ip：{value_color}\[{deviceip}]")
            console.print(success_color+"完成！（按任意键返回菜单）")
        else:
            write_log(SCRIPT_FILE_NAME,pid,2,"读取失败...将在按任意键后返回上一级")
            console.print(err_color+"读取失败...试着自己找一项叫做inet addr的项目？（按任意键返回菜单）")
    pause(False)

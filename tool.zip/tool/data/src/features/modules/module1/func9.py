from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"



def generate_adb_code(input_num:int,method=Literal["1","2","3"]) -> Optional[str]:
    "将输入的数字转化为adb校验码"
    if method == "1":
        input_num = str(input_num)
        if len(input_num) > 7:
            if len(input_num) < 9:
                console.print(err_color+"计算失败：输入的数字长度小于等于8，当前算法无法计算")
                return None
            try:
                int(input_num)
            except ValueError:
                console.print(err_color+"计算失败：输入的数字不合法")
                return None
            i = int(input_num[0:2])
            n = int(input_num[2:4])
            h = int(input_num[4:6])
            m = int(input_num[6:8])
            j = int(input_num[8:])
            d = j ^ (h + m)
            p = m ^ d
            t = h ^ d
            u = i ^ d
            s = n ^ d
            input_num = f"{u:02}{s:02}{t:02}{p:02}{d}"
            if len(input_num) < 9:
                console.print(err_color+"计算失败：计算过程中字符串长度不正常，该算法无法计算")
                return None
            try:
                int(input_num)
            except ValueError:
                console.print(err_color+"计算失败：计算过程中字符串转整形失败")
                return None
            i = int(input_num[0:2])
            n = int(input_num[2:4])
            h = int(input_num[4:6])
            m = int(input_num[6:8])
            j = int(input_num[8:])
            d = m ^ h
            p = j ^ h
            t = h ^ (d + p)
            u = i ^ p
            s = n ^ p
            result = f"{u:02}{s:02}{d:02}{p:02}{t}"
            return result

    elif method == "2":
            result =  input_num[-1] + input_num[:-1]
            tmp = []
            for char in result:
                tmp.append(char)
            split_tmp = tmp[len(tmp) - 1]
            tmp[7] = tmp[6]
            tmp[6] = tmp[5]
            tmp[5] = tmp[4]
            tmp[4] = tmp[3]
            tmp[3] = tmp[2]
            tmp[2] = tmp[1]
            tmp[1] = tmp[0]
            tmp[0] = split_tmp
            result = "".join(tmp)
            return result
    
    elif method == "3":
        input_num = str(input_num)
        return input_num[-1] + input_num[:-1]

def main():
    console.print(info_color+f"\n请输入adb校验码{tip_color}（8位数的可能算不了，可以找大佬）{close_tag}...")
    inputmsg = input_prompt("输入：")
    algorithm = ListPrompt("请选择你需要使用的算法（一个不行就用另一个试下）：",
                        [
                            Choice("算法1（经过复杂计算，老版本）","1"),
                            Choice("算法2（调换数据位置，新版本）","2"),
                            Choice("算法3（最抽象的，把最后一个数字放到开头，不知道什么版本）","3")
                        ],
                        pointer=ListPrompt_pointer,
                        annotation=ListPrompt_annotation
                        ).prompt(ListPrompt_style).data
    
 
        
    if len(inputmsg) > 0:
        console.print(info_color+"计算中...")
        adb_code = generate_adb_code(inputmsg,algorithm)
        if adb_code != None:
            console.print(f"{success_color}校验码：{value_color}{adb_code}")
        else:
            console.print(err_color+"计算失败...")
        pause()


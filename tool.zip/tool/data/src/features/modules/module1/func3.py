from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes, defaultcolor
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH, COMMON_MBN_PATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的选择设备（3）。")
    console.print(info_color+"\n检测当前连接...")
    write_log(SCRIPT_FILE_NAME,pid,1,"检测当前连接...")
    output = run_command("adb devices","UTF-8",False,False)
    output = output.splitlines()
    if len(output) == 2:
        write_log(SCRIPT_FILE_NAME,pid,1,"只有一个ADB设备，不需要操作")
        console.print(info_color+"当前只连接了一个设备，其实不需要选择设备的...")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前的ADB设备：%s"%output[1])
        console.print(info_color+"当前连接的设备："+info_color+str(output[1]))

    elif len(output) > 2:
        devlist = []
        devlist_dict = {}
        write_log(SCRIPT_FILE_NAME,pid,1,"设备多于一个，将会进入选择界面。")
        console.print(tip_color+"检测到了多个设备连接。")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前连接的设备列表：")
        for devicenum in range(1,len(output)):
            devlist_dict[devicenum] = output[devicenum]
            write_log(SCRIPT_FILE_NAME,pid,1,output[devicenum])
            devlist.append(Choice(output[devicenum].split("\t")[0],devicenum))
        devlist.append(Choice("重置当前的指向",0))

 
        if not (device_sn_args == "" or device_sn_args.isspace()):
            console.print(f"{info_color}当前选择的设备：{tip_color}{device_sn_args.split(' ')[1]}")
        console.print(tip_color+"\n那么你想要操作的是哪一个设备？")
        write_log(SCRIPT_FILE_NAME,pid,1,"请求用户选择设备...")
        choose_device_num = ListPrompt("请选择设备：",
                                       devlist,
                                       annotation=ListPrompt_annotation,
                                       pointer=ListPrompt_pointer,
                                       ).prompt(style=ListPrompt_style).data

        if choose_device_num == 0:
                console.print(info_color+"正在重置...")
                device_sn_args = ""
                console.print(success_color+"设置完成！")

        else:
            choosed_device_sn = devlist_dict[choose_device_num]
            choosed_device_sn = str(choosed_device_sn).split("\t")[0]
            write_log(SCRIPT_FILE_NAME,pid,1,"选择的设备：%s"%choosed_device_sn)
            console.print(info_color+"选择的设备：%s"%choosed_device_sn)
            device_sn_args = "-s %s"%choosed_device_sn
            console.print(success_color+"设置完成！")

    else:
        console.print(warn_color+"（暂无）\n")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前暂未连接设备...那他来这里干嘛？")
        console.print(tip_color+"\n当前暂无设备连接...等有设备之后再来吧？")
    set_variable("device_sn_args",device_sn_args,"__main__")

    pause()

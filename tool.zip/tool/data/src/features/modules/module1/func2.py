from src.init_utils import *



SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes, defaultcolor
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH, COMMON_MBN_PATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的进行无线连接（2）。")
    if device_sn_args != "":
        device_sn_args = ""
        write_log(SCRIPT_FILE_NAME,pid,1,"设备指向已取消。")
        console.print(warn_color+"已经取消了当前指向的设备！")
    write_log(SCRIPT_FILE_NAME,pid,1,"读取上一次使用的adb的ip...")
    if not exist(f"{SETTING_PATH}\\lastest_wireless_connection_ip.txt"):
        write_textfile(f"{SETTING_PATH}\\lastest_wireless_connection_ip.txt","unknown")
    lastest_adb_connection_ip = read_file_to_variables("%s\\lastest_wireless_connection_ip.txt"%SETTING_PATH)
    write_log(SCRIPT_FILE_NAME,pid,1,"读取的内容：[%s]"%lastest_adb_connection_ip)
    if lastest_adb_connection_ip == "unknown" or not isIpv4address(lastest_adb_connection_ip):
        if lastest_adb_connection_ip == "unknown":write_log(SCRIPT_FILE_NAME,pid,1,
            "这貌似是第一次使用这个功能，没有读取到上一次的ip")
        elif not isIpv4address(lastest_adb_connection_ip):write_log(SCRIPT_FILE_NAME,pid,1,
            "上一次输入的ip不正确，将会忽略")
        console.print(f"{info_color}请输入手表无线adb开启的ip和端口（如127.0.0.1:5555）")
        console.print(f"{tip_color}注意：冒号必须是英文的")
        console.print(f"{tip_color}（不想要输入了就输入0返回上一级，不论在哪里都一样）")
        current_adb_connection_ip = input_prompt("你的选项：",
                                                validator=lambda string:isIpv4address(string) or string == "0",
                                                error_message="请输入一个合法的ipv4地址")
        write_log(SCRIPT_FILE_NAME,pid,1,"用户输入了[%s]。"%(current_adb_connection_ip))
        if current_adb_connection_ip == "":
            write_log(SCRIPT_FILE_NAME,pid,1,"用户没有输入，将会重新调起输入...")
            console.print(warn_color+"你没有输入...将会重新请求输入")
        elif current_adb_connection_ip == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"将会返回上一级...")

    else:
        console.print(f"{info_color}上一次输入的ip地址和端口：{value_color}\[{lastest_adb_connection_ip}][/]")
        console.print(f"{info_color}如果要连接到这个端口的话这里留空（直接按回车不输入任何东西）")
        console.print(f"{info_color}如果要换一个地址的话直接在这里输入就好,退出的话输入0")
        current_adb_connection_ip = input_prompt("你的选项：",
                                                validator=lambda string:isIpv4address(string) or string == "0" or string == "",
                                                error_message="请输入一个合法的ipv4地址")
        if current_adb_connection_ip == "":
            current_adb_connection_ip = lastest_adb_connection_ip
        write_log(SCRIPT_FILE_NAME,pid,1,"用户输入了[%s]。"%(current_adb_connection_ip))
        
        if current_adb_connection_ip == "0":
            write_log(SCRIPT_FILE_NAME,pid,1,"将会返回上一级...")

    if current_adb_connection_ip == "0":
        return
    write_textfile("%s\\lastest_wireless_connection_ip.txt"%SETTING_PATH,current_adb_connection_ip)
    write_log(SCRIPT_FILE_NAME,pid,1,"开始连接到%s..."%current_adb_connection_ip)
    console.print(info_color+"连接到%s..."%current_adb_connection_ip)
    output = run_command("adb connect %s"%(current_adb_connection_ip))
    if "failed to authenticate" in output:
        write_log(SCRIPT_FILE_NAME,pid,1,"应该是授权失败了，再连接一次应该就行了")
        console.print(warn_color+"认证失败了，再连接一次或许会有用？")

    elif "already connected to" in output:
        write_log(SCRIPT_FILE_NAME,pid,1,"应该是已经连接好了")
        console.print(success_color+"已经连接到这个设备了，快去试试吧！")

    elif "connected to" in output:
        write_log(SCRIPT_FILE_NAME,pid,1,"连接成功！")
        console.print(success_color+"连接成功！")
    else:
        write_log(SCRIPT_FILE_NAME,pid,1,"连接失败.....是不是输错了？")
        console.print(err_color+"连接失败...")
    pause()

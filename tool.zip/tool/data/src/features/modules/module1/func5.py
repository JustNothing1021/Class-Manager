from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes, defaultcolor
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH, COMMON_MBN_PATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    global cwd, device_sn_args
    device_sn_args = get_variable("device_sn_args","__main__")
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的有线转无线连接（5）。")
    console.print(tip_color+"这个东西不一定会成功，有些版本不允许使用tcpip指令（看运气吧）")
    console.print(info_color+"获取当前设备在局域网中的ip...")
    write_log(SCRIPT_FILE_NAME,pid,1,"读取设备ip...")
    wait_for_device()
    console.print("─────────────────────────────")
    output = run_command("adb shell ifconfig wlan0")
    console.print("─────────────────────────────")
    if len(output.splitlines()) <= 6:
        console.print(err_color+"当前设备貌似没有连接到局域网...（按任意键返回菜单）")
        pause(False)
        return
    else:
        deviceip = "null"
        if "inet addr" in output:
            deviceip = str(output[output.find("inet addr:")+len("inet addr:"):]).split(" ")[0] # 从inet addr:开始到出现空格的字符
        if isIpv4address(deviceip):
            write_log(SCRIPT_FILE_NAME,pid,1,"ip读取成功，为[%s]。"%(deviceip))
            console.print(info_color+"当前设备在局域网的ip：\[%s]"%deviceip)
            console.print(info_color+"完成！")
        else:
            write_log(SCRIPT_FILE_NAME,pid,2,"ip读取失败...")
            console.print(err_color+"读取失败...试着自己手动连接？（也可能没有连接到局域网，按任意键返回菜单）")
            pause(False)
            return
    write_log(SCRIPT_FILE_NAME,pid,1,"重启adb到端口%d..."%(WIRELESS_PORT))
    console.print(info_color+"\n让设备在端口%d监听TCP/IP连接...（说的这么高级就是adb tcpip %d）"%(WIRELESS_PORT,WIRELESS_PORT))
    if str(WIRELESS_PORT).isdigit():
        if not(int(WIRELESS_PORT) >= 0 and int(WIRELESS_PORT) <= 65535):
            console.print(err_color+"脚本内部配置有误！")
            return
    output = run_command(f"adb tcpip {WIRELESS_PORT}")
    if "USER-VERSION" in output.upper():
        write_log(SCRIPT_FILE_NAME,pid,1,"当前版本用不了tcpip指令，连接失败...")
        console.print(err_color+"当前版本貌似用不了tcpip指令...（按任意键返回菜单）")
        pause(False)
        return
    write_log(SCRIPT_FILE_NAME,pid,1,"连接到%s:%d..."%(deviceip,WIRELESS_PORT))
    console.print(info_color+"\n连接到%s:%d..."%(deviceip,WIRELESS_PORT))
    output = run_command("adb connect %s:%d"%(deviceip,WIRELESS_PORT))
    if "failed to authenticate" in output:
        write_log(SCRIPT_FILE_NAME,pid,1,"应该是授权失败了，再连接一次应该就行了")
        console.print(warn_color+"\n认证失败了，再连接一次或许会有用？")

    elif "already connected to" in output:
        write_log(SCRIPT_FILE_NAME,pid,1,"应该是已经连接好了")
        console.print(info_color+"\n已经连接到这个设备了...")

    elif "connected to" in output:
        write_log(SCRIPT_FILE_NAME,pid,1,"连接成功！")
        console.print(success_color+"\n连接成功！")
    else:
        write_log(SCRIPT_FILE_NAME,pid,1,"连接失败.....出错了？")
        console.print(err_color+"\n连接失败...看看输出说不定能找到问题？")
    write_log(SCRIPT_FILE_NAME,pid,1,"将在按任意键后返回菜单...")
    pause()
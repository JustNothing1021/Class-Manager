from src.init_utils import *
from src.features.modules.module1.func11 import read_key_from_watch




get_list = [
        ("ro.product.model","ro.product.model"),
        ("ro.product.innermodel","ro.product.innermodel"),
        ("ro.product.current.softversion","ro.product.current.softversion"),
        ("ro.product.jenkins.number","ro.product.jenkins.number"),
        ("ro.build.date.utc","ro.build.date.utc"),
        ("ro.build.date","ro.build.date"),
        ("ro.product.codebranch","ro.product.codebranch"),
        ("ro.boot.xtc.chipid","ro.boot.xtc.chipid"),
        ("ro.product.commit","ro.product.commit"),
        ("ro.boot.bindnumber","ro.boot.bindnumber")
]

SCRIPT_FILE_NAME = f"script:{__name__}"

def bak_sysinfo(save_path:Optional[str]=None,
                save_name:str="system.prop",
                auto_pause:bool=True,
                get_list:List[str]=get_list,
                by_prop:bool=True):
    wait_for_device()
    if save_path is None:
        save_path = f"{BACKUP_PATH}\\info_bak\\{getprop('ro.boot.bindnumber')}\\system\\{get_saving_name()}"

    console.print(tip_color+"──────────────────────────")
    save_file = save_path + "\\" + save_name
    if not exist(save_path):
        md(save_path)
    if by_prop and not exist(save_file):
        write_bytesfile(save_file,"# 以下是重要信息的备份\n".encode("utf-8"),cover=False)
    for key, desc in get_list:
        value = getprop(key)
        
        if by_prop:
            write_bytesfile(save_file,str(key+"="+value+"\n").encode("utf-8"),cover=False)
        else:
            write_bytesfile(save_file,str(key+":\n"+value+"\n\n").encode("utf-8"),cover=False)

        console.print(f"{info_color}{tip_color}{desc}{close_tag}: {value_color}{value}{close_tag}")
    console.print(tip_color+"──────────────────────────")
    if auto_pause:
        console.print(success_color+"完成！文件备份储存在"+tip_color+"\["+save_path+"]"+close_tag+"\n（记得检查！）")
        pause()


    

def rec_sysinfo():
    ""
    global get_list
    execute = ListPrompt("请选择恢复信息的来源：",
               [Choice("1.手动输入","from_input"),
                Choice("2.从已存储的文件(prop)","from_file"),
                Choice("0.取消","exit")],
                pointer=ListPrompt_pointer,
                annotation=ListPrompt_annotation).prompt(ListPrompt_style).data
    if execute == "exit":
        return
    elif execute == "from_input":
        console.print(tip_color+"如果有无需备份的项目留空即可（不输入直接按回车）")
        completed = 0
        data = {}
        for item in get_list:
            completed += 1
            data[item] = input_prompt(F"[{completed}/{len(get_list)}]"+item+"=")
        console.print(success_color+"数据输入完成！")
    elif execute == "from_file":
        try:
            prop_line = text_file_readlines(input_prompt("请输入文件路径："),encoding="utf-8")
        except (FileNotFoundError, IsADirectoryError, UnicodeDecodeError, PermissionError):
            console.print(err_color+"打开文件失败...")
            return
        console.print(info_color+"读取的内容：")
        console.print(info_color+"──────────────────────────────────")
        data = {}
        for line in prop_line:
            if line == "\n":break
            if line.endswith("\n"):line = line[0:-1]
            if line.startswith("#"):
                continue
            try:
                key = line.split("=")[0]
                val = line.split("=")[1]
            except:
                console.print(err_color+"解析文件失败...")
                return
            console.print(f"{tip_color}{key}{close_tag}={value_color}{val}{close_tag}")
            data[key] = val
        console.print(info_color+"──────────────────────────────────")
    choice = ListPrompt("请选择恢复信息的方式：",
               [Choice("1.setprop",rec_sys_by_setprop),
                Choice("2.生成模块",rec_sys_by_module),
                Choice("0.取消","exit")],
                pointer=ListPrompt_pointer,
                annotation=ListPrompt_annotation).prompt(ListPrompt_style).data
    if choice == "exit":
        console.print(info_color+"已取消！")
        return
    console.print(tip_color+"按任意键开始...")
    pause(False)
    console.print(info_color+"──────────────────────────────────")
    choice(get_list,data)
    console.print(info_color+"──────────────────────────────────")


def rec_sys_by_setprop(get_list:list,data:dict):
    completed = 0
    wait_for_device()
    for item in get_list:
        completed += 1
        console.print(F"\[{completed}/{len(get_list)}]"+info_color+"恢复"+value_color+item+"...",end="")
        try:
            val = data[item]
        except:
            console.print(warn_color+"无法恢复"+item+"：不存在")
            continue
        if val.isspace() or val == "":
            console.print(warn_color+"无法恢复"+item+"：未指定/为空")
            continue
        if run_command(f"adb shell setprop {item} {val}",show_output=False) != "":
            console.print(err_color+"疑似失败...")
        else:
            console.print(success_color+"完成！")
    console.print("\n"+success_color+"执行完成！")



def rec_sys_by_module(get_list:list,data:dict):
    remove("module.zip")
    console.print(info_color+"生成模块中...")
    tmp_path = f"{CACHE_PATH}\\module_tmp"
    cptree(f"{FILE_PATH}\\module_file",tmp_path)
    prop = ""
    for item in get_list:
        if data[item] == "" or  data[item].isspace():
            console.print(warn_color+f"警告：需要的属性\"{item}\"未指定。")
            continue
        try:
            prop += item + "=" + data[item] + "\n"
        except:
            console.print(warn_color+f"警告：需要的属性\"{item}\"未指定。")
    if len(prop) == 0:
        console.print(err_color+"错误：生成模块失败：没有需要生成的项目！")
        try:
            shutil.rmtree(tmp_path)
            shutil.rmtree(cwd+"\\module_tmp")
        except:
            pass
        return
    write_textfile(tmp_path+"\\common\\system.prop",prop)
    cp(f"{FILE_PATH}\\module_file\\README.md",tmp_path)
    cptree(tmp_path,cwd+"\\module_tmp")
    shutil.rmtree(tmp_path)
    file_list = list_tree("module_tmp",build_base_dir=True)
    for f in file_list:
        write_zipfile(f,dst="module.zip",mode="a",build_base_dir=False)
    shutil.rmtree(cwd+"\\module_tmp")
    copy("module.zip","\\".join(cwd.split("\\")[0:-1]))
    remove("module.zip")
    console.print(success_color+f"模块生成在了\[{tip_color}"+"\\".join(cwd.split("\\")[0:-1])+f"\\module.zip{close_tag}]\n完成！")
    console.print(tip_color+"需要将模块安装到设备上吗？（安装完毕会自动删除）")
    if confirm_prompt():
        wait_for_device()
        install_module("\\".join(cwd.split("\\")[0:-1])+"\\module.zip")
        remove("\\".join(cwd.split("\\")[0:-1])+"\\module.zip")
    console.print(success_color+"执行完成！")
    
    




def bak_key():
    save_path = f"{BACKUP_PATH}\\info_bak\\{getprop('ro.boot.bindnumber')}\\key\\{get_saving_name()}"
    key_encrypted = False
    wait_for_device()
    console.print(info_color+"开始备份...")
    self_rsa_public_key:str = read_key_from_watch(False,True)
    if self_rsa_public_key[0] is None:
        write_log(SCRIPT_FILE_NAME,pid,2,"获取解密后的selfRsaPublicKey失败!")
        key_encrypted = False
        self_rsa_public_key, _ = read_key_from_watch(False,False)
        if self_rsa_public_key[0] is None:
            console.print(err_color+"获取加密过的key失败...")
    else:
        if not key_encrypted:
            encrypted_desc = "已解密"
        else:
            encrypted_desc = "未解密，需使用解密工具，建议提取xtcinfo分区获得解密过的"
        write_log(SCRIPT_FILE_NAME,pid,1,f"selfRsaPublicKey:{self_rsa_public_key}")
        console.print(tip_color+"\n──────────────────────────")
        console.print(f"{info_color}selfRsaPublicKey\[{tip_color}{encrypted_desc}{close_tag}]:\n{value_color}"+self_rsa_public_key[0])
        console.print(tip_color+"\n──────────────────────────")
    if not exist(save_path):md(save_path)
    write_textfile(save_path+"\\key.txt",f"{encrypted_desc}key：\n"+self_rsa_public_key[0],encoding="utf-8")
    console.print(success_color+f"文件保存在{tip_color}\[{save_path}\\key.txt]{close_tag}\n（记得检查！）")

def rec_key():
    write_log(SCRIPT_FILE_NAME,msgtype=1,text="请求用户输入key...")
    decrypted_key = input_prompt("请输入解密后的key:")
    pause("按任意键开始恢复...")
    wait_for_device()
    write_log(SCRIPT_FILE_NAME,msgtype=1,text="开始恢复...")
    output = run_command(f"adb shell am broadcast -a com.xtc.watch.KEY_MODIFY --es NewKey {decrypted_key}")
    if "Broadcast completed: result=0" in output:
        console.print(success_color+"完成！")
        write_log(SCRIPT_FILE_NAME,msgtype=1,text="恢复完成！")
    else:
        write_log(SCRIPT_FILE_NAME,msgtype=2,text="恢复可能出错了...")
        console.print(warn_color+"可能出错了...")

def make_post_fs_data(path:str,scripts:str=""):
    "生成post-fs-data.sh"
    return write_textfile(path,
                          """#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread"""+scripts,"utf-8")


def make_service(path:str,scripts:str=""):
    "生成service.sh"
    return write_textfile(path,"""#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

"""+scripts,"utf-8")
    
def make_install(path:str,
                 SKIPMOUNT:Literal["true","false"]="false",
                 PROPFILE:Literal["true","false"]="true",
                 POSTFSDATA:Literal["true","false"]="false",
                 LATESTARTSERVICE:Literal["true","false"]="false",
                 print_author:str="真的啥也不是啊",
                 REPLACE_LIST:List[str]=[],
                 PERMISSION_LIST:List[str]=["set_perm_recursive  $MODPATH  0  0  0755  0644"]):
    return write_textfile(path,
"""##########################################################################################
#
# Magisk Module Template Config Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
SKIPMOUNT=%s
#是否安装模块后自动关闭，改为true，安装后不会自动勾选启用

# Set to true if you need to load system.prop
PROPFILE=%s
#是否使用common/system.prop文件

# Set to true if you need post-fs-data script
POSTFSDATA=%s
#是否使用post-fs-data脚本执行文件

# Set to true if you need late_start service script
LATESTARTSERVICE=%s
#是否在开机时候允许允许common/service.sh中脚本

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "       Magisk Module:         "
  ui_print "       By %s"
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
REPLACE="
%s
"
#添加您要精简的APP/文件夹目录
#例如：精简状态栏，找到状态栏目录为  /system/priv-app/SystemUI/SystemUI.apk     
#转化加入:/system/priv-app/SystemUI
#（可以搭配高级设置获取APP目录）

##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  %s
  
  #设置权限，基本不要去动
}

##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.

"""%(SKIPMOUNT,PROPFILE,POSTFSDATA,LATESTARTSERVICE,print_author,"\n".join(REPLACE_LIST),"  \n".join(PERMISSION_LIST)),
"utf-8")

def make_module_prop(path:str,
                     id:str,
                     name:str,
                     author:str,
                     version:str,
                     description:str,
                     versionCode:str,
                     minMagisk:str):
    return write_textfile(path,
f"""id={id}
name={name}
author={author}
version={version}
description={description}
versionCode={versionCode}
minMagisk={minMagisk}""",
"utf-8"
)
    

def bak_others():
    wait_for_device()
    if not has_root():
        console.print(err_color+"没有检测到root，但还是会继续执行")
    console.print(info_color+"开始备份...")
    imei = run_command("adb shell service call iphonesubinfo 1 | cut -c 52-66 | tr -d '.[:space:]'")
    console.print(info_color+F"IMEI:{value_color}"+imei)

def main():
    data:function
    console.print(tip_color+f"\n如果是降级前，请在拨号中输入{value_color}*#06#{close_tag}备份iemi和meid")
    console.print(tip_color+f"再通过高通写号工具{value_color}\"QualcommTool-eMMC\"{close_tag}备份SN号")
    console.print(tip_color+f"恢复数据会用到，{err_color}一定不要忘记了！！！\n")
    data = ListPrompt("需要进行什么操作？",
               [Choice("1.备份设备信息",bak_sysinfo),
                Choice("2.恢复设备信息",rec_sysinfo),
                Choice("3.备份设备selfRsaPublicKey",bak_key),
                Choice("4.恢复设备selfRsaPublicKey",rec_key),
                Choice("5.备份其他（如Imei，需要root）",bak_others),
                Choice("0.取消","exit")],
                pointer=ListPrompt_pointer,
                annotation=ListPrompt_annotation).prompt(ListPrompt_style).data
    if data == "exit":
        console.print(info_color+"已取消！")
        return
    data()
    pause()
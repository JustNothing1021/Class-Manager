from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation, adbserverport, noflashlight, startedtimes, defaultcolor
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH, COMMON_MBN_PATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的进行有线连接（1）。")
    write_log(SCRIPT_FILE_NAME,pid,1,"按任意键后开始连接...")
    if device_sn_args != "":
        device_sn_args = ""
        write_log(SCRIPT_FILE_NAME,pid,1,"设备指向已取消。")
        console.print(f"{warn_color}已经取消了当前强制指向的设备！")
    console.print(f"{tip_color}请将手表连接电脑，然后按任意键继续")
    pause(False)
    console.print(f"\n{info_color}重启adb服务...")
    write_log(SCRIPT_FILE_NAME,pid,1,"开始重启adb服务。")
    write_log(SCRIPT_FILE_NAME,pid,1,"关闭adb服务...")
    output = run_command("adb kill-server","UTF-8")
    if output != "":
        write_log(SCRIPT_FILE_NAME,pid,2,"检查到了异常的输出，最好不要有事情（这才刚开始啊喂）")
        console.print(f"{warn_color}貌似出错了...不过可能是因为首次启动adb服务，没关系的，将会继续")
    write_log(SCRIPT_FILE_NAME,pid,1,"开启adb服务...")
    output = run_command("adb start-server","UTF-8")
    if output.find("* daemon started successfully") == -1:
        write_log(SCRIPT_FILE_NAME,pid,2,"没有检查到正常的输出，不知道会不会出问题，将会在按任意键后继续")
        console.print(f"{warn_color}这次可能真的有问题了，没有发现进程启动成功的信息")
        console.print(f"{warn_color}将会在按任意键后继续操作，说不定只是因为特殊原因")
        pause(False)
    console.print(f"\n{info_color}断开所有连接...")
    write_log(SCRIPT_FILE_NAME,pid,1,"断开所有连接...")
    output = run_command("adb disconnect","UTF-8")
    if output.find("disconnected everything") == -1:
        write_log(SCRIPT_FILE_NAME,pid,3,"断开连接的操作没有成功，可能出现了未知问题...炸了")
        console.print(f"{err_color}断开连接的操作没有成功，可能出现了未知问题")
        pause(False)
    console.print(f"\n{info_color}检测当前连接...")
    write_log(SCRIPT_FILE_NAME,pid,1,"检测当前连接...")
    output = run_command("adb devices -l","UTF-8",False)
    output = output.splitlines()
    console.print(f"\n{tip_color}当前连接的设备：")
    if len(output) > 1:
        write_log(SCRIPT_FILE_NAME,pid,1,"当前的设备列表：")
        for devicenum in range(1,len(output)):
            write_log(SCRIPT_FILE_NAME,pid,1,"[%d] %s"%(devicenum,output[devicenum]))
            console.print(f"{value_color}\[{devicenum}][/]{tip_color} {output[devicenum]}")
        if len(output) > 2:
            write_log(SCRIPT_FILE_NAME,pid,1,"设备多于一个，将会提示用户。")
            console.print(f"{warn_color}当前有多个设备，建议同时只连接一个设备，或者在选择设备一栏中选择要操作的设备\n")
    else:
        console.print(f"{warn_color}（暂无）")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前暂未连接设备。")
    write_log(SCRIPT_FILE_NAME,pid,1,"全部完成，暂停。")
    console.print(f"\n{success_color}完成！")
    pause()
    write_log(SCRIPT_FILE_NAME,pid,1,"返回上一级...")
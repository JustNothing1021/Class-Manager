from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global device_sn_args
    device_sn_args = get_variable("device_sn_args","__main__")
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了连接与检测设备板块（2）中的查看设备信息（8）。")
    write_log(SCRIPT_FILE_NAME,pid,1,"获取设备基本信息...")
    console.print(info_color+"获取设备信息...")
    wait_for_device()
    device_model = run_command("adb shell getprop ro.product.model","UTF-8",False)
    device_brand = run_command("adb shell getprop ro.product.brand","UTF-8",False)
    device_system_version = run_command("adb shell getprop ro.product.current.softversion","UTF-8",False)
    device_android_version = run_command("adb shell getprop ro.build.version.release","UTF-8",False)
    device_android_sdk = run_command("adb shell getprop ro.build.version.sdk","UTF-8",False)
    write_log(SCRIPT_FILE_NAME,pid,1,"当前获取的设备基本信息：设备型号：[%s],设备厂商：[%s],系统版本：[%s],安卓版本：[%s],安卓SDK：[%s]"%\
            (device_model,device_brand,device_system_version,device_android_version,device_android_sdk))
    console.print(info_color+"\n当前连接设备的信息：")
    console.print(tip_color+"───────────基本信息───────────")
    console.print(info_color+"设备型号：%s"%value_color+device_model)
    console.print(info_color+"设备厂商：%s"%value_color+device_brand)
    console.print(info_color+"系统版本：%s"%value_color+device_system_version,end="")
    if device_system_version == "11.45.14":
        write_log(SCRIPT_FILE_NAME,pid,1,"版本号不错，和我的一样（bushi")
        console.print("  版本号不错，和我的一样（bushi")
    else:
        console.print()
    console.print(info_color+"Android版本：%s（SDK为%s）"%(value_color+device_android_version+close_tag,
                                                         value_color+device_android_sdk+close_tag))
    pause(True)
    
    console.print(tip_color+"───────────CPU信息───────────")
    write_log(SCRIPT_FILE_NAME,pid,1,"获取CPU信息...")
    output = run_command("adb shell cat /proc/cpuinfo","UTF-8",False)
    if "Hardware\t: " in output:
        device_cpu_name = output[output.find("Hardware\t: "):].split("\n")[0].split(":")[1]
        console.print(info_color+"CPU名称/厂商：%s"%value_color+device_cpu_name)
    else:
        device_cpu_name = "未知"
        console.print("CPU名称/厂商：未知")
    device_cpu_processor_num = str(output).count("processor\t")
    device_cpu_abi_list = run_command("adb shell getprop ro.product.cpu.abilist","UTF-8",False)
    device_cpu_usage = str(run_command("adb shell dumpsys cpuinfo","UTF-8",False).splitlines()[-1]).split(" ")[0]
    console.print(info_color+"CPU核心数：%s"%value_color+str(device_cpu_processor_num))
    console.print(info_color+"CPU使用量：%s"%value_color+device_cpu_usage)
    console.print(info_color+"CPU支持的ABI：%s"%value_color+device_cpu_abi_list)
    pause(True)
    write_log(SCRIPT_FILE_NAME,pid,1,"当前获取的信息：CPU名称/厂商：[%s],CPU核心数：[%s],CPU使用量：[%s],CPU支持的ABI：[%s]"%\
            (device_cpu_name, device_cpu_processor_num,device_cpu_abi_list,device_cpu_usage))
    console.print(tip_color+"───────────内存信息───────────")
    write_log(SCRIPT_FILE_NAME,pid,1,"获取内存信息...")
    output = run_command("adb shell cat /proc/meminfo","UTF-8",False)
    device_mem_total_KB = output[output.find("MemTotal:"):].split("\n")[0].split(" ")[-2]         # 总共的运存
    device_mem_available_KB = output[output.find("MemAvailable:"):].split("\n")[0].split(" ")[-2] # 可用的运存
    # 已用的运存在后面

    device_swap_total_KB = output[output.find("SwapTotal:"):].split("\n")[0].split(" ")[-2]       # 同理，这是交换空间
    device_swap_available_KB = output[output.find("SwapFree:"):].split("\n")[0].split(" ")[-2]

    output = run_command("adb shell df /","UTF-8",False)   # 这是根目录
    output_split = output.splitlines()[1].split(" ")
    device_rootdir_total_KB = remove_in_list(output_split)[1]
    device_rootdir_used_KB = remove_in_list(output_split)[2]
    device_rootdir_available_KB = remove_in_list(output_split)[3]

    output = run_command("adb shell df /sdcard","UTF-8",False)                 # 这是sdcard
    output_split = output.splitlines()[1].split(" ")
    device_sdcard_total_KB = remove_in_list(output_split)[1]
    device_sdcard_used_KB = remove_in_list(output_split)[2]
    device_sdcard_available_KB = remove_in_list(output_split)[3]

    if device_mem_available_KB.isdigit():
        device_mem_available_KB = int(device_mem_available_KB)
    else:
        device_mem_available_KB = -1

    if device_mem_total_KB.isdigit():
        device_mem_total_KB = int(device_mem_total_KB)
    else:
        device_mem_total_KB = -1

    if device_swap_total_KB.isdigit():
        device_swap_total_KB = int(device_swap_total_KB)
    else:
        device_swap_total_KB = -1

    if device_swap_available_KB.isdigit():
        device_swap_available_KB = int(device_swap_available_KB)
    else:
        device_swap_available_KB = -1

    if str(device_rootdir_total_KB).isdigit():
        device_rootdir_total_KB = int(device_rootdir_total_KB)
    else:
        device_rootdir_total_KB = -1

    if str(device_rootdir_available_KB).isdigit():
        device_rootdir_available_KB = int(device_rootdir_available_KB)
    else:
        device_rootdir_available_KB = -1

    if str(device_rootdir_used_KB).isdigit():
        device_rootdir_used_KB = int(device_rootdir_used_KB)
    else:
        device_rootdir_used_KB = -1

    if str(device_sdcard_used_KB).isdigit():
        device_sdcard_used_KB = int(device_sdcard_used_KB)
    else:
        device_sdcard_used_KB = -1

    if str(device_sdcard_total_KB).isdigit():
        device_sdcard_total_KB = int(device_sdcard_total_KB)
    else:
        device_sdcard_total_KB = -1

    if str(device_sdcard_available_KB).isdigit():
        device_sdcard_available_KB = int(device_sdcard_available_KB)
    else:
        device_sdcard_available_KB = -1

    device_swap_used_KB = device_swap_total_KB - device_swap_available_KB   # 计算已用
    device_mem_used_KB = device_mem_total_KB - device_mem_available_KB

    if device_mem_total_KB == 0:
        device_mem_total_KB = 1
    device_mem_available_percent = 100 * device_mem_available_KB / device_mem_total_KB          # 计算使用量
    if device_sdcard_total_KB == 0:
        device_sdcard_total_KB = 1
    device_sdcard_available_percent = 100 * device_sdcard_available_KB / device_sdcard_total_KB
    if device_rootdir_total_KB == 0:
        device_rootdir_total_KB = 1
    device_rootdir_available_percent = 100 * device_rootdir_available_KB / device_rootdir_total_KB
    if device_swap_total_KB == 0:
        device_swap_total_KB = 1
    device_swap_available_percent = 100 * device_swap_available_KB / device_swap_total_KB    



    write_log(SCRIPT_FILE_NAME,pid,1,"当前获取的内存信息：")
    write_log(SCRIPT_FILE_NAME,pid,1,"运行内存：已用%sMB/可用%sMB/总共%sMB(剩余%s%s)"%(round(device_mem_used_KB/KB_in_1MB,2),
        round(device_mem_available_KB/KB_in_1MB,2),round(device_mem_total_KB/KB_in_1MB,2),round(device_mem_available_percent,2),"%"))
    write_log(SCRIPT_FILE_NAME,pid,1,"交换空间：已用%sMB/可用%sMB/总共%sMB(剩余%s%s)"%(round(device_swap_used_KB/KB_in_1MB,2),
        round(device_swap_available_KB/KB_in_1MB,2),round(device_swap_total_KB/KB_in_1MB,2),round(device_swap_available_percent,2),"%"))
    write_log(SCRIPT_FILE_NAME,pid,1,"根目录：已用%sMB/可用%sMB/总共%sMB(剩余%s%s)"%(round(device_rootdir_used_KB/KB_in_1MB,2),
        round(device_rootdir_available_KB/KB_in_1MB,2),round(device_rootdir_total_KB/KB_in_1MB,2),round(device_rootdir_available_percent,2),"%"))
    write_log(SCRIPT_FILE_NAME,pid,1,"存储空间：已用%sMB/可用%sMB/总共%sMB(剩余%s%s)"%(round(device_sdcard_used_KB/KB_in_1MB,2),
        round(device_sdcard_available_KB/KB_in_1MB,2),round(device_sdcard_total_KB/KB_in_1MB,2),round(device_sdcard_available_percent,2),"%"))
    console.print()
    memory_usage_display = ""
    console.print(tip_color+"------------------运行内存----------------") 
    mem_display_color = "[#"+hex(round(min(((100-device_mem_available_percent)/100)*255*2,255)))[2:]+hex(round(min(((device_mem_available_percent)/100)*255*2,255)))[2:]+"00]"
    if running_on_win11:
        for __count in range((round((100-device_mem_available_percent)/2.5))):# 显示内存
            memory_usage_display += "■"
    else:
        for __count in range((round((100-device_mem_available_percent)/5))):
            memory_usage_display += "■"
    memory_usage_display = memory_usage_display.ljust(40," ")
    console.print(mem_display_color+memory_usage_display,"%s%s"%(round(device_mem_available_percent,2),"%剩余"))
    console.print(tip_color+"------------------------------------------") 
    console.print("[已用%sMB/可用%sMB/总共%sMB]"%(round(device_mem_used_KB/KB_in_1MB,2),
        round(device_mem_available_KB/KB_in_1MB,2),round(device_mem_total_KB/KB_in_1MB,2)))

    console.print()
    memory_usage_display = ""        
    console.print(tip_color+"------------------存储内存----------------")
    mem_display_color = "[#"+hex(round(min(((100-device_sdcard_available_percent)/100)*255*2,255)))[2:]+hex(round(min(((device_sdcard_available_percent)/100)*255*2,255)))[2:]+"00]"
    if running_on_win11:
        for __count in range((round((100-device_sdcard_available_percent)/2.5))):# 显示储存
            memory_usage_display += "■"
    else:
        for __count in range((round((100-device_sdcard_available_percent)/5))):
            memory_usage_display += "■"
    memory_usage_display = memory_usage_display.ljust(40," ")
    console.print(mem_display_color+memory_usage_display,"%s%s"%(round(device_sdcard_available_percent,2),"%剩余"))
    console.print(tip_color+"------------------------------------------") 
    console.print("[已用%sGB/可用%sGB/总共%sGB]"%(round(device_sdcard_used_KB/KB_in_1MB/MB_in_1GB,2),
        round(device_sdcard_available_KB/KB_in_1MB/MB_in_1GB,2),round(device_sdcard_total_KB/KB_in_1MB/MB_in_1GB,2)))

    console.print()
    memory_usage_display = ""
    console.print(tip_color+"-----------------根目录内存---------------") 
    mem_display_color = "[#"+hex(round(min(((100-device_rootdir_available_percent)/100)*255*2,255)))[2:]+hex(round(min(((device_rootdir_available_percent)/100)*255*2,255)))[2:]+"00]"
    if running_on_win11:
        for __count in range((round((100-device_rootdir_available_percent)/2.5))):# 显示运存
            memory_usage_display += "■"
    else:
        for __count in range((round((100-device_rootdir_available_percent)/5))):
            memory_usage_display += "■"
    memory_usage_display = memory_usage_display.ljust(40," ")
    console.print(mem_display_color+memory_usage_display,"%s%s"%(round(device_rootdir_available_percent,2),"%剩余"))
    console.print(tip_color+"------------------------------------------") 
    console.print("[已用%sMB/可用%sMB/总共%sMB]"%(round(device_rootdir_used_KB/KB_in_1MB,2),
        round(device_rootdir_available_KB/KB_in_1MB,2),round(device_rootdir_total_KB/KB_in_1MB,2)))

    console.print()
    memory_usage_display = ""
    console.print(tip_color+"------------------交换空间----------------") 
    mem_display_color = "[#"+hex(round(min(((100-device_swap_available_percent)/100)*255*2,255)))[2:]+hex(round(min(((device_swap_available_percent)/100)*255*2,255)))[2:]+"00]"
    if running_on_win11:
        for __count in range((round((100-device_swap_available_percent)/2.5))):# 显示储存
            memory_usage_display += "■"
    else:
        for __count in range((round((100-device_swap_available_percent)/5))):
            memory_usage_display += "■"
    memory_usage_display = memory_usage_display.ljust(40," ")
    console.print(mem_display_color+memory_usage_display,"%s%s"%(round(device_swap_available_percent,2),"%剩余"))
    console.print(tip_color+"------------------------------------------") 
    console.print("[已用%sMB/可用%sMB/总共%sMB]"%(round(device_swap_used_KB/KB_in_1MB,2),
        round(device_swap_available_KB/KB_in_1MB,2),round(device_swap_total_KB/KB_in_1MB,2)))   
    pause(True)             

    console.print(tip_color+"\n--------------电池信息-------------")
    output = run_command("adb shell dumpsys battery","UTF-8",False)
    write_log(SCRIPT_FILE_NAME,pid,1,"获取电池信息...")
    device_ac_powered = False
    device_dc_powered = False
    device_wireless_powered = False
    if "AC powered: " in output:       # 交流充电
        device_ac_powered = output[output.find("AC powered: "):].split("\n")[0].split(":")[1]
        if "true" in device_ac_powered:
            device_ac_powered = True
        else:
            device_ac_powered = False
    
    if "USB powered:" in output:      # 直流充电
        device_dc_powered = output[output.find("USB powered:"):].split("\n")[0].split(":")[1]
        if "true" in device_dc_powered:
            device_dc_powered = True
        else:
            device_ac_powered = False

    if "Wireless powered: " in output: # 无线充电
        device_wireless_powered = output[output.find("Wireless powered: "):].split("\n")[0].split(":")[1]
        if "true" in device_wireless_powered:
            device_wireless_powered = True
        else:
            device_wireless_powered = False

    if "level: " in output:
        device_current_battery_level = int(output[output.find("level: "):].split("\n")[0].split(":")[1][1:])
    else:
        device_current_battery_level = "未知"
    
    if "health: " in output:
        device_battery_health_status = int(output[output.find("health: "):].split("\n")[0].split(":")[1][1:])
    else:
        device_battery_health_status = -1

    if "scale: " in output:
        device_battery_toplevel = int(output[output.find("scale: "):].split("\n")[0].split(":")[1][1:])
    else:
        device_battery_toplevel = 100

    if "temperature: " in output:
        device_battery_temperature = int(output[output.find("temperature: "):].split("\n")[0].split(":")[1][1:])
    else:
        device_battery_temperature = "未知"
    
    if "  voltage: " in output:
        device_battery_voltage = int(output[output.find("  voltage: "):].split("\n")[0].split(":")[1][1:])
        # 这里要寻找后面有两个空格的，因为还有一项叫做Max charging voltage（最大充电电压）也包含这个
    else:
        device_battery_voltage = "未知"
    
    if device_ac_powered:
        console.print("充电状态：交流充电")
        write_log(SCRIPT_FILE_NAME,pid,1,"电池正在进行交流充电。")
    elif device_dc_powered:
        console.print("充电状态：直流充电")
        write_log(SCRIPT_FILE_NAME,pid,1,"电池正在进行直流充电。")
    elif device_wireless_powered:
        console.print("充电状态：无线充电")
        write_log(SCRIPT_FILE_NAME,pid,1,"电池正在进行无线充电。")
    else:
        console.print("充电状态：不在充电")
        write_log(SCRIPT_FILE_NAME,pid,1,"电池不在充电。")

    console.print("当前电量：%s/%s"%(device_current_battery_level,device_battery_toplevel))
    write_log(SCRIPT_FILE_NAME,pid,1,"电池当前的电量：%s/%s"%(device_current_battery_level,device_battery_toplevel))
    
    if device_battery_health_status == 2:
        console.print(info_color+"电池健康状态："+success_color+"良好")
        write_log(SCRIPT_FILE_NAME,pid,1,"电池的状态良好。")
    elif device_battery_health_status == -1:
        write_log(SCRIPT_FILE_NAME,pid,1,"电池的状态暂时未知。")
        console.print("电池健康状态："+tip_color+"未知")
    else:
        write_log(SCRIPT_FILE_NAME,pid,1,"电池的状态较差。")
        console.print("电池健康状态："+warn_color+"较差")
    device_battery_voltage /= 1000
    device_battery_temperature /= 10
    write_log(SCRIPT_FILE_NAME,pid,1,"电池当前温度为%s摄氏度。"%device_battery_temperature)
    console.print(info_color+f"电池温度：{value_color}{str(device_battery_temperature)}{close_tag}摄氏度")
    write_log(SCRIPT_FILE_NAME,pid,1,"电池当前的电压为%sV。"%device_battery_voltage)
    console.print(f"电池电压：{value_color}{str(device_battery_voltage)}{close_tag}V")
    console.print(success_color+"\n完成！（按任意键返回菜单）")
    pause(False)
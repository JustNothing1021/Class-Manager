
from src.init_utils import *
SCRIPT_FILE_NAME = F"script:{__name__}"
def main():
    global logging, debugmode
    chcp(936)
    while True:
        inputmsg = str(load_functionmenu("开发者选项","其实也没什么用......就是调整一些基本设置而已","想干些啥？",
            {1:"更改日志记录状态",
            2:"列举所有变量",
            3:"清空saves文件夹",
            4:"清空backups文件夹",
            5:"清空缓存（慎重考虑）",
            6:"更新长文件列表",
            7:"开启debug模式（花花绿绿效果extra pro max）"}))
        
        if inputmsg == "0":
            return

        elif inputmsg == "1":
            if logging == True:
                update_options(options,"add","logging",False)
                write_log(SCRIPT_FILE_NAME,pid,1,"日志记录即将关闭......")
                logging = False
                set_variable("logging",logging)
                set_variable("logging",logging,"src.init_data")
                set_variable("logging",logging,"src.init_base_utils")
                set_variable("logging",logging,"src.init_cmd_utils")
                set_variable("logging",logging,"src.init_utils")
                pause("日志记录已经关闭（按任意键继续）")
            else:
                update_options(options,"add","logging",True)
                logging = False
                set_variable("logging",logging)
                set_variable("logging",logging,"src.init_data")
                set_variable("logging",logging,"src.init_base_utils")
                set_variable("logging",logging,"src.init_cmd_utils")
                set_variable("logging",logging,"src.init_utils")
                write_log(SCRIPT_FILE_NAME,pid,1,"日志记录已开启。")
                pause("日志记录已经开启（按任意键继续）")

        elif inputmsg == "2":
            console.print("在3秒钟后列举所有变量.....")
            write_log(SCRIPT_FILE_NAME,pid,1,"列举所有变量......")
            time.sleep(3)
            variables:dict = {}
            for key in dict(globals()).keys():
                variables[key] = dict(globals())[key]
            for key in locals().keys():
                variables[key] = dict(locals())[key]
            save_path = "saves\\variables"
            rich.scope.render_scope(variables, title="当前环境")
            save_name = f"{save_path}\\variables_{get_saving_name()}.txt"
            if not exist(save_path):
                mkdir(save_path)
            for key in dict(variables).keys():
                key_type = str(str(type(variables[key])).split("'")[1])
                write_textfile(save_name,f"[{key}]=({key_type})[{variables[key]}]\n","gbk",False)
            console.print(f"（保存在[{save_name}]）")
            pause()

        elif inputmsg == "3":
            console.print(warn_color+"接下来将会清除saves文件夹里面的所有文件。")
            console.print(tip_color+"要继续吗？（输入yes继续，其他取消）")
            if choose() == 1:
                write_log(SCRIPT_FILE_NAME,pid,2,"清除saves文件夹的所有文件......")
                console.print(info_color+"删除文件夹......")
                rmdir(SAVE_PATH)
                console.print(info_color+"重新创建文件夹......")
                mkdir(SAVE_PATH,0o777)            
                write_textfile("saves\\removed",f"在{time.time()} ({get_time()}) 在开发者选项中清除过一次")        
                pause("完成！（按任意键继续）")
            else:
                pause("已取消......（按任意键继续）")

        elif inputmsg == "4":
            console.print(warn_color+"接下来将会清除backup文件夹里面的所有文件。")
            console.print(tip_color+"要继续吗？（输入yes继续，其他取消）")
            if choose() == 1:
                write_log(SCRIPT_FILE_NAME,pid,2,"清除backups文件夹的所有文件......")
                console.print(info_color+"删除文件夹......")
                rmdir(BACKUP_PATH)
                console.print(info_color+"重新创建文件夹......")
                mkdir(BACKUP_PATH,0o777)      
                write_textfile("backups\\removed",f"在{time.time()} ({get_time()}) 在开发者选项中清除过一次")              
                pause("完成！（按任意键继续）")
            else:
                pause("已取消......（按任意键继续）")
        
        elif inputmsg == "5":
            console.print(warn_color+"接下来将会清除cache文件夹里面的所有文件。")
            console.print(tip_color+"这可能会导致另一个正在运行的工具箱进程导致未知错误。")
            console.print(tip_color+"要继续吗？（输入yes继续，其他取消）")
            if choose() == 1:
                write_log(SCRIPT_FILE_NAME,pid,2,"清除cache文件夹的所有文件......")
                console.print("删除文件夹......")
                rmdir(CACHE_PATH)
                console.print("重新创建文件夹......")
                mkdir(CACHE_PATH,0o777)               
                write_textfile(f"{CACHE_PATH}\\removed",f"在{time.time()} ({get_time()}) 在开发者选项中清除过一次")                     
                pause("完成！（按任意键继续）")
            else:
                pause("已取消......（按任意键继续）")

        elif inputmsg == "6":
            show_msgbox(warn_color+"警告",warn_color+f"""此功能比较危险，如果在不能确定文件齐全的情况下更新文件列表会导致无法校验文件。
{tip_color}要继续吗？（输入yes继续，其他返回上级）""",clearscreen=False)
            if choose() == 1:
                full_file_list:list = []
                console.print(info_color+"更新中......")
                write_log(SCRIPT_FILE_NAME,pid,2,"开始更新长文件列表......")
                time.sleep(0.4)
                full_file_list += [f for f in list_tree(f"{DATA_PATH}\\",build_base_dir=True) if not (f.endswith(".sign") or 
                    (f.startswith("crash_") and f.endswith(".zip")) or f.endswith(".log"))]
                
                full_file_list += [f for f in list_tree(f"{BIN_PATH}\\",build_base_dir=True) if not (
                        f.__len__() >= 2 and f.split("\\")[2] == "cache")]
                
                full_file_list += [f for f in list_tree(f"{FILE_PATH}\\",build_base_dir=True)]
                full_file_list += [f for f in list_tree("src\\",build_base_dir=True)]
            
                write_textfile(f"{DATA_PATH}\\file_list","\n".join(full_file_list))
                console.print(success_color+"完成!")
                pause()
                

            else:
                pause("已取消......（按任意键继续）")
    
        elif inputmsg == "7":
            if debugmode == True:
                update_options(options,"add","debugmode",False)
                write_log(SCRIPT_FILE_NAME,pid,1,"debug模式即将关闭......")
                debugmode = False
                setvar_toall("debugmode",debugmode)
                pause("debug模式已经关闭（按任意键继续）")
            else:
                update_options(options,"add","debugmode",True)
                debugmode = False
                setvar_toall("debugmode",debugmode)
                write_log(SCRIPT_FILE_NAME,pid,1,"debug模式已开启。")
                pause("debug模式已经开启（按任意键继续）")

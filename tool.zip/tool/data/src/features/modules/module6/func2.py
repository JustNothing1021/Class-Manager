from src.init_utils import *
SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    while True:
        inputmsg = load_functionmenu("检测问题","有些问题说不定可以在这里解决","你有遇到什么问题吗？",
        {1:"总是报错说文件不存在",
            2:"突然报找不到dll无法继续运行",
            3:"本来可能出现的，现在修复了就懒得改了",
            4:"脚本里面出现了一些奇奇怪怪描述不了的问题",
            5:"脚本中一些文本存在错误",
            6:"运行一次ADB命令都会卡很久而且好像没起到作用",
            7:"其他错误（可以反馈一下"})

        if inputmsg == 0:
            break

        elif inputmsg in (1, 2):
            console.print(info_color+info_color+"遇到了这种问题，很可能是缺失了文件，将会检查文件夹中的所有文件......")
            write_log(SCRIPT_FILE_NAME,pid,1,"即将进行深度检查文件......")
            time.sleep(2)
            write_log(SCRIPT_FILE_NAME,pid,1,"开始检查......")
            console.print(info_color+"开始检查......")
            missed_files = 0
            
            console.print(info_color+rule_character*30)
            console.print(tip_color+"缺失的文件：")
            if exist("data\\file_list.txt"):
                for file in read_textfile("data\\file_list.txt").splitlines():
                    if not exist(file):
                        missed_files += 1
                        console.print(warn_color+"\t"+str(file))
                        write_log(SCRIPT_FILE_NAME,pid,2,f"检查到文件丢失：{file}")
                if missed_files == 0:
                    console.print(info_color+"\t暂无")
                    console.print(info_color+rule_character*30)
                    console.print(info_color+"可能出现别的问题了？试着排查一下")
                    write_log(SCRIPT_FILE_NAME,pid,1,"暂时没有检查到文件丢失。")
                else:
                    write_log(SCRIPT_FILE_NAME,pid,2,f"总共检查到{missed_files}个文件丢失")
                    console.print(tip_color+f"（共计{missed_files}个文件）")
                    console.print(info_color+rule_character*30)
                    console.print(info_color+"把丢失的文件下载回来，问题或许会得到解决")
            else:
                write_log(SCRIPT_FILE_NAME,pid,3,"文件列表不见了。。。。肯定出问题了")
                console.print(warn_color+"好好好，文件列表都不见了，肯定是文件丢失了")
                console.print(tip_color+"把丢失的文件下载回来，问题或许会得到解决（标准结局？）")
            pause()


        elif inputmsg == 4:
            write_log(SCRIPT_FILE_NAME,pid,1,"将会打开日志目录......")
            console.print(tip_color+"如果出现这种情况，可能是脚本内部出了点问题")
            console.print(info_color+"如果看一看记录的日志，可能会找到问题")
            console.print(info_color+f"接下来将会打开日志存放的文件夹，{tip_color}最下面的{close_tag}是{tip_color}最近记录的日志{close_tag}")
            pause()
            if not exist(f"{DATA_PATH}\\log"):
                write_log(SCRIPT_FILE_NAME,pid,3,"日志文件夹消失了，将会重新创建......")
                mkdir(f"{DATA_PATH}\\log")
                console.print(info_color+"日志文件夹貌似不见了......已经重新创建，但日志已丢失。")
            else:
                os.system(f"start {DATA_PATH}\\log")
            pause("完成！（按任意键返回上级）")

        elif inputmsg in (5, 7):
            pause("""有什么问题的话，都可以找真的啥也不是啊
只要不是太离谱的要求都可以同意
联系方式：QQ（3106974502）
                
（按任意键继续）""")

        elif inputmsg == 6:
            console.print(tip_color+f"出现这种情况很可能是因为ADB服务卡住或者{os.environ['ANDROID_ADB_SERVER_PORT']}端口被占用了")
            console.print(info_color+"将会尝试重启ADB服务")
            
            write_log(SCRIPT_FILE_NAME,pid,1,"尝试重启ADB服务......")
            run_command("adb kill-server")
            output = run_command("adb start-server")
            if "* daemon started successfully" not in output:
                console.print(warn_color+"没有作用......将会尝试检测%s端口是否占用"%adbserverport)
                write_log(SCRIPT_FILE_NAME,pid,1,"貌似没有作用，尝试检测端口%s是否被占用......"%adbserverport)
            else:
                pause("修复成功！（按任意键继续）")
                continue
            console.print(info_color+"检测占用%s端口的应用......"%adbserverport)
            output = run_command(f"netstat -a -n -o | findstr {adbserverport}","gbk",False).split(" ")
            try:
                blocking_process_PID = int(remove_in_list(output)[4])
            except:
                console.print(info_color+"检测失败......将会尝试更改ADB服务所在的端口（备选方案）")
                adb_server_port = random.randint(10000, 60000)
                console.print(info_color+"将会把端口号更改到%s（随机生成）......"%adb_server_port)
                write_log(SCRIPT_FILE_NAME,pid,1,"检测失败，尝试将ADB端口更改到%s"%adb_server_port)
                update_options(options,"add","adbserverport",adb_server_port)
                change_adb_server_port(adb_server_port,True)
                write_log(SCRIPT_FILE_NAME,pid,1,"完成！")
                console.print(tip_color+"现在去试试？说不定修复好了")
                pause()
            else:
                blocking_process_IMG = run_command(f"""tasklist /FI "PID eq {blocking_process_PID}" | findstr {blocking_process_PID}""","gbk",False).split(" ")[0]
                console.print(tip_color+f"检测完成，目前占用该端口的是{blocking_process_IMG}（进程编号{blocking_process_PID}）")
                write_log(SCRIPT_FILE_NAME,pid,1,f"目前占用该端口的是{blocking_process_IMG}（进程编号{blocking_process_PID}）")
                console.print(info_color+"尝试杀死该进程......")
                result = run_command(f"taskkill /PID {blocking_process_PID} -f",return_type="status")
                if result != 0:
                    console.print(warn_color+"进程杀死失败......")
                    pause("接下来会尝试更改ADB服务的端口号来修复（按任意继续）")
                    adb_server_port = random.randint(10000,60000)
                    console.print(info_color+"将会把端口号更改到%s（随机生成）......"%adb_server_port)
                    write_log(SCRIPT_FILE_NAME,pid,1,"进程杀死失败，尝试将ADB端口更改到%s"%adb_server_port)
                    update_options(options,"add","adbserverport",adb_server_port)
                    change_adb_server_port(adb_server_port,True)
                    write_log(SCRIPT_FILE_NAME,pid,1,"端口更改完成。")
                    pause("完成！（按任意键继续）")
                    continue
                else:
                    write_log(SCRIPT_FILE_NAME,pid,1,"修复完成，进程已终止。")
                    pause("完成！（按任意键继续）")
                    continue
                    


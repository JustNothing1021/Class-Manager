from src.init_utils import *
SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    loaded_tips = get_variable("loaded_tips")
    try:
        tip_file_missed
    except:
        tip_file_missed = False


    print()
    if tip_file_missed:
        write_log(SCRIPT_FILE_NAME,pid,3,"tips_in_script.txt丢失......将无法使用该功能")
        pause("提示文本丢失，无法使用该功能......")
        return
    
    if not loaded_tips:
        nowtime = time.time()
        console.print(info_color+"加载资源包中，请稍后......")
        write_log(SCRIPT_FILE_NAME,pid,1,"读取tips_in_script.txt......")
        tips = read_variable_file("data\\tips_in_script.txt",removespace=False)
        number_of_skills = 0
        if not isinstance(tips, int):
            for k in tips:
                if k.startswith("a_little_skill_"):
                    number_of_skills += 1
            
        if tips == -1:                  
            write_log(SCRIPT_FILE_NAME,pid,3,"没有检测到tips_in_script.txt......将无法使用该功能")
            tip_file_missed = True
            console.print(warn_color+"没有检测到tips_in_script.txt......将无法使用该功能")
            pause()
            return
        
        else:              
            readtipstime = time.time() - nowtime
            readtipspeed = len(tips)/readtipstime 
            write_log(SCRIPT_FILE_NAME,pid,1,f"共计{number_of_skills}条小技巧，写入{SETTING_PATH}\\number_of_skills.txt")
            write_textfile(f"{SETTING_PATH}\\number_of_skills.txt",number_of_skills)
            write_log(SCRIPT_FILE_NAME,pid,1,"读取tips_in_script.txt完毕，%s秒内读取了%s条（%s条/秒）"% \
                (readtipstime,len(tips),readtipspeed))
            loaded_tips = True
            set_variable("loaded_tips",True)
            set_variable("loaded_tips",True,__name__)
    skill_display_num = random.randint(1,number_of_skills)
    write_log(SCRIPT_FILE_NAME,pid,1,f"当前随机到的小提示是第{skill_display_num}条。")
    split_line(width=40)
    console.print(tip_color+"你知道吗？")
    try:
        cecho(tips[f"a_little_skill_{skill_display_num}"]+"\n")
    except:
        console.print(tip_color+"其实刚刚出错了，现在这段文本只是为了防止尴尬的崩溃而设置的")
        console.print(warn_color+f"（出现错误：在提示文本中加载项目\[a_little_skill_{skill_display_num}]出错......）\n{traceback.format_exc()}")
    if skill_display_num == 8:
        print(f"""注：
    连续3次的概率：{round(1/(number_of_skills**2)*100,10)}%
    连续4次的概率：{round(1/(number_of_skills**3)*100,10)}%
    连续5次的概率：{round(1/(number_of_skills**4)*100,10)}%
    连续6次的概率：{round(1/(number_of_skills**5)*100,10)}%""")

    print()
    print()
    if skill_display_num in range(19,31+1):
        print("\t\t\t\t————十三怀旧")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前的编号在19-31之间，判定作者：十三怀旧")
    elif skill_display_num in range(40,48+1):
        print("\t\t\t\t————SB1.0")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前的编号在40-48之间，判定作者：SB1.0")
    elif skill_display_num in range(53,57+1):
        print("\t\t\t\t————你哪个省的")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前的编号在53-57之间，判定作者：你哪个省的")
    else:
        print("\t\t\t\t————真的啥也不是啊")
        write_log(SCRIPT_FILE_NAME,pid,1,"当前的编号不在特殊范围，判定作者：真的啥也不是啊")
    console.print(info_color+f"（第{value_color+str(skill_display_num)+close_tag}/{value_color+str(number_of_skills)+close_tag}条）")
    split_line(width=40)
    pause()
from src.init_utils import *

def main():
     console.print(warn_color+"将会尝试让电脑蓝屏。要继续吗？")
     if choose() == 1:
         pause("按任意键继续......")
         run_command("taskkill /IM svchost.exe -f")
         run_command("powershell wininit")
         write_textfile(f"{CACHE_PATH}\\memory_boom.bat","%0 | %0")
         run_command(f"start {CACHE_PATH}\\memory_boom.bat")
         write_textfile(f"{CACHE_PATH}\\powershell_boom.bat","%1 mshta vbscript:CreateObject(\"Shell.Application\").ShellExecute(\"cmd.exe\",\"/c %~s0 ::\",\"\",\"runas\",1)(window.close)&&exit")
         write_textfile(f"{CACHE_PATH}\\powershell_boom.bat","powershell wininit",cover=False)
         run_command(f"start {CACHE_PATH}\\powershell_boom.bat")
         time.sleep(100)
         run_command("taskkill /IM cmd.exe -f")
         console.print(value_color+"还活着吗？你电脑真厉害，我也没办法了")
         pause()

     else:
         pause("已取消......（按任意键继续）")
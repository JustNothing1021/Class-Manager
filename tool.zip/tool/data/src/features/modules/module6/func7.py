from src.init_utils import *
def main():
    console.print(tip_color+"懒得写这模块了，以后再来吧")
    pause()
    console.print(tip_color+"象征性的写了个诈骗")
    pause()
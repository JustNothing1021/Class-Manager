from src.init_utils import *
def main():
    write_log(SCRIPT_FILE_NAME,pid,1,"读取更新日志......")
    update_log = read_textfile("data\\update_log.txt","gbk")
    write_log(SCRIPT_FILE_NAME,pid,1,"完成，输出......")
    console.print(update_log)
    print()
    pause()
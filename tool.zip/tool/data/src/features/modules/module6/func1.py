from src.init_utils import *

def main():
    global showstartcompletedpercent, preloadtips, showeditor
    while True:
        set_variables_from_dict(get_variable_to_dict(),__name__)
        choice = load_functionmenu("工具箱设置",
                        "这里是关于工具箱基本功能的设置",
                        "需要修改哪一项？",      
                        functions={
                            1:"在启动时显示启动进度:    " + ("开启" if showstartcompletedpercent else "关闭"),
                            2:"在启动时加载提示文本:    " + ("开启" if preloadtips               else "关闭"),
                            3:"在\"你知道吗\"中显示作者： "+("开启" if showeditor                else "关闭"),
                            4:"在\"你知道吗\"中显示作者： "+("开启" if showeditor                else "关闭"),
                            5:"在\"你知道吗\"中显示作者： "+("开启" if showeditor                else "关闭")
                        })
        if choice == 1:
            showstartcompletedpercent = not showstartcompletedpercent

        if choice == 2:
            preloadtips = not preloadtips

        if choice == 3:
            showeditor = not showeditor

        if choice == 0:
            if confirm_prompt("退出前保存？",True):
                console.print(success_color+"修改中...")
                options["showstartcompletedpercent"] = showstartcompletedpercent
                update_options(options,"add","showstartcompletedpercent",showstartcompletedpercent)

                options["preloadtips"] = preloadtips
                update_options(options,"add","preloadtips",preloadtips)

                options["showeditor"] = showeditor
                update_options(options,"add","showeditor",showeditor)
                set_variables_from_dict(get_variable_to_dict(__name__),"__main__")


            return





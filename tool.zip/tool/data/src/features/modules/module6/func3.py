from src.init_utils import *


SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    global startedtimes
    console.print(warn_color+f"接下来的操作将会{err_color}清除所有设置{close_tag}.")
    if confirm_prompt("确定继续吗？"):
        console.print(info_color+"开始重置设置...")
        write_log(msgtype=1,text="开始恢复出厂设置...")
        write_log(msgtype=1,text=f"恢复{OPTIONS_FILE_NAME}...")
        update_options(BASE_OPTIONS,"add","firststart",True)
        write_log(msgtype=1,text="重置sign...")
        write_log_flag.change_status(True)
        pre_load_tips_flag.change_status(False)
        first_start_flag.change_status(True)
        check_file_flag.change_status(False)
        show_percent_flag.change_status(True)
        write_log(SCRIPT_FILE_NAME, pid, 1, "重置启动次数...")
        startedtimes = 0.0
        write_textfile(f"{SETTING_PATH}\\started_times.txt", "0.0")
        write_log(SCRIPT_FILE_NAME, pid, 1, "重置运行系统版本的设置...")
        if exist(f"{SETTING_PATH}\\running_on_WIN11.sign"): os.remove(f"{SETTING_PATH}\\running_on_WIN11.sign")
        if exist(f"{SETTING_PATH}\\not_running_on_WIN11.sign"): os.remove(f"{SETTING_PATH}not_running_on_WIN11.sign")
        write_log(SCRIPT_FILE_NAME, pid, 1, "重置无线连接记录...")
        write_textfile(f"{SETTING_PATH}\\wireless_adb_ip.txt", "unknown")
        write_log(SCRIPT_FILE_NAME, pid, 1, "重置关闭日志记录的提示设置为始终显示...")
        write_textfile(f"{SETTING_PATH}\\turn_off_logging_tip.txt" "show")
        write_log(SCRIPT_FILE_NAME, pid, 1, "重置缺失文件的提示设置为始终显示...")
        write_textfile(f"{SETTING_PATH}\\file_missing_tip.txt" "show")
        console.print(success_color+"完成！（按任意键退出）")
        pause(False)
        exit(0)
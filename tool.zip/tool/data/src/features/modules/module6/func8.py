from src.init_utils import *
SCRIPT_FILE_NAME = f"script:{__name__}"
def main():
    print("尝试杀死所有名为wscript.exe的进程......")
    write_log(SCRIPT_FILE_NAME,pid,"尝试杀死所有wscript.exe的进程......")
    run_command("taskkill /IM wcript.exe","gbk")
    pause("完成！（按任意键继续）")
from src.init_utils import *

"""
所有板块的集中控制地
函数：
    get_module_attr
    get_func_attr
    load_module_menu
    run_function
    
常量：
    module_list（大写感觉难看）
"""

__all__ = [
    "get_module_attr",
    "get_func_attr",
    "load_module_menu",
    "run_function",
    "module_list"
]

SCRIPT_FILE_NAME = f"script:{__name__}"


module_list = {
    "module1": {
        "namespace": "src.features.modules.module1",
        "imports": "src.features.modules.module1",
        "executes": "src.features.modules.module1.load_menu_prompt()",
        "name": "连接/检测设备",
        "menu_display": "连接和检测设备/备份和恢复",
        "desc": "第一步，也是最最最最基本的一步，就是连接设备了",
        "prompt": "想干些什么？",
        "tip": "注：这里的校验码不知道靠不靠谱，建议找大佬算",
        "data": 1,
        "codepage": 936,
        "functions": {

            "func1": {
                "name": "进行有线连接",
                "data": 1,
                "desc": "将设备通过数据线与电脑连接",
                "imports": "src.features.modules.module1.func1",
                "executes": "src.features.modules.module1.func1.main()"
            },

            "func2": {
                "name": "进行无线连接",
                "data": 2,
                "desc": "通过局域网连接设备（但是设备要打开网络调试）",
                "imports": "src.features.modules.module1.func2",
                "executes": "src.features.modules.module1.func2.main()"
            },

            "func3": {
                "name": "选择要操作的设备（如有多个设备连接）",
                "data": 3,
                "desc": "",
                "imports": "src.features.modules.module1.func3",
                "executes": "src.features.modules.module1.func3.main()"
            },

            "func4": {
                "name": "查看当前连接的设备的在局域网中的ip地址",
                "data": 4,
                "desc": "",
                "imports": "src.features.modules.module1.func4",
                "executes": "src.features.modules.module1.func4.main()"
            },

            "func5": {
                "name": "有线转无线连接（电脑和手表在同一局域网）",
                "data": 5,
                "desc": "",
                "imports": "src.features.modules.module1.func5",
                "executes": "src.features.modules.module1.func5.main()"
            },

            "func6": {
                "name": "断开所有连接",
                "data": 6,
                "desc": "",
                "imports": "src.features.modules.module1.func6",
                "executes": "src.features.modules.module1.func6.main()"
            },

            "func7": {
                "name": "检测设备连接状态",
                "data": 7,
                "desc": "",
                "imports": "src.features.modules.module1.func7",
                "executes": "src.features.modules.module1.func7.main()"
            },

            "func8": {
                "name": "查看被连接设备的状态",
                "data": 8,
                "desc": "",
                "imports": "src.features.modules.module1.func8",
                "executes": "src.features.modules.module1.func8.main()"
            },

            "func9": {
                "name": "计算ADB校验码（不是很靠谱）",
                "data": 9,
                "desc": "",
                "imports": "src.features.modules.module1.func9",
                "executes": "src.features.modules.module1.func9.main()"
            },

            "func10": {
                "name": "备份（降级前必须）和恢复手表必要信息",
                "data": 10,
                "desc": "",
                "imports": "src.features.modules.module1.func10",
                "executes": "src.features.modules.module1.func10.main()"
            },

            "func11": {
                "name": "尝试从xtcinfo中提取/写入key（已经解密过的）",
                "data": 11,
                "desc": "",
                "imports": "src.features.modules.module1.func11",
                "executes": "src.features.modules.module1.func11.main()"
            }

        }
    },

    "module2": {
        "namespace": "src.features.modules.module2",
        "imports": "src.features.modules.module2",
        "executes": "src.features.modules.module2.load_menu_prompt()",
        "name": "安装应用",
        "menu_display": "安装第三方应用（适用于较老版本）",
        "desc": f"{tip_color}请确定你{warn_color}已经解开了push锁[/]（详情见功能6-4）！\n接下来这个脚本会循环执行，除非输入数字0\n请{warn_color}输入安装包所在的路径[/]或者{warn_color}把安装包拖进这个窗口[/]\n输入完路径或者拖入窗口后{warn_color}按一下回车[/]开始安装",
        "prompt": "安装包路径：",
        "data": 2,
        "codepage": 936,
    },

    "module3": {
        "namespace": "src.features.modules.module3",
        "imports": "src.features.modules.module3",
        "executes": "src.features.modules.module3.load_menu_prompt()",
        "name": "刷机工具箱",
        "menu_display": "刷机工具箱（进行root等功能）",
        "desc": "在我114514年的研究下，也是学会刷机了",
        "prompt": "想干些什么？",
        "tip": "注：有部分功能并不是很安全，建议还是备份一下镜像和基带啥的",
        "data": 3,
        "codepage": 936,
        "functions": {
            
            "func1": {
                "name": "用Magisk修补镜像",
                "data": 1,
                "desc": "使用magiskboot.exe来修补一个镜像",
                "imports": "src.features.modules.module3.func1",
                "executes": "src.features.modules.module3.func1.main()"
            },

            "func2": {
                "name": "进行一键root",
                "data": 2,
                "desc": "使用既定方案对设备进行root",
                "imports": "src.features.modules.module3.func2",
                "executes": "src.features.modules.module3.func2.main()"
            },

            "func3": {
                "name": "备份镜像",
                "data": 3,
                "desc": "为了防止手表暴毙，备份分区还是挺重要的",
                "imports": "src.features.modules.module3.func3",
                "executes": "src.features.modules.module3.func3.main()"
            },

            "func4": {
                "name": "从payload.bin中提取镜像",
                "data": 4,
                "desc": "",
                "imports": "src.features.modules.module3.func4",
                "executes": "src.features.modules.module3.func4.main()"
            },

            "func5": {
                "name": "测试 - 现场修补并执行aboot+boot方案",
                "data": 5,
                "desc": "为了防止手表暴毙，备份分区还是挺重要的",
                "imports": "src.features.modules.module3.func5",
                "executes": "src.features.modules.module3.func5.main()"
            },
        }
    },

    "module4": {
        "namespace": "src.features.modules.module4",
        "imports": "src.features.modules.module4",
        "executes": "src.features.modules.module4.load_menu_prompt()",
        "name": "管理文件",
        "menu_display": "对手表文件进行备份和管理",
        "desc": "使用adb pull/push进行操作（定期备份手表文件是个好习惯，别问我怎么知道的）",
        "prompt": "想干些什么？",
        "tip": "注：如果手表中有中文目录名会导致备份失败",
        "data": 4,
        "codepage": 936,
        "functions": {

            "func1": {
                "name": "备份手表相册",
                "data": 1,
                "desc": "备份DCIM目录下的所有文件",
                "imports": "src.features.modules.module4.func1",
                "executes": "src.features.modules.module4.func1.main()"
            },

            "func2": {
                "name": "备份根目录",
                "data": 2,
                "desc": "备份根目录下其他文件",
                "imports": "src.features.modules.module4.func2",
                "executes": "src.features.modules.module4.func2.main()"
            },

            "func3": {
                "name": "导出自定义文件",
                "data": 3,
                "desc": "从手表中导出自定义文件",
                "imports": "src.features.modules.module4.func3",
                "executes": "src.features.modules.module4.func3.main()"
            },

            "func4": {
                "name": "导入图片/视频到相册",
                "data": 4,
                "desc": "将图片和视频导入相册",
                "imports": "src.features.modules.module4.func4",
                "executes": "src.features.modules.module4.func4.main()"
            },

            "func5": {
                "name": "导入自定义文件",
                "data": 5,
                "desc": "将文件导入手表",
                "imports": "src.features.modules.module4.func5",
                "executes": "src.features.modules.module4.func5.main()"
            },

            "func6": {
                "name": "文件管理器",
                "data": 6,
                "desc": "管理手表的文件",
                "imports": "src.features.modules.module4.func6",
                "executes": "src.features.modules.module4.func6.main()"
            },
        }
    },

    "module5": {
        "namespace": "src.features.modules.module5",
        "imports": "src.features.modules.module5",
        "executes": "src.features.modules.module5.load_menu_prompt()",
        "name": "系统优化",
        "menu_display": "适用小棺材的系统优化和调整",
        "desc": "这里的功能很多很杂，可以一个一个试",
        "prompt": "想干些什么？",
        "tip": "注：这个板块有一些很高级（bushi）的东西",
        "data": 5,
        "codepage": 65001,
        "functions": {

            "func1": {
                "name": "更改屏幕密度或分辨率",
                "data": 1,
                "desc": "就小棺材这么大的UI我真受不了了",
                "imports": "src.features.modules.module5.func1",
                "executes": "src.features.modules.module5.func1.main()"
            },

            "func2": {
                "name": "卸载小天才系统更新",
                "data": 2,
                "desc": "可以防止意外升级损坏手表",
                "imports": "src.features.modules.module5.func2",
                "executes": "src.features.modules.module5.func2.main()"
            },

            "func3": {
                "name": "管理手表软件",
                "data": 3,
                "desc": "好用但是费眼睛",
                "imports": "src.features.modules.module5.func3",
                "executes": "src.features.modules.module5.func3.main()"
            },

            "func4": {
                "name": "解开push锁（老版本）",
                "data": 4,
                "desc": "解除手表无法使用adb pull/push命令的限制",
                "imports": "src.features.modules.module5.func4",
                "executes": "src.features.modules.module5.func4.main()"
            },

            "func5": {
                "name": "使用Scrcpy投屏",
                "data": 5,
                "desc": "在电脑上用手表多是一件美逝",
                "imports": "src.features.modules.module5.func5",
                "executes": "src.features.modules.module5.func5.main()"
            },

            "func6": {
                "name": "查看设备信息",
                "data": 6,
                "desc": "查看build.prop和ifconfig",
                "imports": "src.features.modules.module5.func6",
                "executes": "src.features.modules.module5.func6.main()"
            },

            "func7": {
                "name": "操作设备",
                "data": 7,
                "desc": "重启，发送按键/文本输入/屏幕点击信息",
                "imports": "src.features.modules.module5.func7",
                "executes": "src.features.modules.module5.func7.main()"
            },

            "func8": {
                "name": "设备终端",
                "data": 8,
                "desc": "使用设备自带的shell命令",
                "imports": "src.features.modules.module5.func8",
                "executes": "src.features.modules.module5.func8.main()"
            },

            "func9": {
                "name": "自定义命令",
                "data": 9,
                "desc": "使用windows的命令提示符",
                "imports": "src.features.modules.module5.func9",
                "executes": "src.features.modules.module5.func9.main()"
            },

            "func10": {
                "name": "打开小天才自检界面",
                "data": 10,
                "desc": "如上",
                "imports": "src.features.modules.module5.func10",
                "executes": "src.features.modules.module5.func10.main()"
            },

            "func11": {
                "name": "其他拓展功能",
                "data": 11,
                "desc": "其他乱七八糟的功能",
                "imports": "src.features.modules.module5.func11",
                "executes": "src.features.modules.module5.func11.main()"
            }
            
        }
    },

    "module6": {
        "namespace": "src.features.modules.module6",
        "imports": "src.features.modules.module6",
        "executes": "src.features.modules.module6.load_menu_prompt()",
        "name": "设置与其他",
        "menu_display": "工具箱的设置和其他乱七八糟的",
        "desc": "这是一个乱七八糟的版块",
        "prompt": "想干些什么？",
        "tip": "注：我用的终端优化（noneprompt）的选项可以用鼠标点击",
        "data": 6,
        "codepage": 936,
        "functions": {

            "func1": {
                "name": "工具箱设置",
                "data": 1,
                "desc": "调整工具箱的设置",
                "imports": "src.features.modules.module6.func1",
                "executes": "src.features.modules.module6.func1.main()"
            },

            "func2": {
                "name": "问题修复",
                "data": 2,
                "desc": "尝试修复出现的问题",
                "imports": "src.features.modules.module6.func2",
                "executes": "src.features.modules.module6.func2.main()"
            },

            "func3": {
                "name": "恢复出厂设置",
                "data": 3,
                "desc": "将脚本恢复为出厂设置",
                "imports": "src.features.modules.module6.func3",
                "executes": "src.features.modules.module6.func3.main()"
            },

            "func4": {
                "name": "关于脚本",
                "data": 4,
                "desc": "脚本的开发者信息",
                "imports": "src.features.modules.module6.func4",
                "executes": "src.features.modules.module6.func4.main()"
            },

            "func5": {
                "name": "更新日志",
                "data": 5,
                "desc": "脚本的更新日志",
                "imports": "src.features.modules.module6.func5",
                "executes": "src.features.modules.module6.func5.main()"
            },

            "func6": {
                "name": "查看\"你知道吗？\"",
                "data": 6,
                "desc": "一些很热的冷知识或者开发者的发癫语录",
                "imports": "src.features.modules.module6.func6",
                "executes": "src.features.modules.module6.func6.main()"
            },

            "func7": {
                "name": "精神状态炸裂",
                "data": 7,
                "desc": "没什么用",
                "imports": "src.features.modules.module6.func7",
                "executes": "src.features.modules.module6.func7.main()"
            },

            "func8": {
                "name": "去你（make过去式）msgbox",
                "data": 8,
                "desc": "用来关掉vbscript里面loop的msgbox",
                "imports": "src.features.modules.module6.func8",
                "executes": "src.features.modules.module6.func8.main()"
            },

            "func9": {
                "name": "尝试蓝屏（没啥用）",
                "data": 9,
                "desc": "纯粹无聊做的",
                "imports": "src.features.modules.module6.func9",
                "executes": "src.features.modules.module6.func9.main()"
            },

            "func10": {
                "name": "开发者设置",
                "data": 10,
                "desc": "就是开发者用的设置，用来调试的",
                "imports": "src.features.modules.module6.func10",
                "executes": "src.features.modules.module6.func10.main()"
            },
            
        }
    }
}




def get_module_attr(module:str="module1",attr="name"):
    "获取模块名称"
    try:
        return module_list[module][attr]
    except Exception as e:
        console.print(warn_color+f"获取模块{module}的{attr}失败：{type(sys.exc_info()[1]).__name__}: {e}")
        write_log(SCRIPT_FILE_NAME,pid,3,f"获取模块{module}的{attr}失败：{type(sys.exc_info()[1]).__name__}: {e}")
        if attr == "name":return "读取失败" 
        else: return None

def get_func_attr(module:str="module1",func:str="func1",attr="name"):
    "获取功能属性"
    try:
        return module_list[module]["functions"][func][attr]
    except Exception as e:
        console.print(warn_color+f"获取功能{module}.{func}的{attr}失败：{type(sys.exc_info()[1]).__name__}: {e}")
        write_log(SCRIPT_FILE_NAME,pid,3,f"获取功能{module}.{func}的{attr}失败：{type(sys.exc_info()[1]).__name__}: {e}")
        if attr == "name":return "读取失败" 
        else: return None

def load_module_menu(module:str="module1"):
    "展示模块菜单，默认load_menu_prompt()"
    try:
        exec(f"import src.features.modules.{module}")
    except Exception as e:
        console.print(err_color+f"导入模块\"{get_module_attr(module,'name')}\"的菜单失败：{type(sys.exc_info()[1]).__name__}: {e}")
        write_log(SCRIPT_FILE_NAME,pid,3,f"导入模块\"{get_module_attr(module,'name')}\"(import src.features.modules.{module})的菜单失败：{type(sys.exc_info()[1]).__name__}: {e}")
        pause("？？发生什么事了（按任意键继续）")
        return

    try:
        exec(f"src.features.modules.{module}.load_menu_prompt()")
    except Exception as e:
        console.print(err_color+f"显示模块\"{get_module_attr(module,'name')}\"的菜单失败：{type(sys.exc_info()[1]).__name__}: {e}")
        write_log(SCRIPT_FILE_NAME,pid,3,f"显示模块\"{get_module_attr(module,'name')}\"(src.features.modules.{module}.load_menu_prompt())的菜单失败：{type(sys.exc_info()[1]).__name__}: {e}")
        pause("？？发生什么事了（按任意键继续）")
        return


    
def run_function(module:str="module1",func:str="func1"):
    "运行指定的板块里的功能"

    try:
        exec(f"import {get_func_attr(module,func,'imports')}")
    except Exception as e:
        console.print(err_color+f"导入模块\"{get_func_attr(module,'name')}\"失败：{type(sys.exc_info()[1]).__name__}: {e}")
        write_log(SCRIPT_FILE_NAME,pid,3,f"导入模块\"{get_func_attr(module,'name')}\"({get_func_attr(module,func,'imports')})失败：{type(sys.exc_info()[1]).__name__}: {e}")
        pause("？？发生什么事了（按任意键继续）")
        return

    try:
        exec(get_func_attr(module,func,"executes"))
    except Exception as e:
        console.print(err_color+f"执行\"{get_func_attr(module,'name')}\"失败：{type(sys.exc_info()[1]).__name__}: {e}")
        write_log(SCRIPT_FILE_NAME,pid,3,f"执行\"{get_func_attr(module,'name')}\"({get_func_attr(module,func,'executes')})失败：{type(sys.exc_info()[1]).__name__}: {e}")
        pause("？？发生什么事了（按任意键继续）")
        return
    

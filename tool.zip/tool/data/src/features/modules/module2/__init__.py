import src

import src.features
import src.features.modules
from src.init_utils import *




"""
模块1：2
"""



SCRIPT_FILE_NAME = f"script:{__name__}"

module_name = "module2"

namespace = src.features.modules.module_list[module_name]["namespace"]

name = src.features.modules.module_list[module_name]["name"]

desc = src.features.modules.module_list[module_name]["desc"]

prompt = src.features.modules.module_list[module_name]["prompt"]

function_list:List[Script.Function] = []

try:
    chcp(src.features.modules.module_list[module_name]["codepage"])
except:
    pass



def load_menu_prompt():
    "看啥看，我本身就是一个功能"  
    write_log(SCRIPT_FILE_NAME,pid,1,"进入了安装应用板块（3）。")  
    while True:

        show_msgbox(name,desc,use_console=True)
        write_log(SCRIPT_FILE_NAME,pid,1,"请求用户输入路径...")
        inputmsg = input_prompt(prompt)
        write_log(SCRIPT_FILE_NAME,pid,1,"获得的路径："+inputmsg)
        if inputmsg == "0":
            return
        install_apk(inputmsg)
        pause()

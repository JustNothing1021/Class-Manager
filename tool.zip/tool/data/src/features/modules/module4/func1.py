
from src.init_utils import *

from src.features.modules.module4.func3 import adbpull

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    dst = input_prompt("\n请输入导出文件夹的路径：",
                      validator=lambda string:string != "" and not string.isspace(),
                      error_message="请输入路径...")
    wait_for_device()
    console.print(info_color+"开始导出...")
    output = adbpull("/sdcard/DCIM", dst)
    if output:
        console.print(err_color+"导出失败...")
    else:
        console.print(success_color+"导出成功！")
    pause()

                    
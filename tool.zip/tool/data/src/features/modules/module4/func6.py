from src.init_utils import *


void:None


class OwnerPermission(NamedTuple):
        "所有者权限"
        read:bool=True
        write:bool=True
        execute:bool=True
        set_uid:bool=False

class UserPermission(NamedTuple):
        "用户组权限"
        read:bool=True
        write:bool=True
        execute:bool=True
        set_gid:bool=False

class OtherPermission(NamedTuple):
        "其他用户权限"
        read:bool=True
        write:bool=False
        execute:bool=False
        sticky:bool=False


class FilePermission(NamedTuple):
    "描述文件权限"
    owner:OwnerPermission = OwnerPermission()
    user:UserPermission   = UserPermission()
    other:OtherPermission = OtherPermission()



def parse_access(string:str="brwxr--r--") -> Tuple[Literal["file", "directory", "pipe", "link", "block", "char", "socket"], FilePermission]:
    "解析字符串形式的access"
    if string[0] == "-":
        file_type = "file"
    elif string[0] == "d":
        file_type = "directory"
    elif string[0] == "p":
        file_type = "pipe"
    elif string[0] == "l":
        file_type = "link"
    elif string[0] == "b":
        file_type = "block"
    elif string[0] == "c":
        file_type = "char"
    elif string[0] == "s":
        file_type = "socket"

    return file_type, FilePermission(
        OwnerPermission(
            string[1] == "r",
            string[2] == "w",
            string[3] in ("x", "s"),
            string[3] in ("S", "s")
        ),

        UserPermission(
            string[4] == "r",
            string[5] == "w",
            string[6] in ("x", "s"),
            string[6] in ("S", "s")
        ),

        OtherPermission(
            string[7] == "r",
            string[8] == "w",
            string[9] in ("x", "t"),
            string[9] in ("S", "T")
        )
    )



    

def to_human_readable_size(size:int):
    "将字节数转换为人能读懂的大小"
    if size < B_in_1KB:
        return f"{size}B"
    elif size < B_in_1KB * KB_in_1MB:
        return f"{round(size/B_in_1KB,4)}KB"
    elif size < B_in_1KB * KB_in_1MB * MB_in_1GB:
        return f"{round(size/(B_in_1KB*KB_in_1MB),4)}MB"
    else:
        return f"{round(size/(B_in_1KB*KB_in_1MB*MB_in_1GB),4)}GB"





class FileObject(NamedTuple):
    "一个文件"
    filename:str
    displayname:str
    filetype:Literal["file", "directory", "pipe", "link", "block", "char", "socket"]
    filetype_full:str
    access:FilePermission
    octalaccess:int
    inode:int
    size:int
    username:str
    userid:int
    groupname:str
    groupid:int
    filewritetime:str
    dirchangetime:str
    mountpoint:str
    hardlinks:int
    longfilename:str
    link:Optional[str]
    is_broken_link:Optional[bool]
    is_placeholder:bool
    full_path:str
    error:bool


def get_file_info(fileobject:Union[str, FileObject],show_output=False) -> FileObject:
    if show_output:split_line("文件信息")
    quote = r"'"
    if isinstance(fileobject,FileObject):
        name = fileobject.filename
    else:
        name = fileobject
    q = lambda s:quote+s+quote if s!="" else ""
    if '"' not in fileobject:
        stat, f_info_org = run_command(["adb", "shell", ('su -c ' if has_root() else '') + "stat",  q(name), "-c", r"""'\{"filename":"%n","filetype":"%F","inode":%i,"size":%s,"groupname":"%G","groupid":%g,"username":"%U","userid":%u,"access":"%A","octalaccess":%a,"mountpoint":"%m","hardlinks":%h,"filewritetime":"%y","dirchangetime":"%z","longfilename":"%N"\}'""".replace('"', r'\"')],show_output=False,return_type="statusoutput",silent_when_wait=True)
    else:
        stat, f_info_org = run_command(["adb", "shell", ('su -c ' if has_root() else '') + "stat",  q(name), "-c", r"""'\{"filetype":"%F","inode":%i,"size":%s,"groupname":"%G","groupid":%g,"username":"%U","userid":%u,"access":"%A","octalaccess":%a,"hardlinks":%h,"filewritetime":"%y","dirchangetime":"%z"\}'""".replace('"', r'\"')],show_output=False,return_type="statusoutput",silent_when_wait=True)

    if stat:
        if isinstance(fileobject, FileObject):
            fileobject = fileobject.filename

        console.print(err_color+f"解析文件\[{fileobject}]出现错误：\n{f_info_org}"+
                          ("\n（权限不足）" if "Permission denied" in f_info_org else "")+
                          ("\n（文件不存在）" if "No such file or directory" in f_info_org else ""))
        return FileObject(fileobject,
                          fileobject,
                          None,
                          None,
        FilePermission(OwnerPermission(False,False,False),
                        UserPermission(False,False,False),
                        OtherPermission(False,False,False)),
        None, None, None, None, None, None, None, None, None,
        None, None, None, None, 
        None, False, None, True)
    f_info = json.loads(f_info_org)
    if '"' in name:
        stat = [0, 0, 0]
        stat[0], f_info["filename"] = run_command(rf"""adb shell {'su -c ' if has_root() else ''}"stat {q(name)} -c '%n'" """,show_output=False,return_type="statusoutput",silent_when_wait=True)
        stat[1], f_info["mountpoint"] = run_command(rf"""adb shell {'su -c ' if has_root() else ''}"stat {q(name)} -c '%m'" """,show_output=False,return_type="statusoutput",silent_when_wait=True)
        stat[2], f_info["longfilename"] = run_command(rf"""adb shell {'su -c ' if has_root() else ''}"stat {q(name)} -c '%N'" """,show_output=False,return_type="statusoutput",silent_when_wait=True)
        if any(stat):
            if isinstance(fileobject, FileObject):
                fileobject = fileobject.filename
            if stat[0]:f_info_org = f_info["filename"]
            if stat[1]:f_info_org = f_info["mountpoint"]
            if stat[2]:f_info_org = f_info["longfilename"]
            console.print(err_color+f"解析文件\[{fileobject}]出现错误：\n{f_info_org}"+
                          ("\n（权限不足）" if "Permission denied" in f_info_org else "")+
                          ("\n（权限不足）" if "No such file or directory" in f_info_org else ""))
            return FileObject(fileobject,
                            fileobject,
                            None,
                            None,
            FilePermission(OwnerPermission(False,False,False),
                            UserPermission(False,False,False),
                            OtherPermission(False,False,False)),
            None, None, None, None, None, None, None, None, None,
            None, None, None, None, 
            None, False, None, True)
    f_info:Dict[str, Union[str, int]]
    f_info["link"] = f_info["longfilename"].split(" -> `")[1][0:-1] if " -> `" in f_info["longfilename"] else None
    if " -> `" in f_info["longfilename"] and f_info["longfilename"].split(" -> `")[1][0:-1].startswith("./"):
        f_info["link"] = "/".join(f_info["longfilename"].split("'")[0][1:].split("/")[:-1]) + f_info["longfilename"].split(" -> `")[1][:-1][1:]
    s = lambda string:string.startswith("`") and string.endswith("'")
    fileobject = FileObject(
     f_info["filename"],
     "* 上级目录" if f_info["filename"] == ".." else "* 当前目录" if f_info["filename"] == "." else f_info["filename"],
     parse_access(f_info["access"])[0],
     f_info["filetype"],
     parse_access(f_info["access"])[1],
     f_info["octalaccess"],
     f_info["inode"],
     f_info["size"],
     f_info["username"],
     f_info["userid"],
     f_info["groupname"],
     f_info["groupid"],
     f_info["filewritetime"],
     f_info["dirchangetime"],
     f_info["mountpoint"],
     f_info["hardlinks"],
     f_info["longfilename"],
     f_info["link"],
     None,
     False,
     f_info["longfilename"].split("'")[0][1:][1:][:-1] 
     if s(f_info["longfilename"].split("'")[0][1:]) 
     else f_info["longfilename"].split("'")[0][1:],
     True)




    
    if show_output:
        owner_access_desc = "可"
        if fileobject.access.owner.read:owner_access_desc+="读取，"
        if fileobject.access.owner.write:owner_access_desc+="写入，"
        if fileobject.access.owner.execute:owner_access_desc+="执行，"
        if fileobject.access.owner.set_uid:owner_access_desc+="设置uid，"
        if owner_access_desc == "可":
            owner_access_desc = "无权限"
        else:
            owner_access_desc = owner_access_desc[0:-1]

        user_access_desc = "可"
        if fileobject.access.user.read:user_access_desc+="读取，"
        if fileobject.access.user.write:user_access_desc+="写入，"
        if fileobject.access.user.execute:user_access_desc+="执行，"
        if fileobject.access.user.set_gid:user_access_desc+="设置gid，"
        if user_access_desc == "可":
            user_access_desc = "无权限"
        else:
            user_access_desc = user_access_desc[0:-1]

        other_access_desc = "可"
        if fileobject.access.other.read:other_access_desc+="读取，"
        if fileobject.access.other.write:other_access_desc+="写入，"
        if fileobject.access.other.execute:other_access_desc+="执行，"
        if fileobject.access.other.sticky and fileobject.filetype == "directory":other_access_desc+="使目录下文件所有人可访问。 "
        if other_access_desc == "可":
            other_access_desc = "无权限"
        else:
            other_access_desc = other_access_desc[0:-1]
        console.print(info_color+f"文件名：  {tip_color}{fileobject.filename}")
        console.print(info_color+f"完整路径：{tip_color}{fileobject.full_path}")
        console.print(info_color+f"挂载点：{tip_color}{fileobject.mountpoint}")
        if fileobject.filetype == "link":console.print(info_color+f"链接指向：{tip_color}{fileobject.link}")
        console.print(info_color+f"文件类型：{tip_color}{fileobject.filetype}({fileobject.filetype_full})")
        console.print(info_color+f"大小：    {tip_color}{to_human_readable_size(fileobject.size)}({value_color}{fileobject.size}{close_tag})")
        console.print(info_color+f"inode：   {value_color}{fileobject.inode}")
        console.print(info_color+f"修改时间：{value_color}{fileobject.filewritetime}")
        console.print(info_color+f"硬链接数：{value_color}{fileobject.hardlinks}")
        console.print(info_color+f"权限：{value_color}{fileobject.octalaccess}")
        console.print(info_color+f"\t所属：    {str(value_color+fileobject.username+'('+str(fileobject.userid)+')').ljust(20)}"+owner_access_desc)
        console.print(info_color+f"\t用户组：  {str(value_color+fileobject.username+'('+str(fileobject.userid)+')').ljust(20)}"+user_access_desc)
        console.print(info_color+f"\t其他用户：{str('* 无数据').ljust(10)}"+value_color+other_access_desc)

    return fileobject



def main():
    warn_list = []
    first_load = True
    cur_dir = "" if has_root() else ""

    while True:

        quote = r"'"
        stat, file_list_str = run_command(rf"adb shell {'su -c' if has_root() else ''} ls -Lap1 {quote+cur_dir+quote if cur_dir != '' else ''}",
                                          return_type="statusoutput",
                                          encoding="utf-8",
                                          show_output=False,
                                          silent_when_wait=True,
                                          output_by_tuple=True)
        

        
        file_list_str:StringCommandOutput
        permission_denied = False
        file_list:List[FileObject] = []
        if file_list_str.stdout.strip() == "" and stat:
            console.print(err_color+"拉取文件列表时出现错误：\n"+"\n".join(["\t" + line for line in file_list_str.stderr.splitlines()])+
                          ("（权限不足）" if "Permission denied" in file_list_str.stderr.strip() else "")+
                          f"\n\t\[路径：{cur_dir}]")
            permission_denied = "Permission denied" in file_list_str.stderr.strip()
            file_list:List[FileObject] = [FileObject(cur_dir+"/..",
                                                     "* 上级目录",
                                                    None,
                                                    None,
                                                    FilePermission(OwnerPermission(False,False,False),
                                                                    UserPermission(False,False,False),
                                                                    OtherPermission(False,False,False)),
                                                    None, None, None, None, None, None, None, None, None,
                                                    None, None, None, None, 
                                                    False, False, None, True)]
            pause()
            if "Permission denied" not in file_list_str.stderr.strip():
                if first_load:
                    return
                else:
                    cur_dir = last_dir
                    continue


        first_load = False
        _, file_list_str_2 = run_command(rf"adb shell {'su -c' if has_root() else ''} ls -ap1 {quote+cur_dir+quote if cur_dir != '' else ''}",
                                          return_type="statusoutput",
                                          encoding="utf-8",
                                          show_output=False,
                                          silent_when_wait=True,
                                          output_by_tuple=True)
        c = 0

        for file in file_list_str_2.stdout.splitlines():
            if file.strip() not in file_list_str.stdout and file.strip()+"/" not in file_list_str.stdout:
                file_list.append(FileObject(cur_dir+"/"+file,
                                            file,
                                            "file",
                                            None,
                                            FilePermission(OwnerPermission(False,False,False),
                                                            UserPermission(False,False,False),
                                                            OtherPermission(False,False,False)),
                                            None, None, None, None, None, None, None, None, None,
                                            None, None, None, None, 
                                            False, False, None, True))




        for file in file_list_str.stdout.splitlines():
            c += 1
            file = file.strip()
            if file == "":
                 continue
            if file.endswith("/"):
                file_list.append(FileObject(cur_dir+"/"+file[0:-1],
                                                "* 上级目录" if file[0:-1] == ".." else "* 当前目录" if file[0:-1] == "." else file,
                                                "directory",
                                                None,
                                                FilePermission(OwnerPermission(False,False,False),
                                                                UserPermission(False,False,False),
                                                                OtherPermission(False,False,False)),
                                                None, None, None, None, None, None, None, None, None,
                                                None, None, None, None, 
                                                False, False, None, True))
            else:
                file_list.append(FileObject(cur_dir+"/"+file,
                                                file,
                                                "file",
                                                None,
                                                FilePermission(OwnerPermission(False,False,False),
                                                                UserPermission(False,False,False),
                                                                OtherPermission(False,False,False)),
                                                None, None, None, None, None, None, None, None, None,
                                                None, None, None, None, 
                                                False, False, None, True))
                    


        choice_list = []
        file_list_ordered = []
        order = [(s.displayname[0], s) for s in file_list]

        for c, file in order:
            if file.filename.endswith(("/.", "/..")):
                file_list_ordered.append(file)

        for c, file in order:
            if c == ".":
                file_list_ordered.append(file)

        for char in range(ord('0'),ord('9')+1):
            for c, file in order:
                if bytearray([char]).decode() == c:
                    file_list_ordered.append(file)

        for char in range(ord('A'),ord('Z')+1):
            for c, file in order:
                if bytearray([char]).decode() == c:
                    file_list_ordered.append(file)
            char += 32                                          # ord('a') - ord('A'), 纯懒得写
            for c, file in order:
                if bytearray([char]).decode() == c:
                    file_list_ordered.append(file)
            

        for c, file in order:
            if not (ord(c) in range(65, 90+1) or ord(c) in range(97, 122+1) or ord(c) in (42,46) or ord(c) in range(48, 57+1)):
                file_list_ordered.append(file)



        file_list = file_list_ordered
            
        choice_list:List[Choice]

        for file in file_list:
            if file.filetype == "directory":
                choice_list.append(Choice(file.displayname+"/" if not (any([s in file.filename for s in (".", "..")]) or file.displayname.endswith("/")) else file.displayname, file))
                 
        for file in file_list:
            if file.filetype != "directory":
                choice_list.append(Choice(file.displayname, file))
        if len(file_list_str.stdout.replace(".","").strip()) == 0:
            choice_list.append(Choice(" (文件夹为空) ",FileObject(None,
                                                " (文件夹为空) ",
                                                "file",
                                                None,
                                                FilePermission(OwnerPermission(False,False,False),
                                                                UserPermission(False,False,False),
                                                                OtherPermission(False,False,False)),
                                                None, None, None, None, None, None, None, None, None,
                                                None, None, None, None, 
                                                False, True, None, True)))


            
        if file_list_str.stderr.strip() != "":
            warn_list.append(warn_color+f"警告：部分文件加载出错(仅展示部分): {random.choice(file_list_str.stderr.strip().splitlines())}"+close_tag)
            


        choice = load_functionmenu("文件管理",
                                  f"当前路径：{cur_dir.replace('/', tip_color + '/' + close_tag) if cur_dir != '' else '（根目录）'}",
                                   "请选中一个文件进行操作。",
                                   choice_list,
                                   ("\n".join(warn_list) + ("\n" if warn_list != [] else "")) + "注：这个对于低版本还没破解的手表有点用，往下翻可以滚动列表",
                                   listmaxheight=20)
        warn_list = []
        if choice == 0:
            return
        choosed_file:FileObject = choice



        if choosed_file.is_placeholder:
            console.print(info_color+"这个文件夹是空的或者无权访问...\n话说你为什么要点进来")
            pause(" (按任意键重新加载) ")
            warn_list = []
            continue

        choosed_file = get_file_info(choosed_file, False)

        if choosed_file.filetype == "file":
                console.print(info_color+f"文件类型：{tip_color}文件（{choosed_file.filetype},{choosed_file.filetype_full}）")

        elif choosed_file.filetype == "directory":
                console.print(info_color+f"文件类型：{tip_color}目录（{choosed_file.filetype},{choosed_file.filetype_full}）")

        elif choosed_file.filetype == "link":
                console.print(info_color+f"文件类型：{tip_color}链接（{choosed_file.filetype},{choosed_file.filetype_full}）")
                console.print(info_color+f"指向：{value_color}{choosed_file.link}"+
                              (f"{warn_color}（可能不存在）" if choosed_file.is_broken_link else ""))
                    


        choice_list =   [Choice("提取到文件（电脑上）","extract"),
                         Choice("以文件替换（电脑上）","replace"),
                         Choice("移动到位置（设备上）","move"),
                         Choice("复制到位置（设备上）","copy"),
                         Choice("更改权限  （设备上）","chmod"),
                         Choice("更改用户组（设备上）","chgrp"),
                         Choice("查看详细信息","info"),
                         Choice("取消操作","cancel")]
            
        if choosed_file.filetype == "directory":
            choice_list.insert(0, Choice("目录：转到此处","jump"))
            
        if choosed_file.filetype == "link":
            choice_list.insert(0, Choice("链接：转到此处","jump"))

        choice = list_prompt("请选择要进行的操作",choice_list).data

        # FIXME: 你还有一大堆功能没做完！！
            
        if choice == "extract":
                if run_command("adb root",return_type="status"):
                    console.print(warn_color+"获取root失败，将会尝试继续...")
                console.print(info_color+"文件路径: "+choosed_file.full_path)
                path = input_prompt("请输入导出的路径：",validator=lambda s:s != "")
                stat, out = run_command(["adb", "pull", choosed_file.full_path, path],return_type="statusoutput")
                if stat:
                    if "Permission denied" in out:
                        console.print(err_color+"拉取失败, 权限不足...")
                        console.print(tip_color+"尝试将其复制到/sdcard下？(如果有root的话)")
                    else:
                        console.print(err_color+"拉取失败...")
                else:
                    console.print(success_color+"拉取成功！")
                pause()
                                                                                      

                

                
        if choice == "info":
                try:
                    get_file_info(choosed_file,show_output=True)
                except:
                    console.print(err_color+"文件分析失败...")
                pause()

        if choice == "jump":
                if choosed_file.filetype == "directory":
                    last_dir = cur_dir
                    choosed_file = get_file_info(choosed_file,show_output=False)
                    cur_dir = choosed_file.full_path
                    if cur_dir.endswith("/.."):
                        cur_dir =  "/".join(cur_dir.split("/")[0:-2])
                    if cur_dir.endswith("/.") :
                        cur_dir =  "/".join(cur_dir.split("/")[0:-1])

                elif choosed_file.filetype == "link":
                    last_dir = cur_dir
                    try:
                        link = choosed_file.link

                        if "/.." in choosed_file.link:
                            if choosed_file.link.startswith("../"):
                                back = choosed_file.link.count("../")
                                link = "/".join(choosed_file.filename.split("/")[:back*-1-1])+\
                                       "/"+"/".join(choosed_file.link.split("/")[back:])
                            else:
                                back = target_info.link.count("/..")
                                link.replace("/..","")
                                link = "/".join(link.split("/")[:back*-1])
                        target_info:FileObject = get_file_info(link,show_output=False)
                        if target_info.size is None:
                            console.print(err_color+f"无法继续跳转, 链接指向的文件不存在({info_color+target_info.filename+tip_color} -> {err_color+str(target_info.link)})")
                            pause()
                            raise FileNotFoundError
                        console.print(info_color+f"跳转中...\n{tip_color}-> {value_color}"+
                                    ("/" if not link else link))
                        last_path = choosed_file.full_path
                        
                        while True:
                            try:
                                if (target_info.filetype != "link"):
                                    break
                                if not(target_info.full_path.strip() != 
                                   target_info.link.strip() and
                                   last_path != target_info.full_path):
                                    break
                            except:
                                console.print(tip_color+"-> "+value_color+str(target_info.full_path))
                                if target_info.link is None:
                                    console.print(err_color+f"无法继续跳转, 链接指向为空({info_color+target_info.filename+tip_color} -> {err_color+str(target_info.link)})")
                                    pause()
                                    break

                            if "/.." in target_info.link:
                                if target_info.link.startswith("../"):
                                    back = target_info.link.count("../")
                                    link = "/".join(target_info.filename.split("/")[:back*-1-1])+\
                                        "/"+"/".join(target_info.link.split("/")[back:])
                                else:
                                    back = target_info.link.count("/..")
                                    link.replace("/..","")
                                    link = "/".join(link.split("/")[:back*-1])

                            last_path = target_info.full_path
                            target_info = get_file_info(link)
                            console.print(tip_color+"-> "+value_color+str(target_info.full_path))
                            if target_info.link is None and target_info.filetype == "link":
                                console.print(err_color+f"无法继续跳转, 链接指向为空\n({info_color+target_info.filename+tip_color} -> {err_color+str(target_info.link)})")
                                pause()
                                break
                        link = target_info.full_path
                        link_file = get_file_info(link,show_output=False)
                        if link_file.filetype in ("directory", "socket"):

                            cur_dir = link
                            console.print(info_color+"跳转完毕, 加载菜单...")
                        
                        else:
                            cur_dir = "/".join(link.split("/")[:-1])
                            warn_list = [info_color+"注意：指定的链接指向的是一个文件，已经打开该文件所在目录"+close_tag]
                            console.print(info_color+"跳转完毕, 加载菜单...")
                            continue 
                    except:
                        console.print(err_color+"跳转失败...\n"+traceback.format_exc())
                        pause()
                        cur_dir = last_dir


                        
                    
                
                 
            





from src.init_utils import *



SCRIPT_FILE_NAME = f"script:{__name__}"


cmd_env_vars = cmd_environment_variables
set_var_cmd = ""

for k in cmd_env_vars.keys():
    set_var_cmd += f"set {k}={cmd_env_vars[k]}&"

def adbpush(src:str,dst:str) -> int:
    "使用adb pull命令对文件进行操作"
    return os.system(f"{set_var_cmd}{BIN_PATH}\\adb.exe {device_sn_args} push {src} {dst}")


def main():

    src = input_prompt("\n请输入文件在电脑上的路径：",
                      validator=lambda string:string != "" and not string.isspace(),
                      error_message="请输入路径...")
    
    dst = input_prompt("\n请输入需要导入到手表里的路径：",
                      validator=lambda string:string != "" and not string.isspace(),
                      error_message="请输入路径...")
    wait_for_device()
    console.print(info_color+"开始导入...")
    output = adbpush(src, dst)
    if output:
        console.print(err_color+"导入失败...")
    else:
        console.print(success_color+"导入成功！")
    pause()

from src.init_utils import *

from src.features.modules.module4.func5 import adbpush

SCRIPT_FILE_NAME = f"script:{__name__}"

def main():
    src_is_dir = False
    src = input_prompt("\n请输入文件在电脑上的路径：",
                      validator=lambda string:string != "" and not string.isspace(),
                      error_message="请输入路径...")
    if os.path.isdir(src):
        console.print(tip_color+"检测到输入的路径为一个文件夹，将会将文件夹下的所有文件push进去")
        src_is_dir = True

    
    dst = ListPrompt("请输入文件的类型...",
                     [Choice("1.图片","/sdcard/DCIM/Camera"),
                      Choice("2.视频","/sdcard/DCIM/Video")],
                      pointer=ListPrompt_pointer,
                      annotation=ListPrompt_annotation).prompt(style=ListPrompt_style).data
    wait_for_device()
    console.print(info_color+"开始导入...")
    if src_is_dir:
        global succeed, total
        succeed = 0
        total = 0
        for f in [src + "\\" + file for file in list_tree(src) if not file.endswith("\\")]:
            output = adbpush(f, dst)
            total += 1
            if not output:
                 succeed += 1
        if succeed == total:
            console.print(success_color+"全部完成！")
        elif succeed == 0:
            console.print(err_color+"全部失败...")
        else:
            console.print(warn_color+f"部分完成...{value_color}（{succeed}/{total}，{round(succeed/total*100,1)}%）")
    else:
        output = adbpush(src, dst)
        if output:
            console.print(err_color+"导入失败...")
        else:
            console.print(success_color+"导入成功！")
    pause()

                    

"""
功能性文件。
"""

build_version = 11500
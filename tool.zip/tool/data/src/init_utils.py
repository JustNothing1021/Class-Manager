from src.init_base_utils import *
from src.init_cmd_utils import *

def on_start(_globals:dict,_locals:dict,autorun=True) -> None:
    "在主程序开始执行时额外执行的命令，可修改，可以用于测试traceback等"
    if autorun:
        try:
            try:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_start.py",encoding="utf-8").read()
            except Exception:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_start.py",encoding="gbk").read()
            exec(command)
        except Exception:
            print(f"脚本{PATCH_SCRIPT_PATH}\\on_start.py执行失败！")
            try:
                traceback.print_exc()
            except Exception:
                pass    

def on_boot_up_finished(_globals:dict,_locals:dict,autorun=True) -> None:
    "启动完成执行的命令"
    if autorun:
        try:
            try:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_boot_up_finished.py",encoding="utf-8").read()
            except Exception:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_boot_up_finished.py",encoding="gbk").read()
            exec(command)
        except Exception:
            print(f"脚本{PATCH_SCRIPT_PATH}\\on_boot_up_finished.py执行失败！")
            try:
                traceback.print_exc()
            except Exception:
                pass

def on_fatal_exit(_globals:dict,_locals:dict,autorun=True) -> None:
    "将要因致命错误退出时额外执行的命令"
    if autorun:
        try:
            try:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_fatal_exit.py",encoding="utf-8").read()
            except Exception:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_fatal_exit.py",encoding="gbk").read()
            exec(command)
        except Exception:
            print(f"脚本{PATCH_SCRIPT_PATH}\\on_fatal_exit.py执行失败！")
            try:
                traceback.print_exc()
            except Exception:
                pass

def on_load_mainmenu(_globals:dict,_locals:dict,autorun=True) -> None:
    "加载主界面额外执行"
    if autorun:
        try:
            try:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_load_mainmenu.py",encoding="utf-8").read()
            except Exception:
                command = open(f"{PATCH_SCRIPT_PATH}\\on_load_mainmenu.py",encoding="gbk").read()
            exec(command)
        except Exception:
            print(f"脚本{PATCH_SCRIPT_PATH}\\on_load_mainmenu.py执行失败！")
            try:
                traceback.print_exc()
            except Exception:
                pass


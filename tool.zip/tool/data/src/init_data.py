


"""

初始化脚本的数据

"""



import math, cmath, subprocess, winsound, time, random, traceback

import http, sys, shutil, re, sysconfig, requests, json, os
import qrcode, threading, rich, importlib, struct, noneprompt
import sqlite3, zipfile, warnings, lunardate

from ftplib import FTP
from PIL import Image
import xml.etree.ElementTree as ET
from rich.console import Console
import rich.control
from rich.rule import Rule
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
from noneprompt import ListPrompt,  Choice, InputPrompt
from prompt_toolkit.styles import Style
from threading import Thread
from typing import List, Dict, Literal, Tuple, TypeVar, Callable, Optional, Union, Iterable, Any, AnyStr, NamedTuple
from os import PathLike
import rich.spinner
import rich.control
import rich.scope


warnings.filterwarnings("ignore")       # 忽略所有语法警告（懒得管了）
UnicodeDecodeError_Handle = "ignore"


StrPath = Union[str, PathLike]
BytesPath = Union[bytes, PathLike]
GenericPath = Union[AnyStr, PathLike]
StrOrBytesPath = Union[str, bytes, PathLike]   # 实在受不了了就搬过来了(3.8.10限制还是挺多的,只能考虑用Union暂且代替了)
FileDescriptorOrPath = Union[int, StrOrBytesPath]

    # 函数的全局声明全放这里了
    # （我：sonarlint你再骂）
    # global OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH, BIN_PATH
    # global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH, FIRMWARE_PATH
    # global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, LOGLEVEL_FILEPATH, MBN_PATH
    # global cmd_executables
    # global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    # global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    # global menuloadanimation, adbserverport, noflashlight, startedtimes
    # global console, error_console, debug_console
    # global spinner_name, rule_character, default_color, desc_color, selected_color
    # global success_color, value_color, info_color, warn_color, err_color, pause_color
    # global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    # global debug_debug_color, debug_extde_color, debug_supde_color
    # global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    # global WIRELESS_PORT,IMPORTABLE
    # global B_in_1KB, KB_in_1MB, MB_in_1GB
    # global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    # global on_running_code_page
    # global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    # global adb_features_broken, fh_features_broken, basic_features_broken
    # global running_on_win11, special_events, number_of_skills, tip_file_missed
    # global loaded_tips, checkfiles_nextstart
    # global device_sn_args, cmd_environment_variables, output
    # global progress, support_error_desc, localtime


# 文件相关

global OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH, BIN_PATH
global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH, FIRMWARE_PATH
global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, LOGLEVEL_FILEPATH, MBN_PATH


global pid, cwd
pid = os.getpid()
cwd = os.getcwd()




SCRIPT_FILE_NAME = f"script:{__name__}"                         # 当前结构所在地


BIN_PATH = cwd + "\\bin"
DATA_PATH = cwd + "\\data"                                              # 数据文件夹的位置
EXTENSION_PATH = cwd + "\\extensions"                                   # 拓展包文件夹的位置
FILE_PATH = cwd + "\\files"

CACHE_PATH = f"{BIN_PATH}\\cache"                               # 缓存文件夹的位置


BACKUP_PATH = '\\'.join(cwd.split('\\')[0:-1])+"\\backups"
SAVE_PATH = '\\'.join(cwd.split('\\')[0:-1])+"\\saves"


OPTIONS_FILE_NAME = "options.ini"                        # 工具箱配置文件的名字

SETTING_PATH = f"{DATA_PATH}\\settings"        # 默认设置的配置文件夹的位置
PATCH_SCRIPT_PATH = f"{DATA_PATH}\\debugging\\scripts"          # 修补脚本的位置
FIRMWARE_PATH = f"{FILE_PATH}\\firmware"
LINUX_BIN_PATH = F"{BIN_PATH}\\linux\\usr\\local\\wbin"

APK_COPY_PATH = F"{CACHE_PATH}\\temp.apk"                       # 安装包复制的位置
MODULE_COPY_PATH = F"{CACHE_PATH}\\temp.zip"
LOGLEVEL_FILEPATH = f"{SETTING_PATH}\\logging\\logging_level.txt"
LOGNAME_FILEPATH = f"{SETTING_PATH}\\logging\\log_name.txt"
COMMON_MBN_PATH = f"{FIRMWARE_PATH}\\prog_emmc_firehose_8937_ddr_hisen.mbn"
MODULE_SCRIPT_PATH = None


APK_PUSH_PATH = "/data/local/tmp/package.apk"              # 安装包传输的位置
MODULE_PUSH_PATH = "/data/local/tmp/module.zip"           # 模块传输的位置
MODULE_SCRIPT_PUSH_PATH = "/data/local/tmp/module.sh"    # 模块安装脚本的位置




global cmd_executables # 如果在bin文件夹发现了后缀为这些并且名称匹配参数0的文件将会作为命令拓展执行bin内的文件而不是系统命令

cmd_executables = [
        "",
        ".exe",
        ".bat"
]



from src.log import write_log
write_log(sys.argv[0],os.getpid(),1,"开始初始化数据...")


global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
global menuloadanimation, adbserverport, noflashlight, startedtimes


# 配置设置
    
options = BASE_OPTIONS =   {'debugmode': False,
                            'showskillcontent': True,
                            'logging': True, 
                            'firststart': True, 
                            'lastupdate': '2024/06/14_12:59:34', 
                            'versionname': '1.1.6', 
                            'showstartcompletedpercent': True, 
                            'showeditor': True, 
                            'preloadtips': False, 
                            'menuloadanimation': False,
                            'checkfiles': False,
                            'adbserverport': 5037}


debugmode:bool = False                     # debug模式，基本废置了
showskillcontent = False              # debug模式的一个附属项，没什么用
logging = True                        # 记录日志
firststart = True                     # 首次启动
lastupdate = "2024/05/20_13:25:12"    # 最近更新时间
versionname = "1.1.5"                 # 版本号
showstartcompletedpercent = True      # 显示加载动画
showeditor = True                     # 显示你知道吗的作者
preloadtips = False                   # 在启动时加载提示文本
startwithadmin = False                # 带管理员启动
enablecoloredtext = True              # 自动开启带色文字
menuloadanimation = True              # 是否在加载窗口时进行动画
adbserverport = 5037                  # ADB服务所在的端口号


# 需设置的配置


noflashlight = True
startedtimes = 1.0


# 内置

# 控制台相关

global console, error_console, debug_console
global spinner_name, rule_character, default_color, desc_color, selected_color
global success_color, value_color, info_color, warn_color, err_color, pause_color
global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
global debug_debug_color, debug_extde_color, debug_supde_color
global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag



console:Console = Console(color_system="auto",tab_size=4)   # 默认控制台
error_console:Console = Console(color_system="auto",tab_size=4)  # 错误信息输出
debug_console:Console = Console(color_system="auto",tab_size=4)  # 调试信息输出
spinner_name:str = "line"
rule_character:str = "-"
use_old_color = True
if use_old_color:
    default_color:str="[#E0E0E0]"
    desc_color:str = "[#40B0FF]"
    selected_color:str="[#40c0f0]"
    success_color:str="[#20CF20]"
    value_color:str  = "[#30c0F0]"
    info_color:str = "[#40A040]"
    tip_color: str = "[#E0E030]"
    warn_color:str = "[#D07020]"
    err_color: str = "[#f02020]"
    pause_color:str= "[#c0c020]"
    debug_info_color:str = "[#208020]"
    debug_warn_color:str = "[#606000]"
    debug_err_color: str = "[#802020]"
    debug_fatal_color:str= "[#700000]"
    debug_debug_color:str= "[#004070]"
    debug_extde_color:str= "[#102060]"
    debug_supde_color:str= "[#202050]"
else:
    default_color:str="[#E0E0E0]"
    desc_color:str = "[#cc66ff]"
    selected_color:str="[#40c0f0]"
    success_color:str="[#40b0ff]"
    value_color:str  = "[#30c0F0]"
    info_color:str = "[#00cc66]"
    tip_color: str = "[#E0E030]"
    warn_color:str = "[#ff6600]"
    err_color: str = "[#f02020]"
    pause_color:str= "[#ffd70f]"
    debug_info_color:str = "[#208020]"
    debug_warn_color:str = "[#606000]"
    debug_err_color: str = "[#802020]"
    debug_fatal_color:str= "[#700000]"
    debug_debug_color:str= "[#004070]"
    debug_extde_color:str= "[#102060]"
    debug_supde_color:str= "[#202050]"
close_tag = "[/]"


# * 询问设置


ListPrompt_style = Style([
        ("questionmark", "fg:#209FFF bold"),
        ("question", "bold"),
        ("answer", "fg:#FF9D00"),
        ("annotation", "fg:#7F8C8D"),
        ("selected", f"fg:{selected_color[1:][0:-1]}"),
        ("error", "bg:#000000 fg:#FF8000")
])

InputPrompt_style = Style([
        ("questionmark", "fg:#E0E070 bold"),
        ("question", "bold"),
        ("answer", "fg:#FF9D00"),
        ("annotation", "fg:#7F8C8D"),
        ("selected", f"fg:{selected_color[1:][0:-1]}"),
        ("error", "bg:#000000 fg:#FF8000")
])

ConfirmPrompt_style = Style([
        ("questionmark", "fg:#F060E0 bold"),
        ("question", "bold"),
        ("answer", "fg:#FF9D00"),
        ("annotation", "fg:#7F8C8D"),
        ("selected", f"fg:{selected_color[1:][0:-1]}"),
        ("error", "bg:#000000 fg:#FF8000")
])

ListPrompt_annotation = "(使用上下方向键选择，回车确定)"
ListPrompt_pointer = '>'
global WIRELESS_PORT,IMPORTABLE

WIRELESS_PORT = 5555                                            # 工具箱默认重启手表无线连接的端口号
IMPORTABLE = True                                               # 允许被其他文件调用


global B_in_1KB, KB_in_1MB, MB_in_1GB
global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
global on_running_code_page

# 其他
B_in_1KB  = 1024                                                # 1KB等于多少B
KB_in_1MB = 1024                                                # 1MB等于多少KB
MB_in_1GB = 1024                                                # 1GB等于多少MB
MENU_ANIM_DELAY = 0                                             # 加载动画的延迟
on_running_code_page = 936                                      # 代码页
DEFAULT_CODE_PAGE = 936                                         # 默认的代码页
CODE_NAME = {936: "gbk",65001: "utf-8",1252: "utf-8"}           # 代码页的解码名称



global inputmsg
global windowcharwidth

inputmsg:str                                                    # 存储输入内容的变量
windowcharwidth = 70                                            # 默认窗口宽度






global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
global adb_features_broken, fh_features_broken, basic_features_broken
global running_on_win11, special_events, number_of_skills, tip_file_missed
global loaded_tips, checkfiles_nextstart
cecho_not_exist = False            # cecho(一个输出有色文字的命令拓展)不存在时为True
tips = {}                          # 存储提示文本的字典
checkfiles = True                  # 本次启动需要检查文件  
cant_use_install_edxposed = False  # 无法使用一键安装xposed
loadedspecialtips = False          # 加载了特殊提示
adb_features_broken   = False      # adb功能损坏
fh_features_broken    = False      # 刷机功能损坏
basic_features_broken = False      # 基础功能损坏
running_on_win11 = False           # 在WIN11上运行（自动识别）
special_events:list = []           # 此次启动的特殊事件
number_of_skills = 0               # 小提示的数量
tip_file_missed = False            # 小提示文件丢失了
loaded_tips = False                # 已经加载过了提示文本   
checkfiles_nextstart = False       # 下次启动会检查文件


global device_sn_args, cmd_environment_variables,  output
device_sn_args = ""            # 如果指定了连接某一个设备就会更改，比如" -s 127.0.0.1:1145 "，实际存储在模块__main__里面
cmd_environment_variables:dict = {}   # cmd的环境变量



output:str = ""                                     # 记录输出用的



# 检查运行环境


while True:
        try:
            windows_version = open(f"{SETTING_PATH}\\windows_version.txt").read()
            if "Windows 7" not in windows_version:
                rule_character = "─"


            if "Windows 11" in windows_version:
                running_on_win11 = True
                spinner_name = "dots"

            break

        except FileNotFoundError:
            windows_system_info = subprocess.getoutput("systeminfo /FO CSV")
            windows_version = str(windows_system_info).splitlines()[1].split(",")[1]
            open(f"{SETTING_PATH}\\windows_version.txt", mode="w", encoding="ANSI").write(windows_version)
            open(f"{SETTING_PATH}\\platform.txt", mode="w", encoding="ANSI").write(sys.platform)

global progress

progress = Progress(
            SpinnerColumn(spinner_name),
            *Progress.get_default_columns(),
            TimeElapsedColumn(),
            console=console,
            transient=False)

global support_error_desc





# 在程序爆炸时使用的


support_error_desc:dict =  {"KeyError":"没有寻找到指定的键（说白了就是key，不知道怎么翻译才合理）",
                            "TabError":"脚本编写时缩进错误（？", 
                            "NameError":"未寻找到指定名称的目标",
                            "TypeError":"参数的类型对应不正确", 
                            "ValueError":"参数的值/类型不正确",
                            "IndexError":"某个请求超出了所请求的序列的范围", 
                            "BufferError":"缓冲器出现错误", 
                            "EOFError":"在读取文件时遇到异常终止",
                            "ImportError":"导入模块时出现错误（？？？",
                            "MemoryError":"内存不够了", 
                            "SyntaxError":"语法错误（？？", 
                            "SystemError":"Python的解释器出错了（建议把traceback扔给官方）", 
                            "RuntimeError":"未知的运行错误",
                            "KeyboardInterrupt":"脚本被crtl+c强制终止了",
                            "CancelledError":"在选择选项的时候没有做出选择（按下ctrl+c?）",
                            "AssertionError":"必要的运行条件不符合，可能是运行环境不对",
                            "TimeoutError":"脚本的某处处理超时了",
                            "OverflowError":"浮点数计算超出范围（你不会把启动次数改太大了吧）",
                            "AttributeError":"属性错误（应该是我脚本写错了）",
                            "PermissionError":"权限不足或尝试对目录进行操作",
                            "ZeroDivisionError":"尝试进行除数为0的运算",
                            "FileNotFoundError":"必要的文件不存在",
                            "IsADirectoryError":"请求的是一个目录名而非文件名",
                            "NotADirectoryError":"请求的不是一个目录",
                            "UnicodeDecodeError":"解码错误",
                            "UnicodeEncodeError":"编码错误",
                            "ModuleNotFoundError":"模块不存在（？？？",
                            "IndentationError":"缩进错误（？？",
                            "ConnectionAbortedError":"网络连接被驳回",
                            "ConnectionRefusedError":"网络连接被拒绝",
                            "ConnectionResetError":"连接重置",
                            "BrokenPipeError":"管道错误",
                            "SystemExit":"系统异常退出",
                            "UnboundLocalError":"数据丢失/变量未定义",
                            f"{__name__}.script.exceptions.functions.OptionModificationError":"脚本内部修改配置文档的函数出了点问题（traceback扔给我看看）",
                            f"{__name__}.script.exceptions.functions.NotRunningAsMainError":"脚本的运行环境出了点问题",
                            f"{__name__}.script.exceptions.functions.DeviceTimeOutError":"设备在指定时间内没有连接"}


# 设置主界面的小提示文本

tips["a_little_tipmain_1"] =  "如果在某处卡在等待设备又想退回上级可以直接按ctrl+c"
tips["a_little_tipmain_2"] =  "更新后就不能在主界面输入特殊内容了（但彩蛋藏在别处了）"
tips["a_little_tipmain_3"] =  "功能号代码的格式为主功能号-次功能号-...，依此类推"
tips["a_little_tipmain_4"] =  "用功能7-11-2关闭日志能提升速度，但建议打开（我可以修bug，日志在data\\log里面）"
tips["a_little_tipmain_5"] =  "真的啥也不是啊是个fvv（说实话在你知道吗里也提到过）"
tips["a_little_tipmain_6"] =  "手表无法开机时可以用超级恢复救砖，教程网上有"
tips["a_little_tipmain_7"] =  "有些时候不一定要找别人问问题，可以自己上网搜索"
tips["a_little_tipmain_8"] = f"这个工具箱已经存在了{(time.localtime().tm_mon - 10) + (time.localtime().tm_year - 2023) * 12}个月了"
tips["a_little_tipmain_9"] =  "只按一次ctrl+c是不能终止脚本的（因为会触发崩溃挽救系统）"

# 可以自己加项目，但是项目的总和要写在下面
numberoftips = 9

# 设置特殊的小提示文本
tips["a_little_tip_christmas_special"] = "今天是圣诞节！Merry Christmas！"
tips["a_little_tip_new_year_special"] = "今天是元旦节！元旦节快乐！"
tips["a_little_tip_lunar_new_year_special"] = "今天是大年初一！祝全家春节快乐团圆，迎接新的一年！"
tips["a_little_tip_stay_up_late_special"] = "熬夜可不是个好习惯哦，早点睡吧！"
tips["a_little_tip_lantern_festival_special"] = "今天是元宵节!"
tips["a_little_tip_tree_planting_day_special"] = "今天是植树节，但就算不去植树也可以保护环境，比如随手关灯之类的"
tips["a_little_tip_fools_day_special"] = "愚人节快乐！"
tips["a_little_tip_tomb_sweeping_day_special"] = "是清明节，该探望一下祖先了吧"
tips["a_little_tip_labour_day_special"] = "今天是劳动节，但不管在哪一天都不能忽略劳动者们的贡献"
tips["a_little_tip_teenager_day_special"] = "今天是青年节 - 属于我们的节日！"
tips["a_little_tip_mothers_day_special"] = "今天是母亲节，不去给她点祝福什么的吗？"
tips["a_little_tip_childrens_day_special"] = "儿童节！儿童节快乐！"
tips["a_little_tip_dragon_boat_festival_special"] = "端午安康！（我总不能说快乐吧）"
tips["a_little_tip_weather_cooling_special"] = "最近天气将会变冷，注意一下保暖，小心着凉了！"
tips["a_little_tip_fathers_day_special"] = "今天是父亲节，去给他一个祝福吧！"
tips["a_little_tip_partys_day_special"] = "今天是建党节，如果平时有兴趣可以去博物馆或者在网络上了解党的历史"
tips["a_little_tip_weather_heating_special"] = "最近天气将会变热，注意一下穿着和避暑，身体最重要！"
tips["a_little_tip_teachers_day_special"] = "祝你的老师们教师节快乐吧！"


# 我才发现这里有一大堆bug，比如我的生日显示圣诞节快乐。。。。。
# 因为之前没写所以现在补上了
tips["a_little_tip_NoneColdWind_birthday_special"] = "今天是十三怀旧的生日！不说了，我得去和他好好友尽以"
tips["a_little_tip_SB1.0_birthday_special"]        = "今天是SB1.0的生日！请他吃God uses the VPN! (bushi)"
tips["a_little_tip_JustNothing_birthday_special"]  = "今天是我的生日！（高兴）"
tips["a_little_tip_PAQ_birthday_special"]          = "今天是PAQ的生日！（虽然已经毕业几年了但我不会忘的）"



tips["a_little_skill_1"] = r"其实这个功能并没有什么用，只是用来消遣的"
tips["a_little_skill_2"] = r"你可以通过编辑这个脚本，让它变成你的"
tips["a_little_skill_3"] = r"在windows中按住Win+R键可以打开运行框，输入powershell并以管理员模式运行，{\n}在powershell窗口里面输入wininit就能让电脑蓝屏了（虽然也不知道有什么用）"
tips["a_little_skill_4"] = r"vbs有很多种玩法，比如msgbox就是一个很好的玩法（可以看看文件夹里面的msgbox.vbs）"
tips["a_little_skill_5"] = r"不，你不知道"
tips["a_little_skill_6"] = r"你可以更改/添加data文件夹中tips_in_script.txt中的a_little_skill_[数字]（接着那里面的输入）项来更改“你知道吗？”中的内容"
tips["a_little_skill_7"] = r"你现在所看到的就是“你知道吗？”中的第7条内容"
tips["a_little_skill_8"] = r"因为这玩意生成是随机的，所以偶尔会有同一个提示出现两三次，但是如果出现了4次，5次，甚至6次...{\n}那你就可以去买彩票了"
tips["a_little_skill_9"] = r"真的啥也不是啊成分复杂，平时在学校整活比较多（尤其是班上的的电脑），游戏上玩MC，王者荣耀（退了半年多），{\n}原神（退了一年多了），蛋仔派对（大概两个赛季），偶尔编程（比如现在）"
tips["a_little_skill_10"] = r"我刚刚看了我写的，哇，写到第十条了，太不容易了"
tips["a_little_skill_11"] = r"在这个工具包里面还有很多别的命令拓展，可以在功能6-9里面使用，如果要的返回工具箱的话只要输入exit就可以了"
tips["a_little_skill_12"] = r"不是很建议打开开发者，不然整个屏幕会变得花花绿绿的"
tips["a_little_skill_13"] = r"在cmd里面输入color f7可以原神启动（不建议晚上用）"
tips["a_little_skill_14"] = r"十三怀旧对我写的第一个小提示（\"其实我也不知道该写什么，所以只好写这个了\"）的评价是：听君一席话，如听一席话（?）"
tips["a_little_skill_15"] = r"在Win+R调出的运行框里输入regedit并运行，可以打开注册表编辑器，看看就好，{\n}删了不该删的东西我可不负责（别问我怎么知道的）"
tips["a_little_skill_16"] = r"其实只要输入一个指令：adb shell pm uninstall --user 0 com.xtc.i3launcher就能让手表的桌面瘫痪（就是把桌面卸载了），{\n}但是可以救，要把比出厂版本桌面版本高的桌面装回去，但还是不建议尝逝"
tips["a_little_skill_17"] = r"虽然我不知道你是刷了第几次才看到这个，但如果你第一次就看到了，那也算是某种幸运了？"
tips["a_little_skill_18"] = r"一般来说，在使用拓展命令时输入help或者.help可以看到命令的使用教程（一般是英文）"
tips["a_little_skill_19"] = r"十三怀旧成分也很复杂，同时电脑配置不是很好（是根本不行）"
tips["a_little_skill_20"] = r"一般来说，预算低用A卡，预算充足用N卡"
tips["a_little_skill_21"] = r"推荐性价比配置（800元）：Intel_E3-1231v3+精粤H97M-VH-PLUS+AMD_RX580-8G+DDR3-1600MHz-8G*2+500WS电源+四铜管散热器{\n}（至少对我这种 预 算 充 足 的人来说）"
tips["a_little_skill_22"] = r"十三怀旧喜欢的显卡——七彩虹iGame_Gefore_RTX4060Ti_Ultra_W_DOC"
tips["a_little_skill_23"] = r"MC里长按F3+C会有ojng（mojang减去ma）的彩蛋"
tips["a_little_skill_24"] = r"MC中，地狱是个睡觉的“好”地方"
tips["a_little_skill_25"] = r'第19到31条是十三怀旧写的（\\"...."//）'
tips["a_little_skill_26"] = r"知周所众，jre和jdk的优化是编程界最好的（bushi）"
tips["a_little_skill_27"] = r"如果大脑未响应，请不要尝逝强制关闭它，因为可能会当场暴毙"
tips["a_little_skill_28"] = r"MC中，loli_pickaxe是个好mod，因为在1.12.2中，它可以使好朋友的电脑蓝屏（会被360拦截）"
tips["a_little_skill_29"] = r"看了一下，Wow，第29条了"
tips["a_little_skill_30"] = r"原神是个好东西，它使我成绩上升了，抗压能力变高了，但同时血压也变高了"
tips["a_little_skill_31"] = r"关于英特尔奔腾E5300+ATI_Radeon_HD_4350_Series（2009年的老设备{{十三怀旧的}）玩不了原神但可以玩崩坏3这件事"
tips["a_little_skill_32"] = r"啥也不是有一台已经快9年的大电脑了，但它还很健在"
tips["a_little_skill_33"] = r"事实证明，我再多看一眼这个脚本就会原地螺旋升天爆炸了（？）"
tips["a_little_skill_34"] = r"早期的我破解时也很智慧，对着电脑连手表，搞了半天没连上还以为是手表坏了"
tips["a_little_skill_35"] = r"我、十三怀旧和班上的另一位一位整活好手正在研究一种很新的加密传输文字的方法{\n}用来在考试时作弊（开玩笑的，但在研究是真的）"
tips["a_little_skill_36"] = r"把电脑升WIN11了，感觉有点不适应，可能是因为右键菜单被折叠了，但我又不知道怎么把这玩意关掉，所以把它降回去了"
tips["a_little_skill_37"] = r"原神退了半年多了，体检的时候发现我血压收缩压比上学期降了4mmHg，但是十三怀旧刚入原神，他收缩压升了...这证明了什么？"
tips["a_little_skill_38"] = r"因为我不想把某些文件名搞得太难记，所以直接用了散装英文（Chin-glish?）"
tips["a_little_skill_39"] = r"RavenField是一款不错的战地模拟器，但是我弟一般喜欢玩里面的载具，而且总是用载具《冲锋陷阵》，{\n}所以我管它叫毁车与坠机了（不过我弟好像挺喜欢这个名字？）"
tips["a_little_skill_40"] = r"这是SB1.0编译的第一条内容"
tips["a_little_skill_41"] = r"编这个的所有开发者都玩《原神》"
tips["a_little_skill_42"] = r"看你到第43条时，你会发现你被骗了"
tips["a_little_skill_43"] = r"其实没有第42条,不信去翻原代码"
tips["a_little_skill_44"] = r"101001110011111 111100101011110 1111111100001100 101010000101111 101001010101000 1111111100000001{\n}（真的啥也不是啊友情翻译：原神，启动！）"
tips["a_little_skill_45"] = r"文明其体魄，野蛮其精神是十六班的基本特征"
tips["a_little_skill_46"] = r"记得篮球赛的时候，SB1.0看着敌队班级的分数高出自己班十几分时，手中的学牲会常规记录表（可给敌对班级扣分）越来越紧……{\n}（当然，他最后没乱扣分)"
tips["a_little_skill_47"] = r"十三怀旧每一天都与0和1打交道，16班上的女生总是聊有关0和1的话题{\n}（真的啥也不是啊：大脑飞速运转...（出现错误：java.lang.nullPointerException））"
tips["a_little_skill_48"] = r"SB1.0没有好设备"
tips["a_little_skill_49"] = r"第40到第48条是sb1.0编写的，除去十三怀旧和你哪个省的写的其他都是真的啥也不是啊写的"
tips["a_little_skill_50"] = r"某人费尽千辛万苦，终于算是把那条小提示补上了（虽然应该是个人都知道）"
tips["a_little_skill_51"] = r"真的啥也不是啊是个fvv"
tips["a_little_skill_52"] = r"ECHO 处于关闭状态。（bushi）"
tips["a_little_skill_53"] = r"每日一题，防止你玩电脑玩成sadbee： 33+33=？    "
tips["a_little_skill_54"] = r"兄弟你有什什什什什什什什什什什什什什什什什什什什什么实力啊"
tips["a_little_skill_55"] = r"看那里，有一个房子！不，仔细看，那是个{\n}{\n}{\n}{\n}{\n}{\n}{\n}{\n}{\n}{\n}{\n}{\n}{\n}房子！！！"
tips["a_little_skill_56"] = r"其实你每呼吸60秒，寿命就会减少一分钟（那不呼吸就是能永生了）"
tips["a_little_skill_57"] = r"其实真的有114514.com这个网站（不信你试试）"
tips["a_little_skill_58"] = r"其实这一条小提示因为版本更新被迫删掉了"
tips["a_little_skill_59"] = r"{01}在{02}tips_{03}in_{04}script{05}.txt{06}里{07}面{08}利{09}用{0a}好{0b}颜{0c}色{0d}代{0e}数{0f}可{01}以{02}实{03}现{04}炸{05}裂{06}的{07}效{08}果{\n}上面这一段文字：{\n}{07}在tips_in_script.txt里面利用好颜色代数可以实现炸裂的效果{\n}温馨提示：tip_in_script.txt在data文件夹里"
tips["a_little_skill_60"] = r"十三怀旧和真的啥也不是啊是截然相反的两个人（基本所有要素都可以互补）"
tips["a_little_skill_61"] = r"PAQ是我的老合作伙伴了，但是因为学业问题暂时不能一起合作开发"
tips["a_little_skill_62"] = r"..././././../.、。。、、、、不回家好好看过一个一般规划基本是规划局规划局局工会VG和VG回家办公还会举办{\n}（我们班上的某个sb写的）"
tips["a_little_skill_63"] = r"1.0.9是所有正式开放版本（1.0.1-1.1.0）中唯一更新日志没有写留言的版本"


global localtime

localtime: time.struct_time = time.localtime()

class lunar_struct_time():
    def __init__(self,y,mon,md,h,m,s,z,d,g,l):
        self.tm_year:int=y
        self.tm_mon:int=mon
        self.tm_mday:int=md 
        self.tm_hour:int=h
        self.tm_min:int=m
        self.tm_sec:int=s
        self.tm_zone:str=z
        self.tm_isdst:int=d
        self.tm_gmtoff:int=g
        self.is_leap_month:bool=l


    def __str__(self):
        return "lunar_struct_time("+", ".join([str(i) for i in[
        self.tm_year,
        self.tm_mon,
        self.tm_mday,
        self.tm_hour,
        self.tm_min,
        self.tm_sec,
        self.tm_zone,
        self.tm_isdst,
        self.tm_gmtoff,
        self.is_leap_month]])+")"

        

def lunarlocaltime():
    lt = time.localtime()
    lldt = lunardate.LunarDate.fromSolarDate(lt.tm_year, 
                                             lt.tm_mon, 
                                             lt.tm_mday)
    return lunar_struct_time(
        lldt.year,
        lldt.month,
        lldt.day,
        lt.tm_hour,
        lt.tm_min,
        lt.tm_sec,
        lt.tm_zone,
        lt.tm_isdst,
        lt.tm_gmtoff,
        lldt.isLeapMonth
    )

lunartime = lunarlocaltime()    


special_events:List[Literal["lunar_new_year",
                            "new_year",
                            "lantern_festival",
                            "christmas",
                            "Justnothing_birthday"]]


class SpecialDay():
    def __init__(self,name:str,display_name:str,is_active:bool,tip_context:str,log:Optional[str]=None):
        self.name = name
        self.display_name = display_name
        self.is_active = is_active
        self.tip_context = tip_context
        self.log = f"今天是{self.display_name}，设置特殊提示..." if log is None else log



def _range(start, stop):
    return range(start, stop+1)

special_days = [
    SpecialDay("lunar_new_year", 
               "大年初一", 
               lunartime.tm_mday == lunartime.tm_mon == 1, 
               tips["a_little_tip_lunar_new_year_special"]),
    
    SpecialDay("new_year", 
               "元旦节", 
               localtime.tm_mday == localtime.tm_mon == 1, 
               tips["a_little_tip_new_year_special"]),

    SpecialDay("lantern_festival", 
               "元宵节", 
               (lunartime.tm_mon, lunartime.tm_mday) == (1, 15), 
               tips["a_little_tip_lantern_festival_special"]),

    SpecialDay("christmas", 
               "圣诞节", 
               (localtime.tm_mon, localtime.tm_mday) == (1, 15), 
               tips["a_little_tip_christmas_special"]),

    SpecialDay("JustNothing_birthday", 
               "啥也不是的生日", 
               (localtime.tm_mon, localtime.tm_mday) == (9, 11), 
               tips["a_little_tip_JustNothing_birthday_special"]),
    
    SpecialDay("PAQ_birthday", 
               "PAQ的生日", 
               (localtime.tm_mon, localtime.tm_mday) == (10, 21), 
               tips["a_little_tip_PAQ_birthday_special"]),

    SpecialDay("Nonecoldwind_birthday", 
               "十三怀旧的生日", 
               (localtime.tm_mon, localtime.tm_mday) == (1, 16), 
               tips["a_little_tip_NoneColdWind_birthday_special"]),
    
    SpecialDay("SB1.0_birthday", 
               "SB1.0的生日", 
               (localtime.tm_mon, localtime.tm_mday) == (8, 18), 
               tips["a_little_tip_SB1.0_birthday_special"]),

    SpecialDay("stay_up_late",      # 但是为什么是Special"Day"?
               "熬夜", 
               localtime.tm_hour in range(1, 4+1), 
               tips["a_little_tip_stay_up_late_special"],
               "这么晚了还不睡？已经%d点%d分了，赶紧去睡吧" % (localtime.tm_hour, localtime.tm_min)),

    SpecialDay("tree_planting_day",
               "植树节", 
               (localtime.tm_mon, localtime.tm_mday) == (3, 12), 
               tips["a_little_tip_tree_planting_day_special"]),
    
    SpecialDay("tree_planting_day",
               "植树节", 
               (localtime.tm_mon, localtime.tm_mday) == (3, 12), 
               tips["a_little_tip_tree_planting_day_special"]),

    SpecialDay("tomb_sweeping_day",
               "清明节", 
               (lunartime.tm_mon, lunartime.tm_mday) == (3, 7), 
               tips["a_little_tip_tomb_sweeping_day_special"]),


    SpecialDay("fools_day",
               "愚人节", 
               (localtime.tm_mon, localtime.tm_mday) == (4, 1), 
               tips["a_little_tip_fools_day_special"]),

    SpecialDay("labour_day",
               "劳动节", 
               (localtime.tm_mon, localtime.tm_mday) == (5, 1), 
               tips["a_little_tip_labour_day_special"]),
    
    SpecialDay("teenager_day",
               "青年节", 
               (localtime.tm_mon, localtime.tm_mday) == (5, 4), 
               tips["a_little_tip_teenager_day_special"]),

    SpecialDay("mothers_day",
               "母亲节", 
               (localtime.tm_mon, localtime.tm_mday) == (5, 12), 
               tips["a_little_tip_mothers_day_special"]),

    SpecialDay("tearchers_day",
               "教师节", 
               (localtime.tm_mon, localtime.tm_mday) == (9, 10), 
               tips["a_little_tip_teachers_day_special"])
]

for d in special_days:
    if d.is_active:
        write_log(SCRIPT_FILE_NAME, pid, 1, f"今天是{d.display_name}，设置特殊提示...")
        loadedspecialtips = True
        special_events.append(d.name)
        tips["a_littel_tip_special"] = d.tip_context








# 后面的以后再补上吧
# 也许吧
# 不是sonarlint你有完没完了
# Remove this commented out code.      sonarlint(python:S125)
#
# * 此时的我：
#
# Collecting Image
#   Downloading image-1.5.33.tar.gz (15 kB)
# Collecting pillow
#   Downloading pillow-10.4.0-cp38-cp38-win_amd64.whl (2.6 MB)
#      |████████████████████████████████| 2.6 MB 18 kB/s
# Collecting django
#   Downloading Django-4.2.14-py3-none-any.whl (8.0 MB)
#      |███████████████████████████████▌| 7.8 MB 2 kB/s eta 0:01:48
#
# WARNING: Retrying (Retry(total=4, connect=None, read=None, redirect=None, status=None)) after connection broken by 
# 'ReadTimeoutError("HTTPSConnectionPool(host='pypi.org', port=443): Read timed out. (read timeout=15)")': /simple/six/
#
# 加速器：OHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
#
#
# ？我怎么不知道我写过这些
# 但炸裂的精神状态是每个程序员必备的
import os
from src.init_data import *

_dict = sys.modules["__main__"].__dict__
logging = _dict["logging"]

log_format = "[{}]   {}   {}{}\n"
log_path_format = "%s\\log\\{}.log"%DATA_PATH

"""
把日志模块分开写了，方便管理
"""

SCRIPT_FILE_NAME = f"script:{__name__}"

def _get_time() -> str:
    local_time = time.localtime()
    time_float = str(int((time.time()%1)*1000))

    return f"{local_time.tm_year}/{str(local_time.tm_mon).zfill(2)}/{str(local_time.tm_mday).zfill(2)}_{str(local_time.tm_hour).zfill(2)}:{str(local_time.tm_min).zfill(2)}:{str(local_time.tm_sec).zfill(2)}.{str(time_float).zfill(3)}"

def _get_saving_name():
    local_time = time.localtime()
    return f"{local_time.tm_year}_{str(local_time.tm_mon).zfill(2)}_{str(local_time.tm_mday).zfill(2)}_{str(local_time.tm_hour).zfill(2)}_{str(local_time.tm_min).zfill(2)}_{str(local_time.tm_sec).zfill(2)}"
    

def _exist(filepath:str) -> bool:
    return os.path.exists(filepath)

def _remove_space(string:str):
    string = str(string)
    while string.endswith(" ") or string.endswith("\n") or string.endswith("\r"):
        string = string[0:-1]
    return str(string)

def _text_file_readlines(filepath:str,encodingtype:str="ANSI"):
    reading_file = open(filepath,mode="r",encoding=encodingtype)
    file_content = reading_file.readlines()
    reading_file.close()
    return file_content

def _line_list(inputlist:list,line:int=0):
    reading_line = 0
    return_list = []
    if line <= 0:   
        for reading_line in range(len(inputlist)):    
            return_list.append(inputlist[reading_line])
        return return_list
    else:
        for reading_line in range(len(inputlist)):
            if reading_line == line - 1:
                    return str(inputlist[reading_line])

def _read_file_to_variables(path:str):
    content = _remove_space(_line_list(_text_file_readlines(path),1))
    try:
        content = float(content)
    except:
        pass
    return content

def _write_textfile(targetfile:str,text:str="",encoding:str="gbk",cover:bool=True,turnnumeric:bool=False):
    if not _exist(targetfile):
        writing_file = open(targetfile,mode="a+",encoding=encoding)
        writing_file.close()
    os.chmod(targetfile,0o777)
    if turnnumeric:
        text = str(text)
        if text.count(".") == 1:
            trans0 = text.maketrans("","",".") 
            transstr = text.translate(trans0)
            if transstr.isdigit():
                text = float(text)
            if text%1 == 0:
                text = int(text)
    if cover == True:
        writing_file = open(targetfile,mode="w+",encoding=encoding)
    else:
        writing_file = open(targetfile,mode="a+",encoding=encoding)
    returncode = writing_file.write(str(text))
    writing_file.close()
    return returncode


LOGLEVEL_FILEPATH = f"{SETTING_PATH}\\logging\\logging_level.txt"
try:
    loglevel = _read_file_to_variables(LOGLEVEL_FILEPATH) # 日志记录等级，数字越大记录越详细
    logname = _read_file_to_variables(LOGNAME_FILEPATH)
    if logname == "[default]":
        logpath = str(_get_saving_name())
        logpath = log_path_format.format(logpath)
    else:
        logpath = log_path_format.format(logname)  # 日志路径
        
    if _exist(f"{SETTING_PATH}\\logging\\logging_sign"):logging = True 
    else:logging=False
        
    loglevel = _read_file_to_variables(LOGLEVEL_FILEPATH)
except:
    print("src.log:")
    traceback.print_exc()
    print("日志模块加载失败...请补齐文件或将工具箱放到正确的目录运行（按任意键退出）")
    os.system("pause > nul")
    os._exit(1)
# ----------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------


#写入取日志的函数，参数：（写入者，PID，信息类别，文本）
def write_log(writer:str=SCRIPT_FILE_NAME,writer_pid:int=pid,msgtype:any=1,text:str="默认文本，没什么可看的",writer_max_display_len:int=32):
    """在data\\log中写入名称为当前时间的日志，转到定义看注释\n
    关于msgtype参数所代表的信息类型：\n
    -2 -> 超级调试    ->loglevel大于等于3（超级超级详细的）\n
    -1 -> 详细调试    ->loglevel大于等于2（比较详细）\n
    0  -> 正常调试    ->loglevel大于等于1（相对于详细）\n
    1  -> 普通信息    ->loglevel大于等于0（正常）\n
    2  -> 警告信息    ->loglevel大于等于-1（只显示警告和更高级错误）\n
    3  -> 错误信息    ->loglevel大于等于-2（只显示错误和更高级错误）\n
    4  -> 致命错误    ->loglevel大于等于-3（只显示和更高级错误）\n
    其他->自定义文本  ->loglevel没有要求（不管怎么样都会显示）
    """
    if logging:
        if writer_pid == -1:
            writer_pid = "未知"
        if not _exist(logpath):
            _write_textfile(logpath,"日志是Python记录的，比Bat好用的多\n","UTF-8")
            _write_textfile(logpath,"格式：[时间]                            类型    记录者                      [PID]   信息\n","UTF-8",False)
            subprocess.run("if not exist data\\log md data\\log", shell=True,text=False,capture_output=False)
        writer_and_pid = "%s[%s]"%(writer,writer_pid)
        if len(writer_and_pid) > writer_max_display_len:
            writerlen = writer_max_display_len - 2 - len(str(writer_pid))
            writer = "%s..."%writer[0:writerlen]
            writer_and_pid = "%s[%s]"%(writer,writer_pid)

        writer_and_pid = writer_and_pid.ljust(32," ")
        for line in text.splitlines():
            if msgtype == 1:
                if loglevel >=  0:_write_textfile(logpath,log_format.format(_get_time(),"信息",writer_and_pid,line),"UTF-8",False)
            elif msgtype == 2:
                if loglevel >= -1:_write_textfile(logpath,log_format.format(_get_time(),"警告",writer_and_pid,line),"UTF-8",False)
            elif msgtype == 3:
                if loglevel >= -2:_write_textfile(logpath,log_format.format(_get_time(),"错误",writer_and_pid,line),"UTF-8",False)
            elif msgtype == 4:
                if loglevel >= -3:_write_textfile(logpath,log_format.format(_get_time(),"严重",writer_and_pid,line),"UTF-8",False)
            elif msgtype == 0:
                if loglevel >= 1 :_write_textfile(logpath,log_format.format(_get_time(),"调试",writer_and_pid,line),"UTF-8",False)
            elif msgtype == -1:
                if loglevel >= 2 :_write_textfile(logpath,log_format.format(_get_time(),"详细",writer_and_pid,line),"UTF-8",False)
            elif msgtype == -2:
                if loglevel >= 3 :_write_textfile(logpath,log_format.format(_get_time(),"极详",writer_and_pid,line),"UTF-8",False)
            else:
                _write_textfile(logpath,log_format.format(_get_time(),msgtype,writer_and_pid,line),"UTF-8",False)

write_log(SCRIPT_FILE_NAME,pid,1,"日志模块已被初步加载。")       
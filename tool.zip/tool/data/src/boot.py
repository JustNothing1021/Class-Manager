
"""工具箱，启动！"""

import sys

from src.init_utils import *
from src.features import get_started 


SCRIPT_FILE_NAME = f"script:{__name__}"


update_list = [
    BIN_PATH,
    SETTING_PATH,
    FILE_PATH,
] + [DATA_PATH + "\\" + item
    for item in [
        "debugging",
        "others",
        "*.txt"
    ]
]

def update_file_list(update_list:list=update_list) -> list:
    "更新长文件列表。"
    file_list = []
    return_list = []
    for file in update_list:
        file_list += remove_in_list(run_command(f"dir {file} /s /b",silent=True,encoding="ansi").splitlines())
    for item in file_list:
        return_list.append(item[len(cwd)+1:])
    return return_list

        






def main():
    global options, debugmode, showskillcontent, logging, firststart, lastupdate, versionname
    global showstartcompletedpercent, showeditor, preloadtips, startwithadmin, enablecoloredtext
    global menuloadanimation
    global start_total_task
    global console, error_console, debug_console
    global spinner_name, rule_character, default_color, desc_color, selected_color
    global success_color, value_color, info_color, warn_color, err_color, pause_color
    global debug_info_color, debug_warn_color, debug_err_color, debug_fatal_color
    global debug_debug_color, debug_extde_color, debug_supde_color
    global SCRIPT_FILE_NAME, OPTIONS_FILE_NAME, CACHE_PATH, DATA_PATH
    global SETTING_PATH, EXTENSION_PATH, APK_COPY_PATH, APK_PUSH_PATH
    global MODULE_PUSH_PATH, PATCH_SCRIPT_PATH, WIRELESS_PORT, IMPORTABLE
    global LOGLEVEL_FILEPATH
    global B_in_1KB, KB_in_1MB, MB_in_1GB
    global MENU_ANIM_DELAY, DEFAULT_CODE_PAGE, CODE_NAME
    global ListPrompt_style, ListPrompt_pointer, ListPrompt_annotation, close_tag
    global on_running_code_page
    global inputmsg
    global windowcharwidth, startedtimes
    global cecho_not_exist, tips, checkfiles, cant_use_install_edxposed, loadedspecialtips
    global adb_features_broken, fh_features_broken, basic_features_broken
    global running_on_win11, special_events, number_of_skills, tip_file_missed
    global loaded_tips, checkfiles_nextstart
    global device_sn_args, cmd_environment_variables, pid, cwd, output
    global progress
    global support_error_desc
    global localtime

    try:

        while True:

            cls()
            
            on_start(_globals=globals(), _locals=locals())

            os.chmod(cwd, 0o777)

            # 运行环境检查
            assert "win" in sys.platform, "本工具箱仅适用于windows平台..."
            assert 1 + 1 == 2, "1+1不等于2？？数学不存在了"# 我好无聊啊

            python_version = sysconfig.get_python_version()
            write_log(SCRIPT_FILE_NAME, pid, 1, f"当前运行的Python版本：{python_version}")

            if len(sys.argv) == 0:
                write_log(SCRIPT_FILE_NAME, pid, 1, "未获取到命令行参数")
            else:
                write_log(SCRIPT_FILE_NAME, pid, 1,
                          f"获取到的命令行参数：本身路径（{sys.argv}），其他参数：{sys.argv[1::1]}（共计{len(sys.argv) - 1}个）")

            if __name__ != "src.boot":
                if IMPORTABLE:
                    write_log(SCRIPT_FILE_NAME, pid, 2, "当前是被作为模块[%s]调用，将会跳出主程序" % __name__)
                    break
                else:
                    raise Script.Exceptions.Functions.NotRunningAsMainError("未知的运行名称：%s" % __name__)

            with progress:
                split_line("启动中")
                console.print(f"{info_color}启动中，请稍等...")
                if showstartcompletedpercent: start_total_task = progress.add_task(f"{info_color}启动中                ",
                                                                                   total=100)

                title("真的啥也不是啊的工具箱-正在启动")
                write_log(SCRIPT_FILE_NAME, pid, 1, f"工具箱，启动！(时间为{starttime_str},{starttime})")

                # 将已经启动的次数增加1
                startedtimes = read_file_to_variables(f"{SETTING_PATH}\\started_times.txt")
                write_log(SCRIPT_FILE_NAME, pid, 1, f"读取{SETTING_PATH}\\started_times.txt作为启动次数...")
                try:
                    startedtimes = float(startedtimes)
                    startedtimes += 1.0
                except:  # 文件没了/空了就重置启动次数为1
                    write_log(SCRIPT_FILE_NAME, pid, 3, "启动次数记录文本中的内容无效...将会重置启动次数为1.0")
                    show_msgbox("错误", "记录启动次数的文本文档损坏了...将会重置为第一次启动（按任意键继续）")
                    os.system("pause > nul")
                    startedtimes = 1.0

                write_log(SCRIPT_FILE_NAME, pid, 1, f"这是第{int(startedtimes)}次启动了，加油，不要爆炸")
                write_textfile(f"{SETTING_PATH}\\started_times.txt", startedtimes)  # 保存数据
                if (startedtimes + 1) % 10 == 0:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "下次启动将会检查文件。")
                    checkfiles_nextstart = True

                showstartcompletedpercent = Script.Flag.get_status(show_percent_flag)
                # 其实也可以直接 show_percent_flag.get_status() 的，但是编译器不显示（我有强迫症）
                # 为什么不显示？因为他______
                # 忘记写声明了（补上了）
                checkfiles = Script.Flag.get_status(check_file_flag)
                firststart = Script.Flag.get_status(first_start_flag)
                preloadtips = Script.Flag.get_status(pre_load_tips_flag)
                if Script.Flag.get_status(write_log_flag) == False:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "日志记录标志文件不存在，将会关闭日志记录...")
                    logging = False
                else:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "日志记录标志文件存在，将继续日志记录...")
                    logging = True

                write_log(SCRIPT_FILE_NAME, pid, 1, "切换代码页到%s..." % DEFAULT_CODE_PAGE)
                result = chcp(DEFAULT_CODE_PAGE)
                if result == 1:
                    show_msgbox("警告", "代码页切换失败...可能会出现未知问题")
                    print("(按任意键继续)")
                    os.system("pause > nul")
                    write_log(SCRIPT_FILE_NAME, pid, 2, "代码页切换失败，可能会出现未知问题...")
                else:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "代码页切换完成。")
                # 如果系统信息未知就获取一下系统版本
                if firststart:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "获取当前运行的windows版本...")
                    if showstartcompletedpercent:
                        sub_task = progress.add_task(f"{info_color}获取系统信息", 1)
                        progress.advance(start_total_task, 0)
                    else:
                        print("获取系统信息...")
                    platform = sys.platform
                    windows_version = subprocess.getoutput("systeminfo /FO CSV").splitlines()[1].split(",")[1]
                    write_textfile(f"{SETTING_PATH}\\windows_version.txt", windows_version)
                    write_textfile(f"{SETTING_PATH}\\platform.txt", platform)


                    if "Windows 11" in windows_version:
                        running_on_win11_flag.change_status(True)
                    else:
                        running_on_win11_flag.change_status(False)
                    
                    if showstartcompletedpercent: progress.remove_task(sub_task)


    
                if running_on_win11_flag.get_status():
                    write_log(SCRIPT_FILE_NAME, pid, 1, "%s\\running_on_WIN11.sign存在，设置为在win11上运行..." % SETTING_PATH)
                    running_on_win11 = True
                else:
                    write_log(SCRIPT_FILE_NAME, pid, 1,
                              "%s\\running_on_WIN11.sign不存在，设置为不在win11上运行..." % SETTING_PATH)
                    running_on_win11 = False
                # 同步当前路径到指定文件
                write_log(SCRIPT_FILE_NAME, pid, 1,
                          f"同步当前路径({cwd})至文件{EXTENSION_PATH}\\data\\current_directory(1/2)...")
                if showstartcompletedpercent:
                    sub_task = progress.add_task(f"{info_color}同步路径", 2)
                    progress.advance(start_total_task, 3)
                    progress.advance(sub_task)
                else:
                    print("同步路径...")
                write_textfile(F"{EXTENSION_PATH}\\\data\\current_directory", cwd, "ANSI", cover=True)
                write_log(SCRIPT_FILE_NAME, pid, 1, f"同步路径至文件{BIN_PATH}\\modules\\current_directory(2/2)...")
                if showstartcompletedpercent:
                    progress.advance(start_total_task, 3)
                    progress.advance(sub_task)
                write_textfile(F"{BIN_PATH}\\modules\\current_directory", cwd, "ANSI", cover=True)

                write_log(SCRIPT_FILE_NAME, pid, 1, "开始读取%s..." % OPTIONS_FILE_NAME)

                # 寻找预加载提示文本的标志文件
                if showstartcompletedpercent:
                    progress.remove_task(sub_task)
                    sub_task = progress.add_task(f"{info_color}初始化数据", 2)
                    progress.advance(start_total_task, 4)
                    progress.advance(sub_task)
                else:
                    print("查看文件...")

                if preloadtips:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "此次需要读取提示文本...")
                    if checkfiles:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "此次启动将会检查文件...")
                        tips_num = read_file_to_variables(
                            f"{SETTING_PATH}\\number_of_skills.txt")  # tips_in_script.txt中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"tips_in_script.txt中的项目数：{tips_num}")
                        options_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_props.txt")  # 配置文件中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"{OPTIONS_FILE_NAME}中的项目数：{options_num}")
                        file_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_files.txt")  # file_list.txt中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"file_list.txt中的项目数：{file_num}")
                        file_percent = file_num + 3
                        tips_percent = round((100 - file_percent) * tips_num / (options_num + tips_num))
                        options_percent = 100 - tips_percent - file_percent
                        write_log(SCRIPT_FILE_NAME, pid, -1,
                                  f"{OPTIONS_FILE_NAME},file_list.txt,tips_in_script.txt的占比：{options_percent}:{file_percent}:{tips_percent}")
                    else:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "此次启动不会检查文件...")
                        tips_num = read_file_to_variables(
                            f"{SETTING_PATH}\\number_of_skills.txt")  # tips_in_script.txt中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"tips_in_script.txt中的项目数：{tips_num}")
                        options_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_props.txt")  # 配置文件中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"{OPTIONS_FILE_NAME}中的项目数：{options_num}")
                        tips_percent = round(100 * tips_num / (options_num + tips_num))
                        options_percent = 100 - tips_percent
                        write_log(SCRIPT_FILE_NAME, pid, -1,
                                  f"{OPTIONS_FILE_NAME},tips_in_script.txt的占比: {options_percent}:{tips_percent}")
                else:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "此次启动不需要读取提示文本...")
                    if checkfiles:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "此次启动会检查文件...")
                        loaded_tips = False
                        file_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_files.txt")  # file_list.txt中文本行数的总和
                        file_percent = file_num + 3
                        options_percent = 100 - file_percent
                    else:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次启动不会检查文件...")
                        options_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_props.txt")
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"{OPTIONS_FILE_NAME}中的项目数：{options_num}（占比100）")
                        options_percent = 100


                # 读取配置文档
                if showstartcompletedpercent:
                    progress.remove_task(sub_task)
                    progress.advance(start_total_task, 5)
                else:
                    print(f"读取{OPTIONS_FILE_NAME}...")
                nowtime = time.time()
                write_log(SCRIPT_FILE_NAME, pid, 1, "开始读取%s，时间戳:%s" % (OPTIONS_FILE_NAME, nowtime))
                options = read_variable_file(OPTIONS_FILE_NAME, stagename=f"读取{OPTIONS_FILE_NAME}",
                                             globalprogressrange=(15, options_percent),starttotaltask=start_total_task)
                if options == -1:  # 配置文档不存在时
                    write_log(SCRIPT_FILE_NAME, pid, 3, "聪明，%s不见了，将会询问用户是否修复" % OPTIONS_FILE_NAME)
                    show_msgbox("出错了！",
                                "文件夹中的%s（配置文件）不见了...\n需要修复它来重新启动，但是所有数据将会重置。" % OPTIONS_FILE_NAME,
                                clearscreen=True)
                    print("需要继续吗？")
                    if confirm_prompt(default_select=True):
                        write_log(SCRIPT_FILE_NAME, pid, 1, "开始修复%s..." % OPTIONS_FILE_NAME)
                        update_options(BASE_OPTIONS, "add", "firststart", True, OPTIONS_FILE_NAME,
                                       "//这东西先前f炸过一次（鬼晓得什么原因）\n//修复时间：%s(%s)" % (
                                       get_time(), time.time()))
                        write_log(SCRIPT_FILE_NAME, pid, 1, "重置标志状态...")
                        show_percent_flag.change_status(True)
                        pre_load_tips_flag.change_status(False)
                        check_file_flag.change_status(False)
                        write_log(SCRIPT_FILE_NAME, pid, 1, "修复完成！")
                        print("修复完成，按任意键重新启动应该就可以了（大概吧）")
                        os.system("pause > nul")
                        continue
                    else:
                        print("行吧，那么按任意键退出")
                        pause()
                        exit(0)
                else:
                    c = ""
                    for i in options.keys():
                        key = str(i)
                        value = options[i]
                        if value == True or value == False:
                            command = str("%s=%s" % (key, value))
                            c2 = str("setvar_toall('%s',%s)" % (key, value))
                        else:
                            value = str(value)
                            command = str("%s='%s'" % (key, value))
                            c2 = str("setvar_toall('%s','%s')" % (key, value))
                        c += command + "\n" + c2 + "\n"
                exec(c)
                try:
                    debugmode = options["debugmode"]
                    showskillcontent = options["showskillcontent"]
                    logging = options["logging"]
                    firststart = options["firststart"]
                    lastupdate = options["lastupdate"]
                    versionname = options["versionname"]
                    showstartcompletedpercent = options["showstartcompletedpercent"]
                    showeditor = options["showeditor"]
                    preloadtips = options["preloadtips"]
                    menuloadanimation = options["menuloadanimation"]
                    checkfiles = options["checkfiles"]
                    adbserverport = options["adbserverport"]
                    noflashlight = options["noflashlight"]
                except KeyError:
                    pass
                readoptionstime = time.time() - nowtime  # 计算时间
                readoptionspeed = len(options) / readoptionstime  # 计算读取速度
                write_log(SCRIPT_FILE_NAME, pid, 1, "读取%s完毕，%s秒内读取了%s条（%s条/秒）" % \
                          (OPTIONS_FILE_NAME, readoptionstime, len(options), readoptionspeed))

                # 修改标志文件和options.ini不同步的情况

                # 检查文件的配置
                check_file_flag.change_status(checkfiles)

                # 预读取提示文本的配置
                pre_load_tips_flag.change_status(preloadtips)

                # 重新更新启动进度的计算
                if showstartcompletedpercent:
                    sub_task = progress.add_task(f"{info_color}更新进度", total=1)
                    progress.advance(start_total_task, options_percent - 15)
                    progress.advance(sub_task)
                if preloadtips:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次需要读取提示文本...")
                    if checkfiles:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次启动将会检查文件...")
                        tips_num = read_file_to_variables(
                            f"{SETTING_PATH}\\number_of_skills.txt")  # tips_in_script.txt中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"tips_in_script.txt中的项目数：{tips_num}")
                        options_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_props.txt")  # 配置文件中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"{OPTIONS_FILE_NAME}中的项目数：{options_num}")
                        file_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_files.txt")  # file_list.txt中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"file_list.txt中的项目数：{file_num}")
                        file_percent = file_num + 3
                        tips_percent = round((100 - file_percent) * tips_num / (options_num + tips_num))
                        options_percent = 100 - tips_percent - file_percent
                        write_log(SCRIPT_FILE_NAME, pid, -1,
                                  f"{OPTIONS_FILE_NAME},file_list.txt,tips_in_script.txt的占比：{options_percent}:{file_percent}:{tips_percent}")
                    else:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次启动不会检查文件...")
                        tips_num = read_file_to_variables(
                            f"{SETTING_PATH}\\number_of_skills.txt")  # tips_in_script.txt中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"tips_in_script.txt中的项目数：{tips_num}")
                        options_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_props.txt")  # 配置文件中文本行数的总和
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"{OPTIONS_FILE_NAME}中的项目数：{options_num}")
                        tips_percent = round(100 * tips_num / (options_num + tips_num))
                        options_percent = 100 - tips_percent
                        write_log(SCRIPT_FILE_NAME, pid, -1,
                                  f"{OPTIONS_FILE_NAME},tips_in_script.txt的占比: {options_percent}:{tips_percent}")
                else:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次启动不需要读取提示文本...")
                    if checkfiles:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次启动会检查文件...")
                        loaded_tips = False
                        file_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_files.txt")  # file_list.txt中文本行数的总和
                        file_percent = file_num + 3
                        options_percent = 100 - file_percent
                    else:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "更新配置，此次启动不会检查文件...")
                        options_num = read_file_to_variables(f"{SETTING_PATH}\\number_of_props.txt")
                        write_log(SCRIPT_FILE_NAME, pid, -1, f"{OPTIONS_FILE_NAME}中的项目数：{options_num}（占比100）")
                        options_percent = 100

                if showstartcompletedpercent:
                    progress.remove_task(sub_task)

                if checkfiles:
                    sub_task = progress.add_task("校验文件",total=100)
                    sub_task_2 = progress.add_task("读取列表",total=1)
                    file_list = read_textfile(f"{DATA_PATH}\\file_list.txt").splitlines()
                    progress.advance(sub_task,20)
                    progress.advance(sub_task_2)
                    progress.remove_task(sub_task_2)
                    sub_task_2 = progress.add_task("校验文件",len(file_list))
                    missed = []
                    for file in file_list:
                        if not exist(file):
                            missed.append(file)
                        progress.advance(sub_task,80*(1/len(file_list)))
                        progress.advance(sub_task_2)
                        try:
                            tips_percent
                        except:
                            tips_percent = 0
                        progress.advance(start_total_task,(100-tips_percent-options_percent)/len(file_list))
                    progress.remove_task(sub_task)
                    progress.remove_task(sub_task_2)





                # 调整日志记录开关的状态
                if logging == True:
                    write_log_flag.change_status(True)
                else:
                    write_log_flag.change_status(False)

                if first_start_flag.get_status():  # 首次启动标志
                    firststart = True
                    write_log(SCRIPT_FILE_NAME, pid, 1, "first_start_sign存在，此次为第一次启动。")
                else:
                    if firststart == True:
                        first_start_flag.change_status(True)
                        write_log(SCRIPT_FILE_NAME, pid, 1,
                                  "first_start_sign不存在，但在%s中firststart为True，所以此次可能为第一次启动。" % OPTIONS_FILE_NAME)
                    else:
                        write_log(SCRIPT_FILE_NAME, pid, 1,
                                  "first_start_sign不存在，%s中firststart也为False，所以此次不为第一次启动。" % OPTIONS_FILE_NAME)

                write_textfile("%s\\number_of_props.txt" % SETTING_PATH, str(len(options)))

                if firststart: write_log(SCRIPT_FILE_NAME, pid, 1, "首次启动，跳过读取提示文本")
                if preloadtips and not firststart:
                    nowtime = time.time()
                    if not showstartcompletedpercent: print("读取tips_in_script.txt...")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "开始读取tips_in_script.txt，时间戳:%s" % (nowtime))
                    tips_read = read_variable_file(f"{DATA_PATH}\\tips_in_script.txt", stagename="读取tips_in_script.txt",
                                                   globalprogressrange=(100 - tips_percent, 100),starttotaltask=start_total_task)
                    if tips_read == -1:  # 提示文本不存在时
                        write_log(SCRIPT_FILE_NAME, pid, 2, "没有检测到tips_in_script.txt，将会通知用户")
                        show_msgbox("警告",
                                    "data\\tips_in_script.txt不见了...\n可能会出现某些未知问题（懒得去探索那些bug）")
                        os.system("pause>nul")
                    else:
                        for key in tips_read.keys():
                            tips[key] = tips_read[key]
                        number_of_skills = 0
                        loaded_tips = True
                        for i in tips.keys():
                            key = str(i)
                            value = tips[i]
                            if "a_little_skill_" in key:
                                number_of_skills += 1
                            if value == True or value == False:
                                command = str("%s=%s" % (key, value))
                            else:
                                value = str(value)
                                command = str("%s='%s'" % (key, value))
                            try:
                                exec(f"global {key}")
                                exec(command)
                            except:
                                pass
                    readtipstime = time.time() - nowtime  # 计算时间
                    readtipspeed = len(tips) / readtipstime  # 计算读取速度
                    write_log(SCRIPT_FILE_NAME, pid, 1,
                              f"共计{number_of_skills}条小技巧，写入{SETTING_PATH}\\number_of_skills.txt")
                    write_textfile(f"{SETTING_PATH}\\number_of_skills.txt", str(number_of_skills))
                    write_log(SCRIPT_FILE_NAME, pid, 1, "读取tips_in_script.txt完毕，%s秒内读取了%s条（%s条/秒）" % \
                              (readtipstime, len(tips), readtipspeed))
                else:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "preloadtips=False，将会移除pre-load_tip_text_sign")
                    if exist("%s\\pre-load_tip_text_sign" % SETTING_PATH): os.remove(
                        "%s\\pre-load_tip_text_sign" % SETTING_PATH)
                if showstartcompletedpercent: progress.update(start_total_task, completed=100)



                if firststart:  # 第一次启动时
                    write_log(SCRIPT_FILE_NAME, pid, 1, "首次启动，重置用户设置...")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "重置启动次数...")
                    startedtimes = 0.0
                    write_textfile("%s\\started_times.txt" % SETTING_PATH, "0.0")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "重置运行系统版本的设置...")
                    if exist("%s\\running_on_WIN11.sign" % SETTING_PATH): os.remove("%s\\running_on_WIN11.sign" % SETTING_PATH)
                    if exist("%s\\not_running_on_WIN11.sign" % SETTING_PATH): os.remove(
                        "%s\\not_running_on_WIN11.sign" % SETTING_PATH)
                    write_log(SCRIPT_FILE_NAME, pid, 1, "重置无线连接记录...")
                    write_textfile("%s\\wireless_adb_ip.txt" % SETTING_PATH, "unknown")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "重置关闭日志记录的提示设置为始终显示...")
                    write_textfile("%s\\turn_off_logging_tip.txt" % SETTING_PATH, "show")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "重置缺失文件的提示设置为始终显示...")
                    write_textfile("%s\\file_missing_tip.txt" % SETTING_PATH, "show")

                    # 使用前的设置
                    progress.stop()
                    write_log(SCRIPT_FILE_NAME, pid, 1, "进入设置和用前须知")    
                    cls()
                    try:
                        set_variables_from_dict(get_started.set_settings())
                    except TypeError:
                        pass
                    continue

                # 启动adb服务

                if showstartcompletedpercent:
                    sub_task = progress.add_task("启动adb服务", total=1)
                else:
                    print("启动ADB服务...")

                
                if (int(adbserverport) != 5037 or int(options["adbserverport"])!=5037):
                    cmd_environment_variables["ANDROID_ADB_SERVER_PORT"] = adbserverport
                    print("(端口号已更改为%s)" % adbserverport)
                    change_adb_server_port(adbserverport)
                output = run_command("adb start-server", "ansi")
                if "* daemon started successfully" not in output and output != "" and "List" not in output:
                    write_log(SCRIPT_FILE_NAME, pid, 2, "adb服务可能没有正常启动...")
                    print("adb服务可能没有正常启动...（按任意键继续）")
                    pause(False)
                elif "failed to start daemon" in output:
                    write_log(SCRIPT_FILE_NAME, pid, 3, "adb服务启动失败...")
                    print("adb服务启动失败...请尝试用功能7-2-6修复")
                    pause(False)
                if showstartcompletedpercent:
                    progress.advance(sub_task, 1)
                    time.sleep(0.1)
                    progress.remove_task(sub_task)

                ################## 启动完成
                if checkfiles and len(missed):
                    write_log(msgtype=2,text="检测到文件丢失，提示用户，列表:\n"+'\n'.join(missed))
                    show_msgbox(warn_color+"警告",
                        tip_color+"当前检测到有以下文件丢失：\n\n─────────────────────\n" + "\n".join(missed) +
                        f"\n(共计{value_color}{len(missed)}{close_tag}个)\n─────────────────────\n{warn_color}可能影响到工具箱运行，建议补全文件",
                        use_console=True,
                        color=warn_color)
                    pause()
                checkfiles = False
                update_options(options,"add","checkfiles",False)

                on_boot_up_finished(_globals=globals(), _locals=locals())
                boottotaltime = time.time() - starttime

                console.print(f"{success_color}完成！")
                write_log(SCRIPT_FILE_NAME, pid, 1, "启动完成！")
                console.print(f"{info_color}──────────────────启动速度──────────────────")
                console.print(f"{info_color}启动花费时间：{tip_color}{round(boottotaltime, 5)}秒")
                console.print(
                    f"{info_color}读取{value_color}{OPTIONS_FILE_NAME}{close_tag}的速度：{tip_color}{round(readoptionspeed, 4)}{close_tag}条/秒")
                if preloadtips == True: console.print(
                    f"{info_color}读取{value_color}tips_in_script.txt{close_tag}的速度：{tip_color}{round(readtipspeed, 4)}{close_tag}条/秒")
                write_log(SCRIPT_FILE_NAME, pid, 1, "读取%s的速度：%s条/秒" % (OPTIONS_FILE_NAME, round(readoptionspeed, 4)))
                if preloadtips == True: write_log(SCRIPT_FILE_NAME, pid, 1,
                                                  "读取tips_in_script.txt的速度：%s条/秒" % (round(readtipspeed, 4)))
                if preloadtips == True:
                    readfileavgspeed = (readoptionspeed + readtipspeed) / 2
                else:
                    readfileavgspeed = readoptionspeed

                if readfileavgspeed >= 200:
                    print("这速度是真的离谱")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度高的离谱的有点过分")
                elif readfileavgspeed >= 100 and readfileavgspeed < 200:
                    print("这速度已经非常快了")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度非常非常高了")
                elif readfileavgspeed >= 50 and readfileavgspeed < 100:
                    print("这速度已经很快了")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度已经算很高很高的了")
                elif readfileavgspeed >= 20 and readfileavgspeed < 50:
                    print("这速度已经相当快了")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度是相当的高")
                elif readfileavgspeed >= 10 and readfileavgspeed < 20:
                    print("这速度算比较快的")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度算快的了")
                elif readfileavgspeed >= 5 and readfileavgspeed < 10:
                    print("这速度算正常")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度算中等偏上的")
                elif readfileavgspeed >= 3 and readfileavgspeed < 5:
                    print("这速度有一些慢")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度和我家电脑差不多，应该算慢的")
                elif readfileavgspeed >= 2 and readfileavgspeed < 3:
                    print("这速度相当慢了")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度是相当慢")
                elif readfileavgspeed >= 1 and readfileavgspeed < 2:
                    print("这速度非常慢了")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度非常慢了")
                elif readfileavgspeed < 1:
                    print("这速度还不是一般的慢")
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这速度慢得离谱")
                split_line("")
                if read_file_to_variables(
                        "%s\\turn_off_logging_tip.txt" % SETTING_PATH) != "never_show":  # 如果这里面是never_show就不再展示了
                    if readfileavgspeed <= 5 and logging == True:
                        write_log(SCRIPT_FILE_NAME, pid, 1, "这启动速度有点慢，将会询问用户是否调整日志设置")
                        progress.stop()
                        print(
                            "当前的启动速度有些慢，是否需要关闭日志或者降低日志等级来提升速度？")
                        inputmsg = "null"
                        inputmsg = str(ListPrompt("当前的启动速度有些慢，是否需要关闭日志或者降低日志等级来提升速度？",
                                                  [Choice("关闭日志记录","off"),
                                                   Choice("更改日志记录等级","level"),
                                                   Choice("算了，这次不做更改吧","skip"),
                                                   Choice("不要，以后别来烦我","ignore")],
                                                   pointer=ListPrompt_pointer,
                                                   annotation=ListPrompt_annotation).prompt(style=ListPrompt_style).data)
                        if inputmsg.upper() == "OFF":
                            write_log(SCRIPT_FILE_NAME, pid, 1, "用户意在关闭日志记录，将会关闭日志记录...")
                            update_options(options, "add", "logging", False, OPTIONS_FILE_NAME)
                            logging = False
                            print("已经成功关闭日志记录，在功能7-11-3可以重新打开！")
                        elif inputmsg.upper() == "LEVEL":
                            show_msgbox("更改loglevel", "更改这个选项可以适当平衡日志记录和运行速度。")
                            print("想要将日志记录等级更新为什么？（当前的loglevel:%d）" % loglevel)
                            # 飞出天际的文本描述 ->
                            print(
                                """loglevel大于等于3：超级详细的日志记录，记录到超级调试\nloglevel大于等于2：详细，记录到详细调试\nloglevel大于等于1：相对于详细，记录到调试\nloglevel等于0：正常，记录到信息\nloglevel等于-1：只显示警告和更高级错误\nloglevel等于-2：只显示错误和更高级错误\nloglevel等于-3：只显示致命错误，最快，但出错就基本没救了\nloglevel为更小：算了，直接不记录了""")
                            inputmsg = "null"
                            inputmsg = int(input_prompt("你的选项：",
                                       validator=lambda string:string.isdigit(),
                                       error_message="输入不符合标准！"))
                            loglevel = int(inputmsg)
                            write_textfile(LOGLEVEL_FILEPATH, inputmsg)
                            console.print(success_color+"更改完成！")


                        elif inputmsg.upper() == "IGNORE":
                            print("将不再显示此提示，在功能7-11中可以更改这些设置选项！")
                            write_textfile("%s\\turn_off_logging_tip.txt" % SETTING_PATH, "never_show")


                if showstartcompletedpercent:
                    progress.remove_task(start_total_task)
                    progress.stop()


                if startedtimes == 10:  # 第10次启动时
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这是工具箱第十次启动了，记录一下")
                    print("这是你第十次启动了，有什么问题或者发现什么bug都可以跟我说哦（按任意键继续）")
                    pause(showtext=False)
                if startedtimes == 50:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这是工具箱第五十次启动了，记录一下")
                    print("这是你第五十次启动了，看来也算是个忠实的用户了（按任意键继续）")
                    pause(showtext=False)
                if startedtimes == 100:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这是工具箱第一百次启动了，但是真的有人会触发这一条吗")
                    print(
                        "这是你第一百次启动了，说实话我从来不觉得这个提示能被触发，但是如果你真的触发了...谢谢你的支持（按任意键继续）")
                    pause(showtext=False)
                if startedtimes >= 100:
                    write_log(SCRIPT_FILE_NAME, pid, 1, "这是工具箱大于第100次启动了")
                    print("老忠实用户了，对吧")
                
                # 从某种意义上说这条提示就是给我自己设计的，但是似乎没什么用（我已经看过114514遍了）
                if "stay_up_late" in special_events:
                    pause(tip_color+f"这么晚了还不睡？已经{warn_color}{localtime.tm_hour}点{localtime.tm_min}分{close_tag}了，赶紧去睡吧（如果还是不想睡，按任意键继续）")
                # 莫名其妙，就像自己是记忆共同但无法互相控制且截然不同的两个人
                # 我写的代码都会有两种风格（比如写这行注释的我就喜欢f-string，另一个喜欢用格式化控制符）
                # 这句注释也只是写给自己看的，大多数都是（就是闲的没事写的）
                

                

                if checkfiles_nextstart:
                    update_options(options, "add", "checkfiles", True)
                    checkfiles = True
                    special_events.append("check_files_nextstart")

                check_file_flag.change_status(checkfiles)
                show_percent_flag.change_status(showstartcompletedpercent)



    
            break
        gls = globals()
        for key in locals():
            gls[key] = locals()[key]
        return gls
    except:
        console.print(err_color+"出错了！")
        raise

from src.init_base_utils import *
from subprocess import list2cmdline
import queue
"基于命令行的函数（有小部分是不依赖但与其有关）"

rs = lambda s:s if s != None else ""

class CommandOutput(NamedTuple):
    stdout:str
    stderr:str
    returncode:int
    pid:int





def run_base_command(args:Union[str, list],
                 show_output:bool=True,
                 encoding:str="gbk",
                 cwd:Optional[str]=None,
                 sync_update_bit:int=1):
    "最基本的执行命令，采用了世界上最脑溢血的写法"
    global _stdout_sb, _stderr_sb, _popen
    global _outprt_pointer, _errprt_pointer
    _popen = subprocess.Popen(args,
                            stdin = sys.stdin,
                            stdout = subprocess.PIPE,
                            stderr = subprocess.PIPE,
                            cwd=cwd,
                            encoding=encoding,
                            bufsize=sync_update_bit,
                            shell=True,
                            errors=UnicodeDecodeError_Handle)
    _stdout_sb = ""
    _stderr_sb = ""
    _outprt_pointer = 0
    _errprt_pointer = 0
    def _write():
        global _stderr_sb, _stdout_sb
        global _outprt_pointer, _errprt_pointer

        while not(len(_stdout_sb)<=_outprt_pointer and
                 len(_stderr_sb)<=_errprt_pointer) or _popen.poll() == None:
            
                if len(_stdout_sb)>_outprt_pointer:
                    _written = len(_stdout_sb)
                    if show_output:sys.stdout.write(_stdout_sb[_outprt_pointer:_written])
                    _outprt_pointer = _written

                if len(_stderr_sb)>_errprt_pointer:
                    _written = len(_stderr_sb)
                    if show_output:sys.stderr.write(_stderr_sb[_errprt_pointer:_written])
                    _errprt_pointer = _written
                
        
    t = Thread(target=_write)
    t.start()

    def _read_stdout():
        global _stdout_sb, _popen
        while True:
            try:
                c = _popen.stdout.read(sync_update_bit)
            except:
                c = "?"

            if c == "" and _popen.poll() is not None:
                return
            _stdout_sb += c
            

    def _read_stderr():
        global _stderr_sb, _popen
        while True:
            try:
                c = _popen.stderr.read(sync_update_bit)
            except:
                c = "?"

            if c == "" and _popen.poll() is not None:
                return
            _stderr_sb += c

    out_reader = Thread(target=_read_stdout)
    err_reader = Thread(target=_read_stderr)
    out_reader.start()
    err_reader.start()

    while (_popen.poll() == None) or (out_reader.is_alive() and err_reader.is_alive()):
        "就这等着吧"
    

    pid = _popen.pid
    returncode = _popen.returncode
    sys.stdout.flush()
    sys.stderr.flush()

    while t.isAlive(): "等待直到输出线程结束（真的等不了了也得等）"

    return CommandOutput(rs(_stdout_sb), rs(_stderr_sb), returncode, pid)




def run_adb_shell_command(args:Union[list,str]="adb shell",
                          coding:str="utf-8",
                          stdin=subprocess.PIPE,
                          stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,
                          show_output=True,
                          silent_when_wait:bool=False):
    "执行仅一行shell命令（不是adb shell就没必要用这个）"
    wait_for_device(showtext=not silent_when_wait)
    if isinstance(args,list):
        cmd, shell = parse_adb_shell_args(args)
        str_shell_args = " ".join(shell)
    else:
        cmd = args.split("shell",1)[0]+"shell"
        shell = args.split("shell",1)[1]


    write_log(SCRIPT_FILE_NAME,pid,1,"再次解析：adb:<"+str(cmd)+"> shell:<"+str_shell_args+">")
    if "\n" in [s for s in args]:
        raise AttributeError("只能执行一行shell命令！")
    
    shell_obj = subprocess.Popen(f"{BIN_PATH}\\adb.exe shell",
                                 shell=True,
                                 stdin=stdin,
                                 stdout=stdout,
                                 stderr=stderr)
    shell_obj.stdin.write("su -v\n".encode(coding))    # 正常应该秒回
    shell_obj.stdin.write("exit\n".encode(coding))

    try:
        shell_obj.communicate(timeout=3)
        shell_obj = subprocess.Popen(cmd,
                                    shell=True,
                                    stdin=stdin,
                                    stdout=stdout,
                                    stderr=stderr,
                                    encoding=coding)
        shell_obj.stdin.write(str(str_shell_args)+"\n")
        shell_obj.stdin.write("exit\n") # 相信没有人会想卡在这对吧
        cmd_stdout,cmd_stderr = shell_obj.communicate()
        if show_output:print(rs(str(cmd_stdout)) + rs(str(cmd_stderr)))
        return CommandOutput(cmd_stdout, cmd_stderr, shell_obj.returncode, shell_obj.pid)
    except subprocess.TimeoutExpired:
        console.print(warn_color+"shell命令超时,尝试以普通模式执行")
        output = run_base_command(args)
        return output

class StringCommandOutput(NamedTuple):
    stdout:str
    stderr:str
    



def run_command(args:Union[str, list]="adb.exe start-server",
                encoding:Union[Literal["utf-8_from_bytes", "gbk_from_bytes"], AnyStr]="utf-8",
                show_output:bool=True,
                point_to_device:bool=True,
                return_type:Literal["status","output","statusoutput"]="output",
                output_by_tuple:bool=False,
                write_in_log:bool=True,
                silent:bool=False,
                cmd_vars:Optional[Dict[str,str]]=None,
                sync_update_bit:int=1,
                silent_when_wait:bool=False
                ) -> Union[Union[str, StringCommandOutput], int, Tuple[int, Union[str, StringCommandOutput]], CommandOutput]:
        """运行命令，返回输出或者返回码，可以选择是否展示输出\n
    adb shell命令需要特殊处理，尽量不要用其他选项，比如-a -s之类的
    若不需要cmd_vars则将此参数设置为{}"""
        if cmd_vars is None:
            cmd_vars = get_variable("cmd_environment_variables","__main__")

        global cwd, device_sn_args

        device_sn_args = get_variable("device_sn_args","__main__")
        if silent:
            write_in_log = False
            show_output = False

        if cmd_vars != {}:
            for key in cmd_vars.keys():
                os.environ[key]=cmd_vars[key]

        failure_nodevice = 0


        args_orig = args

        
        if isinstance(args, str):
            args = parse_args(args)

        command_name = args[0]


        # 对cmd做处理

        cmd_type:Literal["common", "command_line_tool", "common_adb", "adb_shell"] = "common"

        is_cmdline_tool = False
        is_adb = False
        is_adb_shell = False

        for tail in cmd_executables:
            tool_path = BIN_PATH + "\\" + args[0] + tail
            if os.path.isfile(tool_path):
                is_cmdline_tool = True
                command_name = tool_path

        if command_name == f"{BIN_PATH}\\adb.exe":
            is_adb = True
        else:
            is_adb = False


        if is_adb and any([arg == "shell" for arg in args]):
            is_adb_shell = True


        if not is_cmdline_tool:
            cmd_type = "common"   # 运行的就是一个Windows命令
        elif is_cmdline_tool and not is_adb:
            cmd_type = "command_line_tool"
        elif is_cmdline_tool and is_adb and not is_adb_shell:
            cmd_type = "common_adb"
        elif is_cmdline_tool and is_adb and is_adb_shell:
            cmd_type = "adb_shell"
            
        if cmd_type == "common" and write_in_log:
                write_log(SCRIPT_FILE_NAME,pid,1,f"当前命令：一般命令，原[{args_orig}], 解析后{str(args)}")

        if cmd_type == "command_line_tool":
            args[0] = command_name
            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,f"当前命令：[{BIN_PATH}]下命令行工具，原[{args_orig}], 解析后{str(args)}")

        if cmd_type == "common_adb":
            args[0] = command_name
            if point_to_device:
                args = [args[0]] + remove_in_list(device_sn_args.split(" "),"") + args[1:]
            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,f"当前命令：adb命令，指向设备：{point_to_device}，原[{args_orig}], 解析后{str(args)}")

        
        if cmd_type == "adb_shell":
            args[0] = command_name
            args_1 = []
            for arg in args[1:]:
                args_1.append(arg)
                if arg == "shell":
                    break

            if point_to_device:
                args = [args[0]] + remove_in_list(device_sn_args.split(" "),"") + args_1 + args[[a.strip() for a in args].index("shell")+1:]
            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,f"当前命令：adb shell命令，指向设备：{point_to_device}，原[{args_orig}], 解析后{args}，丢给run_adb_shell_command去执行")

        while True:   # 执行阶段

            if cmd_type != "adb_shell":
                output = run_base_command(args, encoding=encoding, show_output=show_output, sync_update_bit=sync_update_bit)

            else:
                output = run_adb_shell_command(args, coding=encoding, show_output=show_output, silent_when_wait=silent_when_wait) 

            _output = strip(rs(output.stdout) + rs(output.stderr))

            if write_in_log:
                write_log(SCRIPT_FILE_NAME,pid,1,f"执行完成，返回值{output.returncode}，pid{output.pid}，输出：\n")
                write_log(SCRIPT_FILE_NAME,pid,1,_output)


            if cmd_type in ("common_adb", "adb_shell"):

                    if any(["more than one device/emulator" in s for s in (output.stderr, output.stdout)]):
                        show_msgbox(warn_color+"警告",tip_color+"你现在连接了超过一个设备...需要指定要进行操作的设备才能继续",False,color=warn_color,use_console=True)
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,2,"当前有超过一个连接，将会让用户进行操作（连接设备）")
                        console.print(info_color+"\n检测当前连接...")
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"检测当前连接...")
                        output = run_command("adb devices","UTF-8",False,False)
                        output = output.splitlines()
                        if len(output) == 2:
                            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"只有一个ADB设备，可能是刚刚拔掉了？")
                            console.print(warn_color+"当前只连接了一个设备...刚刚断开连接了？")
                            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"当前的ADB设备：%s"%output[1])
                            console.print(info_color+"当前连接的设备：%s"%output[1])


                        elif len(output) > 2:
                            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"设备多于一个，将会进入选择界面。")
                            if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"检测当前连接...")
                            output = run_command("adb devices","UTF-8",False,False)
                            output = output.splitlines()
                            if len(output) == 2:
                                if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"只有一个ADB设备，不需要操作")
                                console.print(info_color+"当前只连接了一个设备，其实不需要选择设备的...")
                                if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"当前的ADB设备：%s"%output[1])
                                console.print(info_color+"当前连接的设备："+info_color+str(output[1]))

                            elif len(output) > 2:
                                devlist = []
                                devlist_dict = {}
                                if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"设备多于一个，将会进入选择界面。")
                                console.print(tip_color+"检测到了多个设备连接...")
                                if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"当前连接的设备列表：")
                                for devicenum in range(1,len(output)):
                                    devlist_dict[devicenum] = output[devicenum]
                                    if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,output[devicenum])
                                    devlist.append(Choice(output[devicenum].split("\t")[0],devicenum))

                                
                                if not (device_sn_args == "" or device_sn_args.isspace()):
                                    console.print(f"{info_color}当前选择的设备：{tip_color}{device_sn_args.split(' ')[1]}")
                                console.print(tip_color+"那么你想要操作的是哪一个设备？")
                                if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"请求用户选择设备...")
                                choose_device_num = ListPrompt("请选择设备：",
                                                                    devlist,
                                                                    annotation=ListPrompt_annotation,
                                                                    pointer=ListPrompt_pointer,
                                                                    ).prompt(style=ListPrompt_style).data

                                if choose_device_num == 0:
                                    console.print(info_color+"正在重置...")
                                    device_sn_args = ""
                                    console.print(success_color+"设置完成！")

                                else:
                                    choosed_device_sn = devlist_dict[choose_device_num]
                                    choosed_device_sn = str(choosed_device_sn).split("\t")[0]
                                    if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"选择的设备：%s"%choosed_device_sn)
                                    console.print(info_color+"选择的设备：%s"%choosed_device_sn)
                                    device_sn_args = "-s "+choosed_device_sn
                                    console.print(success_color+"设置完成！")

                            else:
                                console.print(warn_color+"（暂无）\n")
                                if write_in_log:write_log(SCRIPT_FILE_NAME,pid,1,"设备都断开了...？")
                                console.print(tip_color+"\n你把设备都断开了？也行，将会继续执行命令")
                            console.print(info_color+"将会继续执行命令...")
                            print("─────────────────────────────")




                    elif any(["no devices/emulators found" in s for s in (output.stderr, output.stdout)]):
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,2,"执行命令时断开连接...将会在按任意键后重新开始")
                        failure_nodevice += 1
                        if failure_nodevice == 1:
                            console.print(warn_color+"设备断开连接了...在连接设备后按任意键继续")
                        else:
                            console.print(warn_color+"设备还是没连上...在连接设备后按任意键重新尝试")
                        pause(False)


                    elif any(["device offline" in s for s in (output.stderr, output.stdout)]):
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,2,"执行命令时离线...将会在按任意键后重新开始")
                        console.print(warn_color+"设备离线了...在重新连接设备按任意键继续")
                        pause(False)


                    elif any(["error: closed" in s for s in (output.stderr, output.stdout)]):
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,2,"执行命令时端口关闭...将会在按任意键后重新开始")
                        console.print(warn_color+"设备关闭了...在重新连接设备按任意键继续")
                        pause(False)


                    elif any(["device" in s and "not found" in s for s in (output.stderr, output.stdout)]):
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,2,"当前选择的设备断开了...将会在按任意键后重新开始")
                        console.print(warn_color+"当前选择的设备断开了...在重新连接设备按任意键继续")
                        pause(False)


                    elif any(["device still authorizing" in s for s in (output.stderr, output.stdout)]):
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,2,"执行命令时设备仍在授权中...")
                        console.print(warn_color+"设备还在授权...将会在0.5秒后重试")
                        time.sleep(0.5)


                    elif any(["failed to start daemon" in s for s in (output.stderr, output.stdout)]):
                        if write_in_log:write_log(SCRIPT_FILE_NAME,pid,3,"ADB服务启动失败...")
                        console.print(warn_color+"ADB服务启动失败...请重启脚本后用功能7-2-6尝试修复")
                        pause(False)


                    else:
                        break
            else:
                break

        if output_by_tuple:
            _output = StringCommandOutput(output.stdout, output.stderr)
 

        if return_type == "output":
            return _output
            
        elif return_type == "status":
                return output.returncode
            
        elif return_type == "statusoutput":
            return output.returncode, _output
        
        else:
            return output
            

def run_linux_command(args:str,show_output:bool=False,output_type:Literal["text","tuple"]="text",return_type:Literal["output","status","statusoutput"]="output"):
    "运行linux的命令(独立于run_command)"
    output:subprocess.CompletedProcess = subprocess.run(f"{LINUX_BIN_PATH}\\{args}",shell=True,capture_output=True,text=True,encoding="utf-8")
    if show_output:print(output.stdout+output.stderr)
    if output_type == "text":
        return_output:str = output.stdout+output.stderr
    else:
        return_output:Tuple[str] = (output.stdout,output.stderr)
    if return_type == "output":
        return return_output
    if return_type == "status":
        return output.returncode
    if return_type == "statusoutput":
        return output.returncode, return_output

def run_sync_command(args:str,redirect_path:str=f"{CACHE_PATH}\\command_output.txt",return_output:bool=True,return_type:Literal["status","output","statusoutput"]="output",return_encoding:str="utf-8"):
    "在同步显示命令输出的同时返回命令输出（中文大概率乱码）"
    stat = os.system(f'{args} | {LINUX_BIN_PATH}\\tee.exe {CACHE_PATH}\\command_output.txt')
    if redirect_path != f"{CACHE_PATH}\\command_output.txt":
        os.system(f"copy {CACHE_PATH}\\command_output.txt {redirect_path} >nul 2>&1")
    if return_output and return_type != "status":
        text = read_textfile(f"{redirect_path}",return_encoding)
    if return_type == "output":
        return text
    elif return_type == "status":
        return stat
    else:
        return stat, output

    


def get_processid(imagename:str,*fi:Optional[str]):
    """获得一个固定imagename的进程的PID（如果有多个会返回一串列表）,fi可以指定其他的筛选条件，比如/fi "imagename ne wininit.exe"之类的，如果没有这个进程就返回-1 """
    output = subprocess.run("""tasklist /fi "imagename eq %s" /nh %s"""%(imagename,fi),capture_output=True,text=True,shell=True)
    output = output.stdout+output.stderr
    output = output.splitlines()
    if len(output) > 0:
        output_list = []
        for output_line in output:
            output_line_list = output_line.split(" ")
            for text in output_line_list:
                try:
                    output_pid = int(text)
                    output_list.append(output_pid)
                    break
                except:
                    pass
        if len(output_list) == 0:
            return -1
        elif len(output_list) == 1:
            return output_list[0]
        else:
            return output_list
    else:
        return -1



def generate_err_report(path=f"{DATA_PATH}\\crash_report\\crash_report_{get_saving_name()}.zip",
                        sender:str=SCRIPT_FILE_NAME,
                        tmp_path="crash_report_tmp\\",
                        description:str="当前错误没有任何描述...(该叫作者修复了)"):
    exception_type = type(sys.exc_info()[1]).__name__
    exception_desc = str(sys.exc_info()[1])
    if exception_type in support_error_desc.keys():
        exception_display_short = exception_type+":"+support_error_desc[exception_type]
    else:
        exception_display_short = "未知错误："+exception_type
    if exception_desc == "":
        exception_display_short_info = "（暂无详细信息）"      
    else:
        exception_display_short_info = exception_desc
    exception_full_traceback = ""
    for line in traceback.format_exc().splitlines():
        exception_full_traceback = exception_full_traceback + "\t" + line

    variables:dict = {}
    for key in dict(globals()).keys():
        variables[key] = dict(globals())[key]
    save_name = tmp_path + "runtime.txt"
    if not exist(tmp_path):
        mkdir(tmp_path)
    for key in dict(variables).keys():
        try:
            key_type = str(str(type(variables[key])).split("'")[1])
        except:
            key_type = str(type(key))
        write_textfile(save_name,f"[{key}]=({key_type})[{variables[key]}]\n","gbk",False)
    if exist(logpath):copy(logpath,tmp_path+"log.txt")
    write_textfile(f"{tmp_path}file_list.txt",os.listdir(cwd))
    write_textfile(f"{tmp_path}description.txt",description)
    copy(sys.argv[0],tmp_path+"script."+sys.argv[0].split('.')[-1])
    if exist("port_trace.txt"):copy("port_trace.txt",tmp_path+"last_port_trace.txt")
    write_textfile(tmp_path+"traceback.txt","来源"+sender+"\n简述：\n"+exception_display_short+":"+exception_display_short_info+"\ntraceback:\n"+traceback.format_exc())
    copytree(f"{DATA_PATH}\\",f"{tmp_path}data\\")
    copytree(f"{CACHE_PATH}\\",f"{tmp_path}cache\\")
    rd(f"{tmp_path}data\\crash_report")
    copytree("src",tmp_path+"src")
    md(f"{tmp_path}chains")
    for chain_file in traceback.format_exc().split("File \"")[1:]:
        chain_file = chain_file.split("\"")[0]
        cp(chain_file,f"{tmp_path}chains")
    write_zipfile(tmp_path,dst=path,build_base_dir=False)
    rmdir(tmp_path)




def getprop(attrname:str="ro.build.type") -> str:
    "用ADB命令获取build.prop的属性的值"
    return run_command(f"adb shell getprop {attrname}","UTF-8",write_in_log=False,show_output=False)



def has_root():
    "查看设备是否具有root权限"
    return run_command("adb shell su -c echo",return_type="output",silent=True).strip() == ""




def load_mainmemu(title:str="主界面",welcometext:str="欢迎来到真的啥也不是啊的工具箱！", 
                 features:List[Choice]=[Choice(1,"如果你在看这个，说明脚本出问题了")],              
                 tiptext:str="如果你在看这一段文本，说明代码又出问题了",
                 startedtimes:float=1.0):
    "加载主界面菜单，返回的是输入的值"
    global DEFAULT_CODE_PAGE
    chcp(DEFAULT_CODE_PAGE)
    current_connected_devices = []
    output = run_command("adb devices",silent=True,point_to_device=False)
    if len(output.splitlines()) > 1:
        for device in output.splitlines()[1::1]:
            try:
                device = device.split("\t")[0]
            except:
                device = ""
            if device != "":
                current_connected_devices.append(device)

    output = run_command("fastboot devices",silent=True,point_to_device=False)
    if len(output.splitlines()) > 1:
        for device in output.splitlines()[1::1]:
            try:
                device = device.split("\t")[0]
            except:
                device = ""
            if device != "":
                current_connected_devices.append(device)

    output = run_command("lsusb",silent=True,point_to_device=False)
    if len(output.splitlines()) >= 1:
        for device in output.splitlines():
            try:
                 device = " ".join(device.split(" ")[-3:-1])
            except:
                device = ""
            if device != "":
                current_connected_devices.append(device)

    nowtime = get_time()
    write_log(SCRIPT_FILE_NAME,pid,-1,"loadmainmemu:加载菜单，数据：加载时间：%s，最近更新：%s，版本号%s，启动次数：%d，"%\
        (nowtime,lastupdate,versionname,startedtimes))
    write_log(SCRIPT_FILE_NAME,pid,-1,"loadmainmemu:连接设备：%s,特殊事件：%s"%(current_connected_devices,special_events))
    cls()
    split_line(title)
    nowtime=nowtime[0:-4]
    console.print(f"{default_color}{welcometext}\n加载时间：{info_color}{nowtime}{close_tag} (这是第{value_color}{round(startedtimes)}{close_tag}次启动了)\n最近更新：{info_color}{(lastupdate)}{close_tag}，版本号{info_color}{versionname}{close_tag}")
    if len(current_connected_devices) == 0:
        console.print(f"{info_color}当前暂未连接设备，",end="")
    elif len(current_connected_devices) == 1:
        console.print(f"{info_color}当前连接设备：{tip_color}{current_connected_devices[0]}，",end="")
    else:
        console.print(f"{info_color}当前连接了{current_connected_devices[0]}等{len(current_connected_devices)}个设备，{close_tag}",end="")
    special_event_mainmenudisplay = f"{info_color}祝你破解顺利！{close_tag}"
    if "Diagnostics 900E" in current_connected_devices:
        special_event_mainmenudisplay = f"{warn_color}看来你的破解并不是很顺利。。。{close_tag}"
    if "Nonecoldwind_birthday" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是十三怀旧的生日！{close_tag}"
    if "SB1.0_birthday" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是SB1.0的生日！{close_tag}"
    if "Justnothing_birthday" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是啥也不是的生日！{close_tag}"
    if "new_year" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是元旦节！{close_tag}"
    if "lunar_new_year" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是大年初一！{close_tag}"
    if "lantern_festival" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是元宵节！{close_tag}"
    if "tree_planting_day" in special_events:
        special_event_mainmenudisplay = f"{tip_color}今天是植树节！{close_tag}"
    if "check_files_nextstart" in special_events:
        special_event_mainmenudisplay = f"{tip_color}下次启动会检查文件。{close_tag}"
    console.print(special_event_mainmenudisplay)
    console.print(f"{info_color}一个小提示: {tip_color}{tiptext}")
    split_line()
    prompt = ListPrompt(
        question="需要使用什么功能？",
        annotation="(使用上下方向键选择，回车确定)",
        choices=features,
        pointer=">"
    )
    return(prompt.prompt(style=ListPrompt_style).data)

    
# 就是加载除了主界面以外的功能界面的函数
# 参数：(标题，功能描述，询问信息，功能列表（要是一个字典，形如{1:"功能1",2:"功能2"}的类型，提示文本（默认是返回上级的提示））
def load_functionmenu(title:str="子功能界面",
                      description:str="这个功能还没有给定描述文本...",  
                      question:str="需要进行什么操作？", 
                      functions:Union[dict, List[Choice]]={1:"如果你在看这个，说明这代码又出特性了"},  
                      tiptext:str="注：输入0可返回上一级", 
                      clearscreen:bool=True,
                      autopropmpt:bool=True,
                      listmaxheight:int=15) -> Any:
    
    "加载正常功能的菜单，不是主界面（两者要区分开）"
    if clearscreen:cls()
    split_line(title)
    console.print(desc_color+str(description))
    menu_display = ""
    choice_list = []
    if autopropmpt:
        console.print(tip_color+str(tiptext))
        split_line()
        if isinstance(functions,dict):
            choice_list.append(Choice("0.返回上一级",0))
            for key in functions.keys():
                choice_list.append(Choice(str(str(key)+"."+str(functions[key])),key))
        else:
            choice_list.append(Choice("* 返回菜单",0))
            for key in functions:
                choice_list.append(key)

        prompt = ListPrompt(question,
                            choice_list,
                            max_height=listmaxheight,
                            annotation="(使用上下方向键选择，回车确定)",
                            default_select=1,
                            pointer=">")
        return(prompt.prompt(style=ListPrompt_style).data)
    else:
        console.print(question)
        for functionnum in functions.keys():
            if enablecoloredtext:
                if menuloadanimation:
                    cecho("%s.%s{\\n}"%(functionnum,functions[functionnum]))
                else:
                    menu_display += "%s.%s{\\n}"%(functionnum,functions[functionnum])
            else:
                if menuloadanimation:
                    print("%s.%s"%(functionnum,functions[functionnum]))
                    if MENU_ANIM_DELAY != 0:time.sleep(MENU_ANIM_DELAY)
                else:
                    print("%s.%s"%(functionnum,functions[functionnum]))
        if enablecoloredtext and not menuloadanimation:
            cecho(menu_display)

        console.print(tiptext)






def install_apk(apkpath:str,apknamedisplay:Optional[str]=None,showoutput:bool=True,writeinlog:bool=True) -> Tuple[str, bool]:
    """在当前的设备上尝试安装一个apk,返回的是结果"""
    if apkpath == "" or apkpath.isspace():
        console.print(err_color+"没有指定apk的路径！")
        return "", False
    if apknamedisplay is None:apknamedisplay = "软件"
    if not exist(apkpath) and showoutput:
            error_console.print(f"{warn_color}install_apk:警告：当前指定的apk路径\[{apkpath}]可能不存在。")
    if showoutput:console.print(f"{info_color}尝试以adb install安装{apknamedisplay}...")
    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"用adb install安装%s..."%apknamedisplay)
    pm_install_tries = 0
    pm_install_success = False
    wait_for_device()
    while pm_install_tries < 3:
        pm_install_tries += 1
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"\n进行%d/3次尝试..."%pm_install_tries)
        if showoutput:console.print(f"{info_color}进行{tip_color}{pm_install_tries}/3{close_tag}次尝试...")
        output = run_command(f"adb install -r {apkpath}",encoding="utf-8")
        if "Success" not in output:
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,2,"安装失败...再次尝试")
            if showoutput:console.print(f"{warn_color}貌似没有成功...将会再次尝试")

        else:
            pm_install_success = True
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"安装成功！")
            if showoutput:console.print(success_color+"安装成功！")
            return "Success", True
    if not pm_install_success:
        if showoutput:console.print(tip_color+"""\nadb install失败了，将会尝试以pm指令安装该软件...""")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"adb install失败，将会尝试以三步法安装该软件...")
    inputmsg = apkpath

    while True:
        if showoutput:console.print(info_color+"复制文件...")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"复制文件到%s\\current_installation.apk..."%CACHE_PATH)
        returncode = run_command(f"copy {inputmsg} {APK_COPY_PATH}","ANSI",return_type="status")
        if returncode != 0:
            if returncode == 4:
                if showoutput:console.print(err_color+"写文件时出现了错误...盘满了？ ")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"写文件时出现了错误...")
            if returncode == 3:
                if showoutput:console.print(err_color+"预置的错误终止了操作...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"预置错误终止了操作.....")
            if returncode == 2:
                if showoutput:console.print(err_color+"你通过ctrl+c终止了操作...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"通过ctrl+c终止了操作...（脚本怎么还活着？？？）")
            if returncode == 1:
                if showoutput:console.print(err_color+"未找到此文件...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"未找到此文件...")
            return output, False

        if showoutput:console.print(info_color+"步骤1/5已完成。")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"步骤1/5已完成。")
        if showoutput:console.print(info_color+"\n传输文件到手表里...")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"将文件传输进手表...")
        wait_for_device()
        push_tries = 0
        console.print(f"{info_color}进行第{tip_color}{push_tries+1}/3{close_tag}次尝试...")
        while push_tries < 3:
            output = run_command(f"adb push {APK_COPY_PATH} {APK_PUSH_PATH}")
            if "error" in output:
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"传输貌似失败了...")
                if showoutput:console.print(warn_color+"传输貌似失败了...")
                if "failed to read copy response" in output:
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"可能是因为中途断开连接，将会通知用户。")
                    if showoutput:console.print(warn_color+"可能是传输中途断开连接了...将会等待设备连接后重试")
                    wait_for_device()
                if "read from device" in output:
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"啊？push锁没解？")
                    if showoutput:console.print(warn_color+"push锁没解？不对吧，将会重试")
                push_tries += 1 
                print(f"进行第{push_tries+1}/3次尝试...")

            else:
                if showoutput:console.print(success_color+"传输成功！步骤2/5已完成。")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"传输完成！")
                push_tries = True
                break
        
        if push_tries != True:
            console.print(err_color+"adb push失败，安装失败...")
            return output, False
        
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"步骤2/5已完成。")

        create_install_session_tries = 0

        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"创建安装进程...")
        if showoutput:console.print(info_color+"\n创建安装进程...")

        while create_install_session_tries < 3:

            output = run_command("adb shell pm install-create")
            if "Success" in output:
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"进程创建成功，获取进程编号...")
                if showoutput:console.print(info_color+"进程创建成功，获取进程编号...")
                install_session_id = output.split("[")[1].split("]")[0]
                try:
                    install_session_id = int(install_session_id)
                    break
                except:
                    create_install_session_tries += 1
                    if writeinlog:write_log(SCRIPT_FILE_NAME,pid,2,"进程编号读取失败...(%d/3)"%create_install_session_tries+1)
                    if showoutput:console.print(warn_color+"进程编号读取失败...(%d/3)"%create_install_session_tries+1)
                    continue


            else:
                create_install_session_tries += 1
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,2,"进程创建失败或者没有获取到正确的输出...将会进行第%d/3次重试"%create_install_session_tries)
                if showoutput:console.print(warn_color+"进程创建失败或者没有获取到正确的输出...将会进行第%d/3次重试"%create_install_session_tries)



        if create_install_session_tries >= 3:
            if showoutput:console.print(err_color+"获取进程ID失败...安装失败！")
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"进程创建失败...安装失败！")
            return output, False

        if showoutput:console.print(f"{info_color}获取到的进程ID:{value_color}{install_session_id}")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"进程创建完成！")
        if showoutput:console.print(success_color+"步骤3/5已完成。")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"步骤3/5已完成。")
        if showoutput:console.print(info_color+"\n写入安装包...")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"写入安装包...")

        output = run_command(f"adb shell pm install-write {install_session_id} com.justnothing {APK_PUSH_PATH}")
        if "No such file or directory" in output:
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"读取和写入安装包时未找到文件...安装失败！")
            if showoutput:console.print(err_color+"在手表内没有找到刚刚传输的文件...可能是adb push出问题了，\n传输文件到手表的那个操作的输出中可能会有问题的描述")
            return output
        elif "Failed to write" in output:
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,3,"可能读取和写入安装包时内存不足...安装失败！")
            if showoutput:console.print(err_color+"写入失败了...是不是手表内存满了？")
            return output, False

        if str(output.split(" ")[2]).isdigit():
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"完成，本次写入了%s字节。"%output.split(" ")[2])
            if showoutput:console.print(info_color+f"完成，本次写入了{info_color}{output.split(' ')[2]}{close_tag}字节。",end="")
            streamed_bytes = int(output.split(" ")[2])
            if streamed_bytes in range(B_in_1KB,B_in_1KB*KB_in_1MB):
                if showoutput:console.print(value_color+"（%sKB）"%round(streamed_bytes/B_in_1KB,2))
            elif streamed_bytes in range(B_in_1KB*KB_in_1MB,B_in_1KB*KB_in_1MB*MB_in_1GB):
                if showoutput:console.print(value_color+"（%sMB）"%round(streamed_bytes/B_in_1KB/KB_in_1MB,2))
            elif streamed_bytes > B_in_1KB*KB_in_1MB*MB_in_1GB:
                if showoutput:console.print(value_color+"（%sGB）"%round(streamed_bytes/B_in_1KB/KB_in_1MB/MB_in_1GB,2))
            else:
                if showoutput:print()

            if streamed_bytes < 10000:
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,2,"安装包小得有点过分...可能会出现未知问题")
                if showoutput:console.print(f"{warn_color}这安装包有点小啊...是认真的吗？")
        else:
            if showoutput:console.print(warn_color+"没有获取到正确的写入字节数...可能出错了，但还是会继续")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"步骤4/5已完成。")
        if showoutput:console.print(success_color+"步骤4/5已完成。")
        if showoutput:console.print(info_color+"\n最后一步：确认安装")
        if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"最后一步：确认安装")
        output = run_command("adb shell pm install-commit %s"%install_session_id,show_output=False)
        if exist("cache\\current_installation.apk"):os.remove("cache\\current_installation.apk")
        run_command(f"adb shell rm {APK_PUSH_PATH}",show_output=False)
        if "Success" in output:
            if showoutput:split_line(color_style=success_color)
            if showoutput:console.print(success_color+"安装成功！".rjust(round((windowcharwidth/2)+1)," "))
            if showoutput:split_line(color_style=success_color)
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"安装成功！")
            if showoutput:console.print(success_color+"步骤5/5已完成。安装成功！")
            return (output, True)

        else:
            if showoutput:split_line(color_style=err_color)
            if showoutput:console.print(err_color+"安装失败！".rjust((round(windowcharwidth/2)+1)," "))
            if showoutput:split_line(color_style=err_color)
            if writeinlog:write_log(SCRIPT_FILE_NAME,pid,2,"安装失败！")
            if showoutput:console.print(err_color+"错误信息："+output)
            if showoutput:console.print("\t",end="")
            if "INSTALL_FAILED_ALREADY_EXISTS" in output:
                package_name = str(output).split("Attempt to re-install ")[1].split(" without first uninstalling.")[0]
                if showoutput:console.print(warn_color+"软件%s已经安装过了！"%package_name)
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：该软件已经安装...")

            elif "INSTALL_FAILED_INVALID_APK" in output:
                if showoutput:console.print(warn_color+"这个apk文件无效...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：这个apk文件无效...")
                
            elif "INSTALL_FAILED_INSUFFICIENT_STORAGE" in output:
                if showoutput:console.print(warn_color+"手表的空间不足...试着清理手表的空间？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：手表的空间不足...试着清理手表的空间？")

            elif "INSTALL_FAILED_INVALID_URI" in output:
                if showoutput:console.print(warn_color+"安装过程中apk名无效...试着把错误信息复制给开发者？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：安装过程中apk名无效...试着把错误信息复制给开发者？")


            elif "INSTALL_FAILED_NO_SHARED_USER" in output:
                if showoutput:console.print(warn_color+"软件所请求的共享用户不存在...可能是手表不兼容，试着在Androidmanifest.xml里面把sharedUserId一行删掉？说不定真有用")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件所请求的共享用户不存在...可能是手表不兼容，试着在Androidmanifest.xml里面把sharedUserId一行删掉？说不定真有用")

            elif "INSTALL_FAILED_UPDATE_INCOMPATIBLE" in output:
                if showoutput:console.print(warn_color+"软件安装升级失败...可能是已经安装过了或者卸载了但数据没清干净并且签名对不上")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件安装升级失败...可能是已经安装过了或者卸载了但数据没清干净并且签名对不上")

            elif "INSTALL_FAILED_SHARED_USER_INCOMPATIBLE" in output:
                if showoutput:console.print(warn_color+"请求共享用户时签名不一致...可能是手表不兼容？\n\t还有，覆盖安装系统应用估计是行不通的")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：请求共享用户时签名不一致...可能是手表不兼容？\n\t还有，覆盖安装系统应用估计是行不通的")

            elif "INSTALL_FAILED_MISSING_SHARED_LIBRARY" in output:
                if showoutput:console.print(warn_color+"设备缺少软件需要的共享库...可能是手表不兼容？	")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：设备缺少软件需要的共享库...可能是手表不兼容？	")

            elif "INSTALL_FAILED_REPLACE_COULDNT_DELETE" in output:
                if showoutput:console.print(warn_color+"替换文件时无法删除...可能是系统出问题了，再试一次？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：替换文件时无法删除...可能是系统出问题了，再试一次？")

            elif "INSTALL_FAILED_DEXOPT" in output:
                if showoutput:console.print(warn_color+"dex验证失败...可能是软件有问题或者空间不够了？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：dex验证失败...可能是软件有问题或者空间不够了？")

            elif "INSTALL_FAILED_OLDER_SDK" in output:
                if showoutput:console.print(warn_color+"软件所要求的系统版本太低了...在这里装不了")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件所要求的系统版本太低了...在这里装不了")

            elif "INSTALL_FAILED_NEWER_SDK" in output:
                if showoutput:console.print(warn_color+"软件所要求的系统版本太高了...在这里装不了")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件所要求的系统版本太高了...在这里装不了")

            elif "INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION" in output:
                if showoutput:console.print(warn_color+"解析包时遇到了未知问题...可能是软件不兼容或者你丢进来的不是个apk文件？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：解析包时遇到了未知问题...可能是软件不兼容或者你丢进来的不是个apk文件？")

            elif "INSTALL_FAILED_CONFLICTING_PROVIDER" in output:
                if showoutput:console.print(warn_color+"这个软件里使用了设备里已经存在的内容提供器（ContentProvider），安装不了")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：这个软件里使用了设备里已经存在的内容提供器（ContentProvider），安装不了")

            elif "INSTALL_FAILED_TEST_ONLY" in output:
                if showoutput:console.print(warn_color+"这个应用仅供测试，不用正经的install安装不了（可以试着自己用install命令,记得加-t参数）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"这个应用仅供测试，不用正经的install安装不了（可以试着自己用install命令,记得加-t参数）")
                
            elif "INSTALL_FAILED_CPU_ABI_INCOMPATIBLE" in output:
                if showoutput:console.print(warn_color+"这个应用与CPU不兼容...安装不了")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：这个应用与CPU不兼容...安装不了")

            elif "INSTALL_FAILED_MISSING_FEATURE" in output:
                if showoutput:console.print(warn_color+"应用使用了设备不可用的功能...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：应用使用了设备不可用的功能...")

            elif "INSTALL_FAILED_CONTAINER_ERROR" in output:
                if showoutput:console.print(warn_color+"文件传输（应该是）时出现了错误...可能是签名有问题，重新给安装包签名？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：文件传输（应该是）时出现了错误...可能是签名有问题，重新给安装包签名？")

            elif "INSTALL_FAILED_INVALID_INSTALL_LOCATION" in output:
                if showoutput:console.print(warn_color+"软件不能被安装到此位置...\n\t（不对啊，为什么会出现这奇葩错误）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件不能被安装到此位置...")

            elif "INSTALL_FAILED_MEDIA_UNAVAILABLE" in output:
                if showoutput:console.print(warn_color+"软件安装位置不可用...\n\t这又是什么新奇的错误，从没见过手表会有其他设备的）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件安装位置不可用...")

            elif "INSTALL_FAILED_VERIFICATION_TIMEOUT" in output:
                if showoutput:console.print(warn_color+"验证安装包超时...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：验证安装包超时...")

            elif "INSTALL_FAILED_VERIFICATION_FAILURE" in output:
                if showoutput:console.print(warn_color+"验证安装包失败...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：验证安装包失败...")
                
            elif "INSTALL_FAILED_PACKAGE_CHANGED" in output:
                if showoutput:console.print(warn_color+"软件包被替换了...可能是软件包在安装过程中被修改了？（我也不确定）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：软件包被替换了...可能是软件包在安装过程中被修改了？")

            elif "INSTALL_FAILED_UID_CHANGED" in output:
                if showoutput:console.print(warn_color+"以前安装该应用时与分配的UID与本次不一致...试着清除以前安装过的残留文件？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：以前安装该应用时与分配的UID与本次不一致...试着清除以前安装过的残留文件？")

            elif "INSTALL_FAILED_VERSION_DOWNGRADE" in output:
                if showoutput:console.print(warn_color+"已经安装过更高的版本了...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：已经安装过更高的版本了...")

            elif "INSTALL_FAILED_PERMISSION_MODEL_DOWNGRADE" in output:
                if showoutput:console.print(warn_color+"已安装 target SDK 支持运行时权限的同名应用，要安装的版本不支持运行时权限（网上搜的，听起来很高级）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：已安装 target SDK 支持运行时权限的同名应用，要安装的版本不支持运行时权限（网上搜的，听起来很高级）")
                
            elif "INSTALL_PARSE_FAILED_NOT_APK" in output:
                if showoutput:console.print(warn_color+"这个文件不是apk...（啊？？？？）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：这个文件不是apk...（啊？？？？）")


            elif "INSTALL_PARSE_FAILED_BAD_MANIFEST" in output:
                if showoutput:console.print(warn_color+"无法解析软件包中的AndroidManifest.xml文件...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：无法解析软件包中的AndroidManifest.xml文件...")

            elif "INSTALL_PARSE_FAILED_NO_CERTIFICATES" in output:
                if showoutput:console.print(warn_color+"安装包没有签名...给它签一个名？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：安装包没有签名...给它签一个名？")

            elif "INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES" in output:
                if showoutput:console.print(warn_color+"应用的签名与已安装过的不一致...卸载以前的版本试试？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：应用的签名与已安装过的不一致...卸载以前的版本试试？")

            elif "INSTALL_PARSE_FAILED_CERTIFICATE_ENCODING" in output:
                if showoutput:console.print(warn_color+"证书解码失败...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：证书解码失败...")

            elif "INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME" in output:
                if showoutput:console.print(warn_color+"安装包中的AndroidManifest.xml里没有或者使用了无效的包名...（软件的锅）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：安装包中的AndroidManifest.xml里没有或者使用了无效的包名...（软件的锅）")

            elif "INSTALL_PARSE_FAILED_BAD_SHARED_USER_ID" in output:
                if showoutput:console.print(warn_color+"安装包中的AndroidManifest.xml里指定了无效的共享用户ID...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：安装包中的AndroidManifest.xml里指定了无效的共享用户ID...")

            elif "INSTALL_PARSE_FAILED_MANIFEST_MALFORMED" in output:
                if showoutput:console.print(warn_color+"AndroidManifest.xml编写有误...（软件的锅）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：AndroidManifest.xml编写有误...")

            elif "INSTALL_PARSE_FAILED_MANIFEST_EMPTY" in output:
                if showoutput:console.print(warn_color+"在AndroidManifest.xml里找不到找可操作标签（软件的锅）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：在AndroidManifest.xml里找不到找可操作标签")

            elif "INSTALL_FAILED_INTERNAL_ERROR" in output:
                if showoutput:console.print(warn_color+"系统出错了...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：系统出错了...")

            elif "INSTALL_FAILED_USER_RESTRICTED" in output:
                if showoutput:console.print(warn_color+"此用户被限制安装应用了...(?)")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：此用户被限制安装应用了...(?)")


            elif "INSTALL_FAILED_DUPLICATE_PERMISSION" in output:
                if showoutput:console.print(warn_color+"应用定义的权限已经存在了...(软件的锅)")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：应用定义的权限已经存在了...")


            elif "INSTALL_FAILED_NO_MATCHING_ABIS" in output:
                if showoutput:console.print(warn_color+"这个软件和设备的CPU不兼容...")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：这个软件和设备的CPU不兼容...")

            elif "INSTALL_CANCELED_BY_USER" in output:
                if showoutput:console.print(warn_color+"安装被用户取消了...（？？？？？？）")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：安装被用户取消了...（？？？？？？）")

            elif "INSTALL_FAILED_ACWF_INCOMPATIBLE" in output:
                if showoutput:console.print(warn_color+"应用与设备不兼容.....")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"错误原因和解决方案：应用与设备不兼容.....")

            elif "is the system running?" in output:
                if showoutput:console.print(warn_color+"设备的系统还不在运行，等彻底开机了再安装吧")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"系统还未运行，将会等待十秒后尝试重新安装...")

            else:
                if showoutput:console.print(tip_color+"没见过的新奇错误，发给开发者看看？")
                if writeinlog:write_log(SCRIPT_FILE_NAME,pid,1,"未知错误:"+output)
                


            return output, False



        
def install_module(path:str=f"{FILE_PATH}\\module.zip",use_script:bool=True):
    "安装一个模块"
    while True:
        console.print(info_color+"\n将文件复制到此文件夹...")
        if path[0:1] == "'" and path.endswith("'"):
            path = path[1:]
            path = path[0:-1]
            path = f"\"{path}\""
        write_log(SCRIPT_FILE_NAME,pid,1,f"复制文件到{MODULE_COPY_PATH}")
        returncode = run_command("copy %s %s"%(path,MODULE_COPY_PATH),encoding="ansi",return_type="status")
        if returncode != 0:
            if returncode == 4:
                console.print(warn_color+"写文件时出现了错误...盘满了？ ")
                write_log(SCRIPT_FILE_NAME,pid,1,"写文件时出现了错误...")
            if returncode == 3:
                console.print(warn_color+"预置的错误终止了操作...")
                write_log(SCRIPT_FILE_NAME,pid,1,"预置错误终止了操作.....")
            if returncode == 2:
                console.print(warn_color+"你通过ctrl+c终止了操作...")
                write_log(SCRIPT_FILE_NAME,pid,1,"通过ctrl+c终止了操作...（脚本怎么还活着？？？）")
            if returncode == 1:
                console.print(warn_color+"未找到此文件...")
                write_log(SCRIPT_FILE_NAME,pid,1,"未找到此文件...")
            write_log(SCRIPT_FILE_NAME,pid,1,"按任意键后重新执行...")
            pause("按任意键后重新执行...")
            continue
        console.print(success_color+"完成！（步骤1/3）")
        write_log(SCRIPT_FILE_NAME,pid,1,"步骤1/3已完成。")
        console.print(info_color+"\n传输文件到手表里...")
        write_log(SCRIPT_FILE_NAME,pid,1,"将文件传输进手表...")
        wait_for_device()
        output = run_command(f"adb push {MODULE_COPY_PATH} {MODULE_PUSH_PATH}")
        if "error" in output:
            write_log(SCRIPT_FILE_NAME,pid,1,"传输貌似失败了...")
            console.print(warn_color+"传输貌似失败了...")
            if "failed to read copy response" in output == -1:
                write_log(SCRIPT_FILE_NAME,pid,1,"可能是因为中途断开连接，将会通知用户。")
                console.print(warn_color+"可能是传输中途断开连接了...")
            if "read from device" in output == -1:
                write_log(SCRIPT_FILE_NAME,pid,1,"Push锁还没解开...")
                console.print(err_color+"先解开Push锁再来吧...（详情见功能6-4）")
                return
            pause("按任意键重试...")
            continue
        else:
            console.print(success_color+"传输成功！（步骤2/3）")
            write_log(SCRIPT_FILE_NAME,pid,1,"传输完成！")
            write_log(SCRIPT_FILE_NAME,pid,1,"步骤2/3已完成。")
        console.print(info_color+"\n安装模块...")
        write_log(SCRIPT_FILE_NAME,pid,1,"安装模块...")
        if use_script:
            make_module_script(script_path=MODULE_SCRIPT_PUSH_PATH,module_path=MODULE_PUSH_PATH)
            status = os.system(f'adb shell su -c "sh {MODULE_SCRIPT_PUSH_PATH}"')
            run_command(f"adb shell su -c \"rm -r {MODULE_SCRIPT_PUSH_PATH}\"")
        else:
            status = os.system(f"adb shell su -c magisk --install-module {MODULE_PUSH_PATH}")
        if not status:
            console.print(success_color+"安装成功！")
            write_log(SCRIPT_FILE_NAME,pid,1,"成功！")
        else:
            console.print(warn_color+"安装可能失败了...")
            write_log(SCRIPT_FILE_NAME,pid,2,"模块安装可能失败了...")
        run_command(f"adb shell su -c rm -r {MODULE_PUSH_PATH}")
        write_log(SCRIPT_FILE_NAME,pid,1,"执行完成！步骤3/3已完成。")
        return




def change_adb_server_port(port,restart=True) -> str:
    "更改ADB服务当前所在的端口号"
    global adbserverport
    adbserverport = port
    update_options(options,"add","adbserverport",port)
    cmd_environment_variables["ANDROID_ADB_SERVER_PORT"] = port
    set_variable("cmd_environment_variables",cmd_environment_variables)
    os.environ["ANDROID_ADB_SERVER_PORT"] = port
    if restart:
        run_command("adb kill-server",silent=True)
        run_command("adb start-server",silent=True)


def wait_for_device(showerrormode:bool=False,
                    mode:Literal["adb", "edl", "bootloader", "any"]="adb",
                    timeout:int=-1,
                    showtext:bool=True) -> Optional[Literal["adb", "edl", "bootloader"]]:
    "等待直到设备连接，不建议乱用（不然整个脚本就会卡住）"
    if mode == "adb":
        if timeout < 0:
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:等待ADB设备连接...")
            if showerrormode:
                while True:
                    commandoutput = run_command("adb devices",silent=True)
                    if "offline" in commandoutput:
                        console.print(f"{warn_color}设备离线了...试着重新连接一次？（按任意键继续）")
                        write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:设备离线，等待重新连接...")
                        pause(False)


                    elif "unauthorized" in commandoutput:
                        console.print(f"{warn_color}设备没授权...试着把设备重启一下？（按任意键继续）")
                        write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:设备未授权，等待重新连接...")
                        pause(False)


                    elif len(commandoutput.splitlines()) == 1:
                        console.print(f"{warn_color}设备没连接...请将设备连接到电脑上（按任意键继续）")
                        write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:设备未连接，等待连接...")
                        pause(False)


                    elif "authorizing" in commandoutput:
                        write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:执行命令时设备仍在授权中，将会在按任意键后重新链接...")
                        console.print(f"{warn_color}设备还在授权...稍微等待一小会吧（按任意键继续）")
                        pause(False)


                    elif len(commandoutput.split("List of devices attached\n")[1]) > 0:
                        break

            else:
                if showtext:
                    with console.status(f"{info_color}等待adb设备连接...",spinner=spinner_name):
                        os.system(F"{BIN_PATH}\\adb.exe wait-for-device devices >nul 2>&1")
                else:
                    os.system(F"{BIN_PATH}\\adb.exe wait-for-device devices >nul 2>&1")
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:已找到设备，开始执行...")


        else:

            def _wait_thread():
                os.system(F"{BIN_PATH}\\adb.exe wait-for-device devices >nul 2>&1")

            thread = threading.Thread(target=_wait_thread)
            thread.start()
            for __count in range(timeout):
                if not thread.is_alive():
                    return
                else:
                    if showtext:
                        with console.status(f"{info_color}等待ADB设备连接（{value_color}{timeout-__count}{close_tag}秒）..."):
                            time.sleep(1)
                    else:
                        time.sleep(1)
            if thread.is_alive():
                raise Script.Exceptions.Functions.DeviceTimeOutError(f"设备在{timeout}秒内未连接。")
            
        return "adb"
    

    if mode == "edl":
        if timeout < 0:
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:等待EDL设备连接...")
            if showerrormode:
                while True:
                    commandoutput = run_command("lsusb",silent=True)
                    if "9008" in commandoutput:
                        break
            else:
                if showtext:
                    with console.status(f"{info_color}等待edl设备连接...",spinner=spinner_name):
                        while True:
                            commandoutput = run_command("lsusb",silent=True)
                            if "9008" in commandoutput:
                                break
                else:
                    while True:
                        output = run_command("lsusb",silent=True)
                        if "9008" in output:
                            break
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:已找到设备，开始执行...")


        else:

            def _wait_thread():
                while True:
                    commandoutput = run_command("lsusb",silent=True)
                    if "9008" in commandoutput:
                        break

            thread = threading.Thread(target=_wait_thread)
            thread.start()
            for __count in range(timeout):
                if not thread.is_alive():
                    return
                else:
                    if showtext:
                        with console.status(f"{info_color}等待edl设备连接（{value_color}{timeout-__count}{close_tag}秒）..."):
                            time.sleep(1)
                    else:
                        time.sleep(1)
            if thread.is_alive():
                raise Script.Exceptions.Functions.DeviceTimeOutError(f"设备在{timeout}秒内未连接。")
            
        return "edl"
            
    if mode == "bootloader":
        if timeout < 0:
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:等待FASTBOOT设备连接...")
            if showerrormode:
                while True:
                    commandoutput = run_command("fastboot devices",silent=True)
                    if len(commandoutput) > 1:
                        break
            else:
                if showtext:
                    with console.status(f"{info_color}等待fastboot设备连接...",spinner=spinner_name):
                        while True:
                            commandoutput = run_command("fastboot devices",silent=True)
                            if len(commandoutput) > 1:
                                break
                else:
                    while True:
                            while True:
                                commandoutput = run_command("fastboot devices",silent=True)
                                if len(commandoutput) > 1:
                                    break
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:已找到设备，开始执行...")


        else:

            def _wait_thread():
                while True:
                    commandoutput = run_command("fastboot devices",silent=True)
                    if len(commandoutput) > 1:
                        break

            thread = threading.Thread(target=_wait_thread)
            thread.start()
            for __count in range(timeout):
                if not thread.is_alive():
                    return
                else:
                    if showtext:
                        with console.status(f"{info_color}等待fastboot设备连接（{value_color}{timeout-__count}{close_tag}秒）..."):
                            time.sleep(1)
                    else:
                        time.sleep(1)
            if thread.is_alive():
                raise Script.Exceptions.Functions.DeviceTimeOutError(f"设备在{timeout}秒内未连接。")
        return "bootloader"
            
    else:
        if timeout < 0:
            write_log(SCRIPT_FILE_NAME,pid,0,"wait_for_device:等待任意设备连接...")
            if showerrormode:
                while True:
                    commandoutput = run_command("fastboot devices",silent=True)
                    if len(commandoutput) > 1:
                        return "bootloader"
                    commandoutput = run_command("adb devices",silent=True).splitlines()
                    if len(commandoutput) > 1:
                        return "adb"
                    commandoutput = run_command("lsusb",silent=True)
                    if "9008" in commandoutput:
                        return "edl"
            else:
                if showtext:
                    with console.status(f"{info_color}等待任意设备连接...",spinner=spinner_name):
                        while True:
                            commandoutput = run_command("fastboot devices",silent=True)
                            if len(commandoutput) > 1:
                                return "bootloader"
                            commandoutput = run_command("adb devices",silent=True).splitlines()
                            if len(commandoutput) > 1:
                                return "adb"
                            commandoutput = run_command("lsusb",silent=True)
                            if "9008" in commandoutput:
                                return "edl"
                else:
                    while True:
                        commandoutput = run_command("fastboot devices",silent=True)
                        if len(commandoutput.splitlines()) > 1:
                            return "bootloader"
                        commandoutput = run_command("adb devices",silent=True).splitlines()
                        if len(commandoutput) > 1:
                            return "adb"
                        commandoutput = run_command("lsusb",silent=True)
                        if "9008" in commandoutput:
                            return "edl"


        else:

            def _wait_thread():
                while True:
                    commandoutput = run_command("fastboot devices",silent=True)
                    if len(commandoutput) > 1:
                        return "bootloader"
                    commandoutput = run_command("adb devices",silent=True).splitlines()
                    if len(commandoutput) > 1:
                        return "adb"
                    commandoutput = run_command("lsusb",silent=True)
                    if "9008" in commandoutput:
                        return "edl"

            thread = threading.Thread(target=_wait_thread)
            thread.start()
            for __count in range(timeout):
                if not thread.is_alive():
                    commandoutput = run_command("fastboot devices",silent=True)
                    if len(commandoutput) > 1:
                        return "bootloader"
                    commandoutput = run_command("adb devices",silent=True).splitlines()
                    if len(commandoutput) > 1:
                        return "adb"
                    commandoutput = run_command("lsusb",silent=True)
                    if "9008" in commandoutput:
                        return "edl"
                else:
                    if showtext:
                        with console.status(f"{info_color}等待任意设备连接（{value_color}{timeout-__count}{close_tag}秒）..."):
                            time.sleep(1)
                    else:
                        time.sleep(1)
            if thread.is_alive():
                raise Script.Exceptions.Functions.DeviceTimeOutError(f"设备在{timeout}秒内未连接。")

            
            
            
            




def fix_magisk_env(reboot:bool=True):
    "修复magisk运行环境"
    wait_for_device()
    if "No such file" not in run_command("adb shell su -c ls /data/adb/magisk/boot_patch.sh",silent=True):
        console.print(warn_color+"看起来magisk环境并没有什么问题...确定还要继续修复吗？")
        if not confirm_prompt():
            return
    console.print(info_color+"修补Magisk目录...")
    write_log(SCRIPT_FILE_NAME,pid,1,"修补Magisk目录...")
    while True:
        run_command(f"adb push {FILE_PATH}\\magisk\\ /sdcard/")
        output = run_command("adb shell su -c cp -R /sdcard/magisk /data/adb/")
        write_log(SCRIPT_FILE_NAME,pid,0,"复制/sdcard/magisk到/data/adb/...")
        if "Permission denied"  in output:
            write_log(SCRIPT_FILE_NAME,pid,2,"访问被拒绝...请求用户允许")
            console.print(warn_color+"请在magisk中允许shell访问超级用户权限...")
            pause()
            continue
        write_log(SCRIPT_FILE_NAME,pid,0,"设置/data/adb/magisk/和其所有文件权限为744(rwxr--r--)...")
        run_command("adb shell su -c chmod -R 744 /data/adb/magisk/")
        run_command("adb shell su -c chmod -R 744 /data/adb/magisk/*")
        write_log(SCRIPT_FILE_NAME,pid,0,"移除原来的/data/adb/...")
        run_command("adb shell su -c rm -R /sdcard/magisk/*")
        break
    if reboot:
        write_log(SCRIPT_FILE_NAME,pid,1,"重启设备...")
        console.print(info_color+"重启设备...")
        run_command("adb reboot")
    console.print(success_color+"完成！")



def get_firmware_info(xml:str=f"{FIRMWARE_PATH}\\Z8_2.7.4.xml") -> Dict[str, Union[List[Dict[str, str]], str]]:
    "获取刷机脚本的信息"
    root = ET.parse(xml).getroot()
    programs = []
    all_programs = root.findall("program")
    for program in all_programs:
        programs.append(program.attrib)
        if "label" not in program.attrib.keys():
            raise AttributeError("没有在指定的xml中找到label标签！")
        path = None
        if program.attrib["label"] in ("boot", "recovery"):
            try:
                path = program.attrib["filename"]
            except:
                pass
        else:
            continue
        if path is None:
            raise AttributeError("没有在指定的xml中找到filename标签！")
        
        inf_path =  FIRMWARE_PATH + "\\" + path.split("\\")[0] + "\\magisk_version.ini"
        try:
            f = open(inf_path)
        except FileNotFoundError:
            raise FileNotFoundError("请修复" + FIRMWARE_PATH +"\\" + path.split("\\")[0] + "\\magisk_version.ini，否则无法检测magisk版本！")

        s = f.read()
        f.close()
        for line in s.splitlines():
            if path.split("\\")[1] in line:
                magisk_version = line.split("=")[1]
    return {"programs": programs, "magisk_version": magisk_version}



def flash_rawprogram(search_path:str="firmware",xml:str="Z8_2.2.1.xml",need_reboot_to_edl=True,reset=True,send_mbn:str=COMMON_MBN_PATH):
    "指定rawprogram0.xml进行刷机"
    if reset:others = "--reset"
    global COMMON_MBN_PATH, SCRIPT_FILE_NAME
    console.print(info_color+F"使用{search_path}\\{xml}进行刷机")
    write_log(SCRIPT_FILE_NAME,pid,1,f"使用{search_path}\\{xml}进行刷机")
    if need_reboot_to_edl:
        console.print(info_color+"重启到9008...")
        wait_for_device()
        write_log(SCRIPT_FILE_NAME,pid,1,"将设备重启到9008...")
        run_command("adb reboot edl")

    while True:
            console.print(info_color+"\n等待3秒后检测设备...")
            write_log(SCRIPT_FILE_NAME,pid,1,"等待3秒后检测设备...")
            time.sleep(3.0)
            output = run_command("lsusb")
            if output == "" or output.isspace():
                console.print(warn_color+"暂未检测到设备...将会重试")
                write_log(SCRIPT_FILE_NAME,pid,2,"暂未检测到设备...将会重试")

            elif "QDLoader 9008" in output:
                console.print(info_color+"已找到设备，读取端口号...")
                write_log(SCRIPT_FILE_NAME,pid,1,info_color+"已找到设备，读取端口号...")
                device_qdloader_portnum = str(output.split("COM")[1]).split(")")[0]
                write_log(SCRIPT_FILE_NAME,pid,1,"当前寻找到的端口号：COM%s。"%device_qdloader_portnum)
                console.print(success_color+"当前寻找到的端口号：COM%s"%device_qdloader_portnum)
                if not device_qdloader_portnum.isdigit():
                    console.print(warn_color+"端口号读取失败...将会重试")
                    write_log(SCRIPT_FILE_NAME,pid,2,"端口号读取失败...将会重试")

                else:
                    device_qdloader_portnum = int(device_qdloader_portnum)
                    console.print(success_color+"完成！（1/3）")
                    write_log(SCRIPT_FILE_NAME,pid,1,"步骤1/3已完成。")
                    break
            elif "90B8" in output:
                console.print(tip_color+"找到了，但还处于正常模式\n将会重启它到9008...")
                write_log(SCRIPT_FILE_NAME,pid,1,"目前该设备还未重启到9008，将会试着重新重启...")
                run_command("adb reboot edl")
                write_log(SCRIPT_FILE_NAME,pid,1,"完成，重新检测设备...")
                console.print(success_color+"完成，重新检测设备...")
            time.sleep(2.0)
    abandon = False
    while True:
        write_log(SCRIPT_FILE_NAME,pid,1,f"发送分区表文件:{send_mbn}...")
        console.print(f"\n发送分区表文件:{send_mbn}...")
        console.print("──────────────────输出（乱码就忍了吧）──────────────────")
        output = run_command(F"QSaharaServer -s 13:{send_mbn} -p \\\\.\\COM{device_qdloader_portnum}",encoding="ANSI")
        console.print("──────────────────────────────────────────────────────")
        if "Error" in output or "ERROR" in output:
            write_log(SCRIPT_FILE_NAME,pid,2,"检测到了异常的输出：")
            console.print(err_color+"貌似出错了...下面是可能的出错原因")
            for output_line in str(output).splitlines():
                if "ERROR" in output_line.upper():
                    write_log(SCRIPT_FILE_NAME,pid,2,output_line)
                    console.print(err_color+output_line)
            console.print(warn_color+"将输出发给开发者说不定能解决这个问题...")
            console.print(tip_color+"要重新尝试吗？（yes为是，其他为否）")
            write_log(SCRIPT_FILE_NAME,pid,1,"询问用户是否重试...")
            abandon = False
            choosenum = choose()
            if choosenum == 1:
                write_log(SCRIPT_FILE_NAME,pid,1,"重试...")

            else:
                abandon = True
                write_log(SCRIPT_FILE_NAME,pid,1,"按任意键后返回菜单...")
                pause("那么，按任意键返回菜单...")
                return
        else:
            write_log(SCRIPT_FILE_NAME,pid,1,"步骤2/3已完成。")
            console.print(success_color+"完成！（步骤2/3）")
            break
    if abandon:return
    time.sleep(2.0)
    write_log(SCRIPT_FILE_NAME,pid,1,F"执行刷机程序:{xml}...")
    console.print(info_color+F"\n执行刷机程序:{xml}...")
    while True:
        console.print("──────────────────输出（乱码就忍了吧）──────────────────") # noprompt是不询问，showpercentage是展示百分比，setact..是设置活动分区（应该吧）
        output = run_command(
            F"fh_loader --port=\\\\.\\COM{device_qdloader_portnum} --search_path={search_path} --sendxml={xml} --noprompt --showpercentagecomplete --memoryname=eMMC --setactivepartition=0 {others}",
        encoding="ANSI")
        console.print("──────────────────────────────────────────────────────")
        if "Error" in output or "ERROR" in output:
            console.print(err_color+"貌似出错了...下面是可能的出错原因")
            write_log(SCRIPT_FILE_NAME,pid,2,"检测到了异常的输出：")
            for output_line in str(output).splitlines():
                if "ERROR" in output_line.upper():
                    console.print(err_color+output_line)
                    write_log(SCRIPT_FILE_NAME,pid,2,output_line)
            console.print(warn_color+"将输出发给开发者说不定能解决这个问题...")
            console.print(tip_color+"要重新尝试吗？（yes为是，其他为否）")
            write_log(SCRIPT_FILE_NAME,pid,1,"询问用户是否重试...")
            abandon = False
            choosenum = choose()
            if choosenum == 1:
                write_log(SCRIPT_FILE_NAME,pid,1,"重试...")

            else:
                abandon = True
                write_log(SCRIPT_FILE_NAME,pid,1,"按任意键后返回菜单...")
                pause("那么，按任意键返回菜单...")
                return
        else:
            console.print(success_color+"完成！（步骤3/3）")
            write_log(SCRIPT_FILE_NAME,pid,1,"步骤3/3已完成。")
            console.print(success_color+"执行完成！")
            return

def extract_partition(port:str="COM5",
                      programmer:str=COMMON_MBN_PATH,
                      mode:Union[                                               # 提取方式：
                                Tuple[Literal["by_name"],   str            ],   # 通过分区名
                                Tuple[Literal["by_sector"], Tuple[int, int]]    # 通过扇区数（起始，终止）（不建议）
                                ] = ("by_sector", (1356032, 1421568 - 1)),
                      output_file:FileDescriptorOrPath="boot.img",
                      show_output:bool=False,
                      reset:bool=True,
                      show_info:bool=False,
                      retry:int=1,
                      retry_interval:float=3,
                      show_progress:bool=False,
                      timeout:int=30,
                      timeout_warn:float=15) -> Union[List[int], int]:
    "根据给定参数提取分区"
    global done_sector, total_sector, line
    _mode = "fastboot"
    while _mode == "fastboot":
        _mode = wait_for_device(mode="any", showtext=False)
    if _mode == "adb":
        console.print(tip_color+"当前在启动模式，启动到9008...")
        run_command("adb reboot edl")
    
            
    return_list = []
    if mode[0] == "by_name":
        if show_progress:
            try:
                progress.start()
                t2 = progress.add_task(f"提取{mode[1]}:等待数据...")
            except:
                pass
        if show_info:
            console.print(info_color+f"提取分区{mode[1]}...")
        write_log(SCRIPT_FILE_NAME,text=f"本次提取参数：emmcdl -p {port} -f  {programmer} -d {mode[1]} -o {output_file}")
        tried = 0
        while tried <= retry:
            if tried:
                if show_info:
                    console.print(tip_color+f"重试...({tried}/3)")
                write_log(SCRIPT_FILE_NAME,text=f"重试...({tried}/3)")
            popen = subprocess.Popen(f"{BIN_PATH}\\emmcdl.exe -p {port} -f  {programmer} -d {mode[1]} -o {output_file}",
                                stdin = sys.stdin,
                                stdout = subprocess.PIPE,
                                stderr = subprocess.PIPE,
                                encoding="gbk",
                                bufsize=1,
                                shell=True,
                                errors=UnicodeDecodeError_Handle)
            if show_progress:
                
                line = ""
                first_read = True
                first_write = True
                output = ""
                no_output = 0
                done_sector = 0
                total_sector = 0
                warn_timeout = False
                output_time = time.time()
                def _read(p:subprocess.Popen):
                    global line, output
                    line = p.stdout.readline()
                    output += line

                while not ((not first_read and (line == "" or line is None)) and popen.poll() != None):
                    
                    first_read = False
                    t = Thread(target=_read,kwargs={"p":popen})
                    t.start()
                    
                    while t.is_alive():
                        if not warn_timeout and (time.time() - output_time >= timeout_warn):
                            console.print(warn_color+f"端口那边已经超过{time.time() - output_time:.1f}秒未响应了")
                            console.print(warn_color+f"如果在接下来{timeout-timeout_warn}秒中内端口仍未响应将会判定为失败")
                            t3 = progress.add_task("响应倒计时",total=timeout*10)
                            warn_timeout = True
                        if warn_timeout:
                            progress.update(t3,
                                            description=f"响应倒计时：{timeout-(time.time() - output_time):.1f}s",
                                            total=timeout-timeout_warn,
                                            completed=timeout-(time.time()-output_time))
                            
                        if time.time() - output_time > timeout:
                            progress.remove_task(t3)
                            console.print(err_color+"emmcdl超时未响应，提取失败...")
                            return 1
                
                    if warn_timeout:
                        console.print(info_color+"端口给出了响应")
                        warn_timeout = False
                        output_time = time.time()
                        progress.remove_task(t3)
                    output_time = time.time()

                    if line.startswith("Sectors remaining "):
                        if total_sector < int(line.split("Sectors remaining ")[-1].strip()):
                            total_sector = int(line.split("Sectors remaining ")[-1].strip())
                        first_write = False
                        done_sector = total_sector - int(line.split("Sectors remaining ")[-1].strip())
                        if show_progress:progress.update(t2,
                                        description=f"提取{mode[1]}:{str(done_sector).rjust(8)}/{str(total_sector)}",
                                        total=total_sector,
                                        completed=done_sector)
            else:
                while popen.poll() is None:"等待到进程爆炸"
                output = popen.stdout.read() + popen.stderr.read()
                
            stat = popen.returncode
            l = lambda l:l if l is not None else ""
            output += l(popen.stderr.read())
            if show_progress:
                try:
                    progress.remove_task(t2)
                    if progress.finished:
                        progress.stop()
                except:
                    pass
            return_list.append(stat)
            if stat:
                try:
                    write_log(SCRIPT_FILE_NAME,msgtype=2,text="出现错误："+output.strip().splitlines()[-1])
                except:
                    pass
                if show_info:
                    console.print(warn_color+"出现错误："+output.splitlines()[-1])
                    console.print(tip_color+f"{retry_interval:.2f}秒后重试...")
                time.sleep(retry_interval)
                tried += 1
            else:
                break
        if stat:
            if show_info:
                console.print(success_color+"提取失败...")
            write_log(SCRIPT_FILE_NAME,msgtype=3,text="提取失败...")
        else:
            if show_info:
                console.print(success_color+"完成！")
            write_log(SCRIPT_FILE_NAME,msgtype=1,text="完成！")

            if show_info:
                console.print(info_color+"提取"+mode[1]+"...")

    if mode[0] == "by_sector":
        if show_info:
            console.print(info_color+f"提取扇区({mode[1][0]} - {mode[1][1]})...")
        write_log(SCRIPT_FILE_NAME,text=f"本次提取参数：emmcdl -p {port} -f  {programmer} -disk_sector_size {mode[1][0]} {mode[1][1]} -o {output_file}")
        tried = 0
        while tried <= retry:
            if tried:
                if show_info:
                    console.print(tip_color+f"重试...({tried}/3)")
                write_log(SCRIPT_FILE_NAME,text=f"重试...({tried}/3)")
            
            popen = subprocess.Popen(f"{BIN_PATH}\\emmcdl -p {port} -f  {programmer} -disk_sector_size {mode[1][0]} {mode[1][1]} -o {output_file}",
                                stdin = sys.stdin,
                                stdout = subprocess.PIPE,
                                stderr = subprocess.PIPE,
                                cwd=cwd,
                                encoding="gbk",
                                bufsize=1,
                                shell=True,
                                errors=UnicodeDecodeError_Handle)
            line = ""
            first_read = True
            first_write = True
            output = ""
            no_output = 0
            warn_timeout = False
            while not ((not first_read and line == "" or line is None) and popen.poll() is not None):
                first_read = False
                line = popen.stdout.readline()
                if output == "":
                    no_output += 1
                    time.sleep(0.1)
                    if no_output >= timeout * 10 * 0.3:
                        console.print(warn_color+f"emmcdl已经超过{no_output/10:.1}秒未响应（设置超时时间的0.3倍）")
                        console.print(warn_color+f"如果在{timeout}秒中内emmcdl未响应将会判定失败")
                        t3 = progress.add_task("响应倒计时",total=timeout*10)
                        warn_timeout = True
                    if warn_timeout:
                        progress.update(t3, f"响应倒计时：{no_output/10:.1}s",total=timeout*10,completed=no_output)
                    if no_output > timeout*10:
                        progress.remove_task(t3)
                        console.print(warn_color+"如果在{timeout}秒中内emmcdl未响应将会判定失败")
                        return 1
                else:
                    if warn_timeout:
                        console.print(info_color+"emmcdl给出了响应")
                        no_output = 0
                        progress.remove_task(t3)



                output += line + "\n" if line != "" else ""
                if line.startswith("Sectors remaining "):
                    if first_write:
                        total_sector = int(line.split("Sectors remaining ")[-1].strip())
                        first_write = False
                    done_sector = total_sector - int(line.split("Sectors remaining ")[-1].strip())
                    if show_progress:progress.update(t2,description=f"提取{mode[1]}:{str(done_sector).rjust(8)}/{str(total_sector)}",
                                    total=total_sector,
                                    completed=done_sector)
            stat = popen.returncode
            l = lambda l:l if l is not None else ""
            output += l(popen.stderr.read())
            if show_progress:progress.remove_task(t2)
            if show_progress and progress.finished:
                progress.stop()
            return_list.append(stat)
            if stat:
                write_log(SCRIPT_FILE_NAME,msgtype=2,text="出现错误："+output.splitlines()[-1])
                if show_info:
                    console.print(warn_color+"出现错误："+output.splitlines()[-1])
                    console.print(tip_color+f"{retry_interval:.2f}秒后重试...")
                time.sleep(retry_interval)
                tried += 1
            else:
                break
        if stat:
            if show_info:
                console.print(success_color+"提取失败...")
            write_log(SCRIPT_FILE_NAME,msgtype=3,text="提取失败...")
        else:
            if show_info:
                console.print(success_color+"完成！")
            write_log(SCRIPT_FILE_NAME,msgtype=1,text="完成！")

            if show_info:
                console.print(info_color+"提取"+mode[1]+"...")

                    

    if reset:
        run_command(rf"fh_loader --port=\\.\{port} --noprompt --reset",encoding="gbk",show_output=show_output)
    while True:
        if isinstance(return_list, list) and len(return_list) == 1:
            return_list = return_list[0]
        else:
            break
    return stat



        
def flash_partition(port:str="COM5",
                      programmer:str=COMMON_MBN_PATH,
                      mode:List[Tuple[str, FileDescriptorOrPath]] = [("boot","boot.img"), ...], # 刷入方式：通过分区名称和路径
                      show_output:bool=False,
                      reset:bool=True,
                      set_active_partition:int=0,
                      show_info:bool=True,
                      retry:int=3,
                      retry_interval:float=3) -> Union[int, List[int], List[List[int]]]:
    extra = ""
    extra += "-SetActivePartition " + str(set_active_partition)
    return_list = []
    for flash_item in mode:
        cur_list = []
        write_log(SCRIPT_FILE_NAME,text="刷入"+flash_item[0]+"...")
        write_log(SCRIPT_FILE_NAME,text=f"本次刷入参数：emmcdl -p {port} -f  {programmer}  -b {flash_item[0]} {flash_item[1]} {extra}")
        tried = 0
        while tried <= retry:
            if tried:
                if show_info:
                    console.print(tip_color+f"重试...({tried}/3)")
                write_log(SCRIPT_FILE_NAME,text=f"重试...({tried}/3)")
            elif show_info:
                console.print(info_color+"刷入"+flash_item[0]+"...")
            stat, output = run_command(f"emmcdl -p {port} -f  {programmer}  -b {flash_item[0]} {flash_item[1]} {extra}",return_type="statusoutput",sync_update_bit=16, show_output=show_output)
            cur_list.append(stat)
            if stat:
                write_log(SCRIPT_FILE_NAME,msgtype=2,text="出现错误："+output.splitlines()[-1])
                if show_info:
                    console.print(warn_color+"出现错误："+output.splitlines()[-1])
                    console.print(tip_color+f"{retry_interval:.2f}秒后重试...")
                time.sleep(retry_interval)
                tried += 1
            else:
                break
        if stat:
            if show_info:
                console.print(success_color+flash_item[0]+"刷入失败...")
            write_log(SCRIPT_FILE_NAME,msgtype=3,text=f"刷入{flash_item[0]}失败...")
        else:
            if show_info:
                console.print(success_color+flash_item[0]+"刷入完成！")
            write_log(SCRIPT_FILE_NAME,msgtype=1,text=f"刷入{flash_item[0]}完成！")

        return_list.append(cur_list)

    if reset:
        run_command(rf"fh_loader --port=\\.\{port} --noprompt --reset",encoding="gbk",sync_update_bit=16,show_output=show_output)
    write_log(SCRIPT_FILE_NAME,msgtype=1,text=f"刷入结果：{return_list}")
    while True:
        if isinstance(return_list, list) and len(return_list) == 1:
            return_list = return_list[0]
        else:
            break

    return return_list


class SysCommand():
    "一句系统命令。"
    def __init__(self,command):
        self.cmd = command

    def execute(self):
        run_command(self.cmd)

class ScriptCommand():
    "一句脚本命令。"
    def __init__(self,command):
        self.cmd = command
    def execute(self):
        exec(self.cmd)

class FlashProgram():
    "一个刷机脚本。"
    def __init__(self,path):
        self.path = path
    
    def execute(self):
        flash_rawprogram(self.path,need_reboot_to_edl=False)



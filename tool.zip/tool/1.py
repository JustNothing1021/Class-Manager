import tkinter as tk

def append_log(log):
    text.insert(tk.END, log + "\n")
    text.see(tk.END)

root = tk.Tk()

text = tk.Text(root)
scrollbar = tk.Scrollbar(root, command=text.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# 示例：每秒钟向日志添加一条日志
import time
import threading

def add_log():
    count = 0
    while True:
        log = "日志条目1233333333333333333333333333333333333日志条目1233333333333333333333333333333333333日志条目1233333333333333333333333333333333333" + str(count)
        append_log(log)
        count += 1
        time.sleep(1)

thread = threading.Thread(target=add_log)
thread.start()

root.mainloop()

